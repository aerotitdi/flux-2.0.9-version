# -*- coding: utf-8 -*-
"""
FLUX :: core.py
Ядро ассистента: конфиг, HTTP (stdlib), PowerShell/система, логгер, цвета,
движок озвучки (TTS) с очередью, панель управления, уведомления/тосты.

ВАЖНО: всё работает на стандартной библиотеке Python.
Доп. пакеты (requests, pyttsx3, SpeechRecognition, psutil, mss, Pillow)
подхватываются автоматически, если установлены, но НЕ обязательны.
"""
from __future__ import annotations

import base64
import ctypes
import datetime as dt
import html
import io
import json
import logging
import mimetypes
import os
import platform
import queue
import random
import re
import shutil
import socket
import string
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

# ---------------------------------------------------------------- пути
def _resolve_root() -> Path:
    """Обычный запуск: корень = папка проекта.
    Сборка PyInstaller (--onefile): корень = папка, где лежит FLUX.exe,
    а встроенные файлы (config.json, searxng/...) распакованы в sys._MEIPASS
    и при первом запуске копируются рядом с EXE."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def _seed_from_bundle(root: Path):
    """Копирует из бандла отсутствующие файлы (только если их нет рядом с EXE)."""
    bundle = getattr(sys, "_MEIPASS", None)
    if not bundle:
        return
    try:
        src = Path(bundle)
        for rel in ("config.json", "docker-compose.yml", "flux_background.vbs", "run.bat",
                    "searxng/settings.yml", "requirements-core.txt", "requirements-extra.txt"):
            dst = root / rel
            sp = src / rel
            if sp.exists() and not dst.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
                try:
                    dst.write_bytes(sp.read_bytes())
                except Exception:
                    pass
    except Exception:
        pass


ROOT = _resolve_root()
_seed_from_bundle(ROOT)
DATA = ROOT / "data"
SESSIONS_DIR = DATA / "sessions"
MEMORY_DIR = DATA / "memory"
LOG_DIR = DATA / "logs"
MEDIA_DIR = DATA / "media"
SCREEN_DIR = MEDIA_DIR / "screenshots"
AUDIO_DIR = MEDIA_DIR / "audio"
DOWNLOAD_DIR = MEDIA_DIR / "downloads"
APPS_DIR = DATA / "apps"
SANDBOX_DIR = DATA / "sandbox"
CONFIG_FILE = ROOT / "config.json"
SECRETS_FILE = ROOT / "secret.key"
MEMORY_FILE = MEMORY_DIR / "memory.json"
NOTES_FILE = MEMORY_DIR / "notes.json"
FACTS_FILE = MEMORY_DIR / "facts.json"
SCHEDULE_FILE = MEMORY_DIR / "schedule.json"
LOG_FILE = LOG_DIR / "flux.log"
TOOLS_LOG = LOG_DIR / "tools.log"

for d in (SESSIONS_DIR, MEMORY_DIR, LOG_DIR, MEDIA_DIR, SCREEN_DIR,
          AUDIO_DIR, DOWNLOAD_DIR, APPS_DIR, SANDBOX_DIR):
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

IS_WIN = platform.system() == "Windows"
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/126.0 Safari/537.36 FluxAssistant/2.0")

# ---------------------------------------------------------------- консоль utf-8
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if IS_WIN:
    try:
        ctypes.windll.kernel32.SetConsoleOutputCP(65001)
        ctypes.windll.kernel32.SetConsoleCP(65001)
    except Exception:
        pass

# ---------------------------------------------------------------- цвета
class C:
    _on = IS_WIN and os.environ.get("WT_SESSION") is None and True
    RESET = "\033[0m"; BOLD = "\033[1m"; DIM = "\033[2m"; ITAL = "\033[3m"
    RED = "\033[91m"; GREEN = "\033[92m"; YELLOW = "\033[93m"
    BLUE = "\033[94m"; MAG = "\033[95m"; CYAN = "\033[96m"; WHITE = "\033[97m"

    @staticmethod
    def enable():
        if not IS_WIN:
            return
        try:
            k = ctypes.windll.kernel32
            h = k.GetStdHandle(-11)
            mode = ctypes.c_uint()
            if k.GetConsoleMode(h, ctypes.byref(mode)):
                k.SetConsoleMode(h, mode.value | 0x0004)
        except Exception:
            pass


def clear_screen():
    os.system("cls" if IS_WIN else "clear")


def banner():
    C.enable()
    logo = r"""
   ______ __    __  __  __
  / ____// /   / / / / / /   F L U X
 / /_   / /   / / / /_/ /    AI-ассистент для Windows 10/11
/ __/  / /___/ /_/ __  /     агент + голос + система + веб
/_/   /_____/\____/_/ /_/     wake word: "ФЛЮКС ..."
"""
    print(C.CYAN + logo + C.RESET)


# ---------------------------------------------------------------- логгер
def _mk_logger(name: str, path: Path, level=logging.INFO) -> logging.Logger:
    lg = logging.getLogger(name)
    lg.setLevel(level)
    lg.propagate = False
    if not lg.handlers:
        try:
            # FIX: ротация логов (3 x 2 МБ) — раньше flux.log/tools.log росли бесконечно
            from logging.handlers import RotatingFileHandler
            fh = RotatingFileHandler(str(path), maxBytes=2_000_000, backupCount=3, encoding="utf-8")
            fh.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
            lg.addHandler(fh)
        except Exception:
            try:
                fh = logging.FileHandler(str(path), encoding="utf-8")
                fh.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
                lg.addHandler(fh)
            except Exception:
                pass
    return lg


log = _mk_logger("flux", LOG_FILE)
tools_log = _mk_logger("flux.tools", TOOLS_LOG)


def debug(msg):
    log.debug(msg)
    if os.environ.get("FLUX_DEBUG"):
        print(C.DIM + "[debug] " + str(msg) + C.RESET)


def dlog(msg):
    """Печатает, только если включён verbose."""
    if os.environ.get("FLUX_VERBOSE"):
        print(C.DIM + str(msg) + C.RESET)


# ---------------------------------------------------------------- конфиг
DEFAULT_CONFIG = {
    "api_key": "",
    "base_url": "https://api.xkiro.com/v1",
    "model": "qwen/qwen3.8-max:free",
    "model_fallbacks": ["qwen/qwen3.7-max:free", "qwen/qwen3.7-plus:free", "qwen/qwen3-max:free"],
    "temperature": 0.6,
    "max_tokens": 4096,
    "request_timeout": 240,
    "max_retries": 4,
    "assistant_name": "Флюкс",
    "wake_words": ["флюкс", "flux", "флукс", "флюкса", "флюксик", "флокс"],
    "language": "ru",
    "voice_input": True,
    "voice_output": True,
    "tts_engine": "auto",
    "tts_rate": 1,
    "tts_voice": "",
    "push_to_talk_hotkey": True,
    "hotkey_modifiers": ["ctrl", "alt"],
    "hotkey_key": "F",
    "listen_timeout": 9,
    "followup_timeout": 7,
    "auto_listen_after_answer": True,
    "searxng_url": "http://localhost:8888",
    "searxng_enabled": True,
    "web_fallbacks": ["ddg", "bing"],
    "search_results": 6,
    "install_dir": "D:\\Flux",
    "auto_approve_dangerous": False,
    "confirm_destructive": True,
    "max_tool_steps": 12,          # v2.0.5: меньше шагов = кратно меньше токенов на задачу
    "shell_timeout": 120,
    "python_timeout": 120,
    "proactive": True,
    "proactive_interval_sec": 180,
    "proactive_speak": True,
    "proactive_checks": ["disk", "memory", "cpu", "battery", "defender", "crashes", "updates", "temperature"],
    "thresholds": {"disk_free_percent": 8, "memory_percent": 93, "cpu_percent": 96,
                   "cpu_sustained_sec": 240, "battery_percent": 15, "temperature_c": 88},
    "control_panel": True,
    "panel_host": "127.0.0.1",
    "panel_port": 8787,
    "panel_token": "",   # FIX: пустой = генерируется случайный при первом запуске (безопасность)
    "menu_theme": "cyan",     # тема стартового меню: cyan/matrix/synth/amber/ice
    "menu_anim": "matrix",    # анимация фона: matrix/stars/rain/wave/off
    "panel_theme": "dark",    # тема веб-панели: dark/cyan/matrix/synth/amber/ice
    "panel_bg": "off",        # фон веб-панели: matrix/stars/wave/off

    # ---- провайдеры моделей (v2.0.6) ----
    # xkiro    — api.xkiro.com (ключ secret.key), лимиты free-тарифа
    # qwen_web — ВСТРОЕННЫЙ мост chat.qwen.ai (без лимитов xkiro; токен qwen_web.key;
    #            модели qwen3.8-max, qwen3.8-max:search — с поиском в интернете)
    # ollama   — локальные модели (http://127.0.0.1:11434, без интернета и ключей)
    # bridge   — внешний мост tools/qwen_bridge.py на localhost:8000 (OpenAI API)
    "provider": "xkiro",
    "auto_fallback_providers": ["qwen_web", "ollama"],  # куда прыгать при исчерпании лимита/401
    "prefer_free_models": True,   # free-режим: в списках и фолбэках только бесплатные модели
    "api_keys": [],               # пул ключей xkiro: ротация при 429/лимите
    "bridge_url": "http://127.0.0.1:8000/v1",
    "bridge_api_key": "",
    "ollama_url": "http://127.0.0.1:11434",
    "qwen_token": "",             # лучше держать в файле qwen_web.key (права 600)
    "qwen_cookie": "",
    "qwen_thinking": "auto",      # auto | thinking | fast
    "qwen_clean_chats": True,
    "qwen_auto_token": True,      # v2.0.9: авто-токен chat.qwen.ai из localStorage браузера
    "qwen_token_scan_dirs": [],   # доп. папки для сканирования (нестандартные браузеры)
    "qwen_default_model": "qwen3.8-max:search",  # :search = модель сама ищет в интернете
    "ollama_model": "",           # пустая = модель из поля model / первая локальная
    "models_by_provider": {"xkiro": "qwen/qwen3.8-max:free",
                           "qwen_web": "qwen3.8-max:search",
                           "bridge": "qwen3.8-max",
                           "ollama": ""},
    # v2.0.5: урезаны раздутые дефолты контекста (90K симв ~27K токенов в КАЖДОМ запросе)
    "context": {"max_messages": 28, "max_chars": 48000, "summary_keep_last": 12},
    "token_economy_v": 2,
    "gui_on_start": False,
    "verbose": False,
    "sound_fx": True,
    "mic_device": "",
}


def _deep_merge(base: dict, extra: dict) -> dict:
    out = dict(base)
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


class Config:
    def __init__(self, path: Path = CONFIG_FILE):
        self.path = path
        self.data = dict(DEFAULT_CONFIG)
        self.load()

    def load(self):
        raw = {}
        try:
            if self.path.exists():
                raw = json.loads(self.path.read_text(encoding="utf-8")) or {}
                self.data = _deep_merge(DEFAULT_CONFIG, raw)
        except Exception as e:
            log.warning("config load error: %s", e)
        # v2.0.5: миграция экономии токенов для конфигов, созданных ДО этой версии.
        # Маркер смотрим В ФАЙЛЕ (в DEFAULT_CONFIG он есть всегда — иначе миграция
        # никогда бы не срабатывала после deep-merge).
        if not (isinstance(raw, dict) and raw.get("token_economy_v")):
            changed = False
            cc = self.data.get("context") or {}
            if int(cc.get("max_messages", 0)) == 46:
                cc["max_messages"] = 28
                changed = True
            if int(cc.get("max_chars", 0)) == 90000:
                cc["max_chars"] = 48000
                changed = True
            if int(self.data.get("max_tool_steps", 0)) == 24:
                self.data["max_tool_steps"] = 12
                changed = True
            self.data["token_economy_v"] = 2
            if changed:
                log.info("config: применена миграция экономии токенов v2")
                self.save()
        # ключ из окружения / файла имеет приоритет
        env = os.environ.get("FLUX_API_KEY") or os.environ.get("XKIRO_API_KEY")
        if env:
            self.data["api_key"] = sanitize_key(env)
        try:
            if SECRETS_FILE.exists():
                sk = sanitize_key(SECRETS_FILE.read_text(encoding="utf-8"))
                if sk:
                    self.data["api_key"] = sk
        except Exception:
            pass
        return self.data

    def save(self):
        try:
            self.path.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            log.warning("config save error: %s", e)

    def __getitem__(self, k):
        return self.data.get(k)

    def get(self, k, d=None):
        return self.data.get(k, d)

    def set(self, k, v, save=True):
        self.data[k] = v
        if save:
            self.save()


CFG = Config()


def sanitize_key(raw: str) -> str:
    """Чистит ключ от всего лишнего: пробелы, переносы, кавычки, префикс Bearer.
    xkiro отвечает 401 'Missing ClientApiKey' на ключ с пробелом по краям
    и 401 'Invalid or disabled ClientApiKey' на ключ в кавычках."""
    s = (raw or "").strip()
    for _ in range(3):
        s = s.strip().strip('"').strip("'").strip()
    if s.lower().startswith("bearer "):
        s = s[7:].strip()
    s = re.sub(r"\s+", "", s)          # внутри ключа пробелов не бывает
    return s


KEY_SOURCE = {"value": None}


def get_api_key() -> str:
    k = sanitize_key(CFG.get("api_key") or "")
    if not k or "ВСТАВЬ" in k.upper():
        KEY_SOURCE["value"] = None
        return ""
    return k


def key_source() -> str:
    """Откуда взят ключ: env / secret.key / config.json / нет."""
    if os.environ.get("FLUX_API_KEY") or os.environ.get("XKIRO_API_KEY"):
        return "переменная окружения"
    try:
        if SECRETS_FILE.exists() and SECRETS_FILE.read_text(encoding="utf-8").strip():
            return str(SECRETS_FILE)
    except Exception:
        pass
    v = (CFG.data.get("api_key") or "")
    if v.strip() and "ВСТАВЬ" not in v.upper():
        return str(CONFIG_FILE)
    return "не задан"


def masked_key() -> str:
    k = get_api_key()
    if not k:
        return "(нет)"
    return f"{k[:7]}...{k[-4:]} ({len(k)} симв.)"


# ---------------------------------------------------------------- JSON helpers
def jload(path: Path, default=None):
    try:
        p = Path(path)
        if p.exists() and p.stat().st_size > 0:
            return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        log.warning("jload %s: %s", path, e)
    return default if default is not None else {}


def jsave(path: Path, obj) -> bool:
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        os.replace(str(tmp), str(p))
        return True
    except Exception as e:
        log.warning("jsave %s: %s", path, e)
        return False


def now() -> dt.datetime:
    return dt.datetime.now()


def now_iso() -> str:
    return now().isoformat(timespec="seconds")


def human_time(ts=None) -> str:
    t = dt.datetime.fromtimestamp(ts) if ts else now()
    return t.strftime("%d.%m.%Y %H:%M:%S")


def rand_id(n=8) -> str:
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))


def safe_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(name)).strip().strip(".")
    return name[:120] or ("file_" + rand_id(6))


def sizeof_fmt(num, suffix="B") -> str:
    try:
        num = float(num)
    except Exception:
        return str(num)
    for unit in ("", "K", "M", "G", "T", "P"):
        if abs(num) < 1024.0:
            return f"{num:3.1f} {unit}{suffix}"
        num /= 1024.0
    return f"{num:.1f} E{suffix}"


def clip(text: str, n: int = 4000) -> str:
    text = str(text)
    if len(text) <= n:
        return text
    return text[:n] + f"\n... [обрезано, всего {len(text)} символов]"


def est_tokens(text: str) -> int:
    """Грубая оценка токенов (~3.3 символа на токен для смеси ru/en)."""
    return max(1, len(text) // 3)


def truncate_middle(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    half = max(200, limit // 2)
    return text[:half] + f"\n\n...[пропущено {len(text) - 2 * half} символов]...\n\n" + text[-half:]


# ---------------------------------------------------------------- HTTP (stdlib)
def http_json(url: str, method: str = "GET", payload=None, headers=None,
              timeout: int = 40, raw_body: str | None = None) -> tuple[int, dict | str]:
    """Простой HTTP-клиент. Возвращает (status, json_or_text)."""
    hdrs = {"User-Agent": USER_AGENT, "Accept": "application/json, text/plain, */*"}
    if headers:
        hdrs.update(headers)
    data = None
    if raw_body is not None:
        data = raw_body.encode("utf-8")
        hdrs.setdefault("Content-Type", "application/json")
    elif payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        hdrs.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=data, headers=hdrs, method=method.upper())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read().decode("utf-8", "replace")
            try:
                return r.status, json.loads(body)
            except Exception:
                return r.status, body
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", "replace")
        except Exception:
            body = ""
        try:
            return e.code, json.loads(body)
        except Exception:
            return e.code, body
    except urllib.error.URLError as e:
        return -1, {"error": f"URLError: {e.reason}"}
    except Exception as e:
        return -1, {"error": f"{type(e).__name__}: {e}"}


def http_get_text(url: str, timeout: int = 30, headers=None) -> tuple[int, str]:
    hdrs = {"User-Agent": USER_AGENT}
    if headers:
        hdrs.update(headers)
    try:
        req = urllib.request.Request(url, headers=hdrs)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            ct = r.headers.get("Content-Type", "")
            body = r.read(4_000_000)
            enc = "utf-8"
            m = re.search(r"charset=([\w\-]+)", ct)
            if m:
                enc = m.group(1)
            return r.status, body.decode(enc, "replace")
    except urllib.error.HTTPError as e:
        try:
            return e.code, e.read(200000).decode("utf-8", "replace")
        except Exception:
            return e.code, ""
    except Exception as e:
        return -1, f"{type(e).__name__}: {e}"


def download(url: str, dest: Path | str, timeout: int = 120, progress=True) -> dict:
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=timeout) as r, open(dest, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            got = 0
            last = 0.0
            while True:
                chunk = r.read(256 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                if progress and total and time.time() - last > 0.6:
                    last = time.time()
                    pct = got * 100 // total
                    print(f"\r  {C.CYAN}загрузка {pct}% ({sizeof_fmt(got)}/{sizeof_fmt(total)}){C.RESET}",
                          end="", flush=True)
            if progress and total:
                print()
        return {"ok": True, "path": str(dest), "size": got, "size_human": sizeof_fmt(got)}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ---------------------------------------------------------------- система
def decode_out(b: bytes) -> str:
    """FIX v2.0.5: вывод cmd/PowerShell на русской Windows приходит в OEM-кодировке cp866,
    а читался как UTF-8 — вся кириллица (сообщения журналов Windows, tasklist, ping...)
    превращалась в ``. Пробуем UTF-8 строго, затем cp866."""
    if not b:
        return ""
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        pass
    if IS_WIN:
        try:
            return b.decode("cp866")
        except Exception:
            pass
    return b.decode("utf-8", "replace")


def run(cmd, timeout: int = 90, cwd=None, shell: bool = False, input_text: str | None = None,
        env: dict | None = None) -> dict:
    """Универсальный запуск процесса. Возвращает dict(ok, code, stdout, stderr, truncated)."""
    e = dict(os.environ)
    e["PYTHONUTF8"] = "1"
    e["PYTHONIOENCODING"] = "utf-8"
    if env:
        e.update(env)
    t0 = time.time()
    try:
        p = subprocess.run(
            cmd, shell=shell, cwd=str(cwd) if cwd else None,
            input=(input_text.encode("utf-8") if input_text else None),
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=timeout, env=e,
            creationflags=(0x08000000 if IS_WIN and not shell else 0),
        )
        out = decode_out(p.stdout or b"")
        err = decode_out(p.stderr or b"")
        return {"ok": p.returncode == 0, "code": p.returncode,
                "stdout": truncate_middle(out, 60000), "stderr": truncate_middle(err, 20000),
                "seconds": round(time.time() - t0, 2)}
    except subprocess.TimeoutExpired:
        return {"ok": False, "code": -1, "stdout": "", "stderr": f"timeout after {timeout}s",
                "seconds": round(time.time() - t0, 2), "timeout": True}
    except FileNotFoundError as e2:
        return {"ok": False, "code": -2, "stdout": "", "stderr": f"command not found: {e2}"}
    except Exception as e2:
        return {"ok": False, "code": -3, "stdout": "", "stderr": f"{type(e2).__name__}: {e2}"}


_ps_cache_lock = threading.Lock()


def powershell(script: str, timeout: int = 60, encoded: bool = True) -> dict:
    """Выполняет PowerShell-скрипт (UTF-16LE encoded command -> без проблем с кавычками)."""
    # FIX v2.0.5: выводим UTF-8 из самого PowerShell, иначе русские строки из
    # Get-WinEvent/Get-MpThreatDetection приходили в cp866 и терялись при декодировании
    script = ("[Console]::OutputEncoding = [System.Text.Encoding]::UTF8\n"
              "$OutputEncoding = [System.Text.Encoding]::UTF8\n") + script
    base = ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass"]
    if encoded:
        try:
            b64 = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
            return run(base + ["-EncodedCommand", b64], timeout=timeout)
        except Exception:
            pass
    return run(base + ["-Command", script], timeout=timeout)


def pwsh_json(script: str, timeout: int = 60):
    """PowerShell, который обязан вернуть JSON. Возвращает объект или None."""
    r = powershell(script, timeout=timeout)
    txt = (r.get("stdout") or "").strip()
    if not txt:
        return None
    # вырезаем возможный мусор до первой { или [
    i1 = min([x for x in (txt.find("{"), txt.find("[")) if x >= 0] or [-1])
    if i1 > 0:
        txt = txt[i1:]
    try:
        return json.loads(txt)
    except Exception:
        try:
            return json.loads(txt.replace("\ufeff", ""))
        except Exception:
            return None


def cmd_run(command: str, timeout: int = 90, cwd=None) -> dict:
    if IS_WIN:
        return run(["cmd", "/c", command], timeout=timeout, cwd=cwd)
    return run(["/bin/sh", "-c", command], timeout=timeout, cwd=cwd)


def is_admin() -> bool:
    try:
        if IS_WIN:
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return False


def open_path(path: str):
    """Открывает файл/папку/URL системным способом."""
    try:
        if IS_WIN:
            os.startfile(path)  # type: ignore[attr-defined]
            return True
        if sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
        return True
    except Exception as e:
        log.warning("open_path %s: %s", path, e)
        return False


def beep(freq=880, ms=180):
    if not CFG.get("sound_fx", True):
        return
    try:
        if IS_WIN:
            import winsound
            winsound.Beep(int(freq), int(ms))
        else:
            print("\a", end="", flush=True)
    except Exception:
        pass


def play_sound_file(path: str):
    try:
        if IS_WIN:
            if str(path).lower().endswith(".wav"):
                import winsound
                winsound.PlaySound(str(path), winsound.SND_FILENAME | winsound.SND_ASYNC)
            else:
                subprocess.Popen(["cmd", "/c", "start", "", str(path)], creationflags=0x08000000)
        else:
            open_path(path)
    except Exception as e:
        log.warning("play_sound: %s", e)


# ---------------------------------------------------------------- TTS
class Speaker:
    """Очередь озвучки. Движки: pyttsx3 -> edge-tts -> PowerShell SAPI -> print."""

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.q: "queue.Queue[str | None]" = queue.Queue()
        self.enabled = bool(cfg.get("voice_output", True))
        self.engine_name = "none"
        self._pyttsx = None
        self._lock = threading.Lock()
        self.thread = threading.Thread(target=self._worker, daemon=True, name="flux-tts")
        self.thread.start()
        self._init_engine()

    # --- инициализация движка
    def _init_engine(self):
        want = str(self.cfg.get("tts_engine", "auto")).lower()
        if not self.enabled:
            self.engine_name = "disabled"
            return
        if want in ("auto", "pyttsx3"):
            try:
                import pyttsx3  # type: ignore
                eng = pyttsx3.init()
                rate = int(self.cfg.get("tts_rate", 1))
                eng.setProperty("rate", 165 + rate * 12)
                vname = str(self.cfg.get("tts_voice", "") or "")
                voices = eng.getProperty("voices") or []
                # FIX: раньше цикл перезаписывал pick на КАЖДОМ совпадении, и английский
                # "David" (он есть почти во всех Windows) перекрывал русскую "Irina" —
                # Флюкс говорил по-русски английским голосом. Теперь: точное имя -> ru -> любой.
                pick = None
                for v in voices:
                    blob = f"{getattr(v,'name','')} {' '.join(getattr(v,'languages',[]) or [])}".lower()
                    if vname and vname.lower() in blob:
                        pick = v
                        break
                if pick is None:
                    for v in voices:
                        blob = f"{getattr(v,'name','')} {' '.join(getattr(v,'languages',[]) or [])}".lower()
                        if re.search(r"\bru\b|russian|irina|maxim|светлана|dmitry|katya|pavel", blob):
                            pick = v
                            break
                if pick:
                    eng.setProperty("voice", pick.id)
                self._pyttsx = eng
                self.engine_name = "pyttsx3"
                return
            except Exception as e:
                log.info("pyttsx3 недоступен: %s", e)
        if want in ("auto", "edge"):
            try:
                import edge_tts  # type: ignore  # noqa
                self.engine_name = "edge-tts"
                return
            except Exception:
                pass
        if IS_WIN:
            self.engine_name = "sapi"
            return
        self.engine_name = "print"

    def set_enabled(self, on: bool):
        self.enabled = on
        if not on:
            self.stop()

    def stop(self):
        try:
            while True:
                self.q.get_nowait()
        except Exception:
            pass

    def say(self, text: str, priority: bool = False):
        if not self.enabled or not text:
            return
        text = self._clean(text)
        if not text.strip():
            return
        if priority:
            self.stop()
        self.q.put(text)

    @staticmethod
    def _clean(t: str) -> str:
        t = re.sub(r"```.*?```", " (код) ", t, flags=re.S)
        t = re.sub(r"`([^`]+)`", r"\1", t)
        t = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", t)
        t = re.sub(r"[*#>_~|]+", " ", t)
        t = re.sub(r"https?://\S+", " ссылка ", t)
        t = re.sub(r"\s+", " ", t).strip()
        return t

    def _worker(self):
        while True:
            item = self.q.get()
            if item is None:
                break
            try:
                self._speak(item)
            except Exception as e:
                log.warning("tts error: %s", e)

    def _speak(self, text: str):
        if self.engine_name == "pyttsx3" and self._pyttsx is not None:
            with self._lock:
                try:
                    self._pyttsx.say(text)
                    self._pyttsx.runAndWait()
                    return
                except Exception as e:
                    log.warning("pyttsx3 speak fail: %s", e)
        if self.engine_name == "edge-tts":
            try:
                if self._edge(text):
                    return
            except Exception as e:
                log.warning("edge-tts fail: %s", e)
        if IS_WIN and self._sapi(text):
            return
        # фолбэк — просто в консоль
        pass

    def _edge(self, text: str) -> bool:
        try:
            import asyncio
            import edge_tts  # type: ignore
        except Exception:
            return False
        out = AUDIO_DIR / f"flux_tts_{rand_id(6)}.mp3"
        voice = str(self.cfg.get("tts_voice") or "") or "ru-RU-DmitryNeural"

        async def go():
            c = edge_tts.Communicate(text, voice)
            await c.save(str(out))
        try:
            loop = asyncio.new_event_loop()
            loop.run_until_complete(go())
            loop.close()
        except Exception as e:
            log.warning("edge synth: %s", e)
            return False
        if not out.exists() or out.stat().st_size < 512:
            return False
        try:
            if IS_WIN:
                # FIX: раньше mp3 открывался системным плеером (мелькало окно), а длительность
                # «угадывалась» по длине текста. Теперь — MCI (winmm), ждём реальный конец.
                played = False
                try:
                    import ctypes
                    alias = "fluxmci" + rand_id(4)
                    mci = ctypes.windll.winmm.mciSendStringW
                    p = str(out).replace('"', "")
                    if mci(f'open "{p}" type mpegvideo alias {alias}', None, 0, None) == 0:
                        if mci(f"play {alias} wait", None, 0, None) == 0:
                            played = True
                        mci(f"close {alias}", None, 0, None)
                except Exception as e:
                    log.debug("mci play: %s", e)
                if not played:
                    ps = (f"$p=Start-Process -FilePath 'cmd.exe' -ArgumentList '/c start \"\" /min "
                          f"\"{out}\"' -WindowStyle Hidden -PassThru; "
                          f"Start-Sleep -Milliseconds 400")
                    powershell(ps, timeout=15)
                    time.sleep(min(60, max(1.2, len(text) / 12.0)))
            else:
                subprocess.run(["mpv", "--no-video", str(out)], timeout=120,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            return False
        return True

    def _sapi(self, text: str) -> bool:
        esc = text.replace("'", "''")[:3500]
        ps = f"""
$ErrorActionPreference='SilentlyContinue'
Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$v = $s.GetInstalledVoices() | Where-Object {{ $_.VoiceInfo.Culture.Name -like 'ru*' }} | Select-Object -First 1
if ($v) {{ $s.SelectVoice($v.VoiceInfo.Name) }}
$s.Rate = {int(self.cfg.get('tts_rate', 1))}
$s.Speak('{esc}')
$s.Dispose()
"""
        r = powershell(ps, timeout=180)
        return r.get("code") == 0


SPEAKER: Speaker | None = None


def get_speaker() -> Speaker:
    global SPEAKER
    if SPEAKER is None:
        SPEAKER = Speaker(CFG)
    return SPEAKER


def say(text: str, priority: bool = False):
    get_speaker().say(text, priority=priority)


# ---------------------------------------------------------------- тосты / уведомления
_toaster_lock = threading.Lock()


def toast(title: str, message: str, seconds: int = 12, sound: bool = True):
    """Всплывающее окно (tkinter) -> PowerShell balloon -> консоль."""
    def _show():
        with _toaster_lock:
            if _tk_toast(title, message, seconds):
                return
        _ps_toast(title, message)
    t = threading.Thread(target=_show, daemon=True)
    t.start()
    if sound:
        beep(1046, 160)
    print(f"{C.YELLOW}[*] {title}:{C.RESET} {message}")


def _tk_toast(title: str, message: str, seconds: int) -> bool:
    try:
        import tkinter as tk
    except Exception:
        return False
    ok = {"v": False}

    def build():
        try:
            root = tk.Tk()
            root.overrideredirect(True)
            root.attributes("-topmost", True)
            try:
                root.attributes("-alpha", 0.97)
            except Exception:
                pass
            w, h = 400, 130
            sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
            root.geometry(f"{w}x{h}+{sw - w - 24}+{sh - h - 64}")
            fr = tk.Frame(root, bg="#0f1720", highlightbackground="#22d3ee", highlightthickness=2)
            fr.pack(fill="both", expand=True)
            tk.Label(fr, text=f"FLUX :: {title}", bg="#0f1720", fg="#22d3ee",
                     font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
            tk.Label(fr, text=message, bg="#0f1720", fg="#e6edf3", font=("Segoe UI", 10),
                     wraplength=w - 30, justify="left").pack(anchor="w", padx=12, pady=(0, 8))
            root.after(int(seconds * 1000), root.destroy)
            ok["v"] = True
            root.mainloop()
        except Exception as e:
            log.debug("tk toast: %s", e)

    th = threading.Thread(target=build, daemon=True)
    th.start()
    th.join(0.6)
    return ok["v"]


def _ps_toast(title: str, message: str):
    if not IS_WIN:
        return
    t = str(title).replace("'", "''")[:120]
    m = str(message).replace("'", "''")[:400]
    ps = f"""
$ErrorActionPreference='SilentlyContinue'
[reflection.assembly]::loadwithpartialname('System.Windows.Forms') | Out-Null
[reflection.assembly]::loadwithpartialname('System.Drawing') | Out-Null
$ni = New-Object System.Windows.Forms.NotifyIcon
$ni.Icon = [System.Drawing.SystemIcons]::Information
$ni.BalloonTipTitle = '{t}'
$ni.BalloonTipText = '{m}'
$ni.Visible = $true
$ni.ShowBalloonTip(12000)
Start-Sleep -Milliseconds 13000
$ni.Dispose()
"""
    threading.Thread(target=lambda: powershell(ps, timeout=40), daemon=True).start()


# ---------------------------------------------------------------- HTML-выжимка
def html_to_text(raw: str, limit: int = 6000) -> str:
    try:
        raw = re.sub(r"(?is)<(script|style|noscript|svg|head)[^>]*>.*?</\1>", " ", raw)
        raw = re.sub(r"(?is)<!--.*?-->", " ", raw)
        raw = re.sub(r"(?is)<br\s*/?>", "\n", raw)
        raw = re.sub(r"(?is)</(p|div|li|tr|h[1-6])>", "\n", raw)
        raw = re.sub(r"(?s)<[^>]+>", " ", raw)
        raw = html.unescape(raw)
        raw = re.sub(r"[ \t\r\f\v]+", " ", raw)
        raw = re.sub(r"\n\s*\n\s*\n+", "\n\n", raw)
        return raw.strip()[:limit]
    except Exception:
        return str(raw)[:limit]


def file_to_base64(path: str | Path, max_bytes: int = 6_000_000) -> str | None:
    try:
        p = Path(path)
        if not p.exists():
            return None
        b = p.read_bytes()
        if len(b) > max_bytes:
            # попробуем уменьшить картинку, если есть Pillow
            try:
                from PIL import Image  # type: ignore
                im = Image.open(io.BytesIO(b))
                im = im.convert("RGB")
                im.thumbnail((1280, 1280))
                buf = io.BytesIO()
                im.save(buf, format="JPEG", quality=72)
                b = buf.getvalue()
            except Exception:
                return None
        return base64.b64encode(b).decode("ascii")
    except Exception as e:
        log.warning("file_to_base64: %s", e)
        return None


def mime_of(path: str) -> str:
    m, _ = mimetypes.guess_type(str(path))
    return m or "application/octet-stream"


def local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def port_open(host: str, port: int, timeout: float = 1.2) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def exc_text() -> str:
    return traceback.format_exc(limit=6)
