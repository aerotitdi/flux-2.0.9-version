# -*- coding: utf-8 -*-
"""
FLUX :: core/tools_system.py
Системные инструменты агента: файлы, процессы, запуск программ, управление ПК,
экран, звук, буфер обмена, shell/python, создание программ на лету.
"""
from __future__ import annotations

import datetime as dt
import glob
import json
import os
import re
import shlex
import shutil
import socket
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

from . import (APPS_DIR, AUDIO_DIR, CFG, DOWNLOAD_DIR, IS_WIN, MEDIA_DIR, ROOT, SANDBOX_DIR,
               SCREEN_DIR, clip, cmd_run, exc_text, file_to_base64, http_get_text, human_time,
               jload, jsave, log, mime_of, now, open_path, powershell, pwsh_json, run,
               safe_filename, sizeof_fmt, toast, tools_log, truncate_middle)

REGISTRY: dict[str, dict] = {}


def tool(name: str, description: str, parameters: dict, handler=None,
         dangerous: bool = False, hidden: bool = False):
    """Декоратор регистрации инструмента (OpenAI function-calling схема)."""
    def deco(fn):
        REGISTRY[name] = {
            "name": name,
            "description": description,
            "parameters": parameters,
            "handler": fn,
            "dangerous": dangerous,
            "hidden": hidden,
        }
        return fn
    if handler is not None:
        REGISTRY[name] = {"name": name, "description": description, "parameters": parameters,
                          "handler": handler, "dangerous": dangerous, "hidden": hidden}
        return handler
    return deco


def tool_schemas(exclude_hidden=True) -> list[dict]:
    out = []
    for name, t in REGISTRY.items():
        if exclude_hidden and t.get("hidden"):
            continue
        out.append({
            "type": "function",
            "function": {
                "name": name,
                "description": t["description"],
                "parameters": t["parameters"],
            },
        })
    return out


OBJ = lambda props, req=None: {  # noqa: E731
    "type": "object",
    "properties": props,
    "required": req or [],
}
STR = lambda d="": {"type": "string", "description": d}          # noqa: E731
INT = lambda d="": {"type": "integer", "description": d}         # noqa: E731
NUM = lambda d="": {"type": "number", "description": d}          # noqa: E731
BOOL = lambda d="": {"type": "boolean", "description": d}        # noqa: E731
ARR = lambda items, d="": {"type": "array", "items": items, "description": d}  # noqa: E731


# ---------------------------------------------------------------- безопасность
DANGEROUS_PATTERNS = [
    r"\brd\s+/s\b", r"\bdel\s+/[sf]", r"\bformat\b\s+[a-z]:", r"\brmdir\s+/s",
    r"remove-item.*-recurse.*-force", r"del\s+[a-z]:\\", r"diskpart",
    r"\bshutdown\b", r"\brestart-computer\b", r"stop-computer",
    r"\breg\s+(delete|add)\b", r"\bbcdedit\b", r"\btakeown\b", r"\bicacls\b.*reset",
    r"\bcipher\s+/w\b", r"vssadmin\s+delete", r"wmic\s+.*delete",
    r"\brm\s+-rf\b", r"\bmkfs\b", r":\(\)\s*\{", r"\bsfc\b.*delete",
]


def is_dangerous(command: str) -> bool:
    c = (command or "").lower()
    return any(re.search(p, c) for p in DANGEROUS_PATTERNS)


ASK_USER = {"fn": None}  # подставляется главным модулем: fn(prompt)->str


_PY_CACHE = {"v": None}


def find_python() -> str | None:
    """FIX: в собранном FLUX.exe sys.executable указывает на сам FLUX.exe — запуск
    [sys.executable, script.py] перезапускал Флюкса с мусорными аргументами вместо
    выполнения кода. Ищем настоящий интерпретатор: venv рядом -> py -3 -> python."""
    if not getattr(sys, "frozen", False):
        return sys.executable or "python"
    if _PY_CACHE["v"]:
        return _PY_CACHE["v"]
    import shutil as _sh
    venv_py = ROOT / "venv" / "Scripts" / "python.exe"
    if venv_py.exists():
        _PY_CACHE["v"] = str(venv_py)
        return _PY_CACHE["v"]
    for name in ("python", "python3"):
        p = _sh.which(name)
        if p:
            _PY_CACHE["v"] = p
            return p
    if _sh.which("py"):
        _PY_CACHE["v"] = "py -3"
        return _PY_CACHE["v"]
    return None


def _py_cmd_list() -> list:
    """find_python() -> список argv (py -3 разбивается на два аргумента)."""
    p = find_python()
    if not p:
        return []
    return p.split() if " " in p else [p]


def ask(prompt: str, default: str = "н") -> str:
    fn = ASK_USER.get("fn")
    if fn:
        try:
            return fn(prompt)
        except Exception:
            pass
    return default


def confirm_action(desc: str) -> bool:
    """Подтверждение опасного действия. Вопрос уходит в главный поток (консоль/GUI/панель).
    В фоновом режиме без диалога — действие ОТКЛОНЯЕТСЯ (безопасно по умолчанию)."""
    if CFG.get("auto_approve_dangerous"):
        return True
    if not CFG.get("confirm_destructive", True):
        return True
    prompt = f"⚠ ОПАСНОЕ ДЕЙСТВИЕ: {desc}\n  Выполнить? (д/н):"
    ans = ask(prompt, "н")
    ok = str(ans).strip().lower() in ("д", "да", "y", "yes", "ok", "1", "true", "ага")
    if not ok:
        log.warning("отклонено пользователем: %s", desc[:200])
    return ok


def resolve_path(p: str, must_exist=False, base=None) -> Path:
    """Раскрывает ~, переменные %VAR%, относительные пути."""
    s = str(p or "").strip().strip('"').strip("'")
    if not s:
        return Path(base or Path.cwd())
    s = os.path.expandvars(s)
    if s.startswith("~"):
        s = str(Path.home() / s[1:].lstrip("/\\"))
    pp = Path(s)
    if not pp.is_absolute():
        base = Path(base) if base else None
        pp = (base / pp) if base else (Path.cwd() / pp)
    try:
        pp = pp.resolve()
    except Exception:
        pass
    return pp


def _file_info(p: Path) -> dict:
    try:
        st = p.stat()
        return {"name": p.name, "path": str(p), "is_dir": p.is_dir(),
                "size": st.st_size, "size_human": sizeof_fmt(st.st_size),
                "modified": human_time(st.st_mtime)}
    except Exception as e:
        return {"name": p.name, "path": str(p), "error": str(e)}


# ================================================================ ФАЙЛЫ
@tool("list_dir", "Показать содержимое папки (файлы и подпапки, размеры, даты). Используй для навигации по диску.",
      OBJ({"path": STR("Путь к папке. Пусто = текущая папка пользователя"),
           "recursive": BOOL("Обходить подпапки (осторожно, может быть медленно)"),
           "max_depth": INT("Глубина обхода при recursive (1-4)"),
           "pattern": STR("Фильтр по маске, например *.py или *отчёт*"),
           "limit": INT("Максимум строк в ответе (по умолчанию 300)")}, []))
def t_list_dir(args):
    base = resolve_path(args.get("path") or str(Path.home()))
    if not base.exists():
        return {"ok": False, "error": f"папка не найдена: {base}"}
    limit = int(args.get("limit") or 300)
    pattern = args.get("pattern") or "*"
    rows, dirs, files, total = [], 0, 0, 0
    if args.get("recursive"):
        depth = max(1, min(4, int(args.get("max_depth") or 2)))
        base_depth = len(base.parts)
        for p in base.rglob(pattern):
            if len(p.parts) - base_depth > depth:
                continue
            try:
                if p.is_dir():
                    dirs += 1
                    rows.append(f"[DIR ] {p}")
                else:
                    sz = p.stat().st_size
                    total += sz
                    files += 1
                    rows.append(f"{sizeof_fmt(sz):>10}  {dt.datetime.fromtimestamp(p.stat().st_mtime):%d.%m.%y %H:%M}  {p}")
            except Exception:
                continue
            if len(rows) >= limit:
                break
    else:
        try:
            entries = sorted(base.glob(pattern), key=lambda x: (not x.is_dir(), x.name.lower()))
        except Exception as e:
            return {"ok": False, "error": str(e)}
        for p in entries[:limit]:
            try:
                if p.is_dir():
                    dirs += 1
                    rows.append(f"[DIR ] {p.name}\\")
                else:
                    st = p.stat()
                    total += st.st_size
                    files += 1
                    rows.append(f"{sizeof_fmt(st.st_size):>10}  {dt.datetime.fromtimestamp(st.st_mtime):%d.%m.%y %H:%M}  {p.name}")
            except Exception:
                continue
    return {"ok": True, "path": str(base), "dirs": dirs, "files": files,
            "total_size": sizeof_fmt(total), "truncated": len(rows) >= limit,
            "listing": "\n".join(rows) if rows else "(пусто)"}


@tool("read_file", "Прочитать содержимое текстового файла (код, конфиг, лог, json, md, txt). Для картинок используй screen_capture/vision.",
      OBJ({"path": STR("Полный путь к файлу"),
           "encoding": STR("Кодировка, по умолчанию utf-8 (для Windows-блокнота попробуй cp1251)"),
           "start_line": INT("С какой строки начать (1-based)"),
           "max_chars": INT("Максимум символов в ответе (по умолчанию 16000)")}, ["path"]))
def t_read_file(args):
    p = resolve_path(args.get("path", ""))
    if not p.exists():
        return {"ok": False, "error": f"файл не найден: {p}"}
    if p.is_dir():
        return {"ok": False, "error": "это папка, используй list_dir"}
    enc = args.get("encoding") or "utf-8"
    maxc = int(args.get("max_chars") or 16000)
    try:
        raw = p.read_bytes()
    except Exception as e:
        return {"ok": False, "error": str(e)}
    try:
        text = raw.decode(enc, errors="replace")
    except LookupError:
        text = raw.decode("utf-8", errors="replace")
    start = max(0, int(args.get("start_line") or 1) - 1)
    if start:
        text = "\n".join(text.splitlines()[start:])
    lines = text.count("\n") + 1
    return {"ok": True, "path": str(p), "size": sizeof_fmt(len(raw)), "lines": lines,
            "truncated": len(text) > maxc, "content": truncate_middle(text, maxc)}


@tool("write_file", "Создать или полностью перезаписать файл с указанным содержимым (код, текст, конфиг, скрипт). Папки создаются автоматически.",
      OBJ({"path": STR("Полный путь файла, например D:\\Projects\\test.py"),
           "content": STR("Полное содержимое файла"),
           "encoding": STR("Кодировка (по умолчанию utf-8)"),
           "append": BOOL("true = дописать в конец вместо перезаписи"),
           "open_after": BOOL("Открыть файл после записи")}, ["path", "content"]))
def t_write_file(args):
    p = resolve_path(args.get("path", ""))
    if not str(args.get("path", "")).strip():
        return {"ok": False, "error": "не указан путь"}
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        enc = args.get("encoding") or "utf-8"
        content = str(args.get("content") or "")
        mode = "a" if args.get("append") else "w"
        with open(p, mode, encoding=enc, errors="replace", newline="\n") as f:
            f.write(content)
        res = {"ok": True, "path": str(p), "size": sizeof_fmt(p.stat().st_size),
               "chars": len(content), "mode": "append" if mode == "a" else "write"}
        if args.get("open_after"):
            res["opened"] = open_path(str(p))
        return res
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "trace": exc_text()[-800:]}


@tool("edit_file", "Точечно изменить файл: найти фрагмент и заменить его (лучше чем перезапись всего файла).",
      OBJ({"path": STR("Путь к файлу"),
           "old_text": STR("Фрагмент, который нужно найти (точно как в файле)"),
           "new_text": STR("Фрагмент для замены"),
           "replace_all": BOOL("Заменить все вхождения, а не только первое")}, ["path", "old_text", "new_text"]))
def _read_text_autodetect(p: Path) -> tuple[str, str]:
    """Читает текст, подбирая кодировку: utf-8 (строго) -> cp1251 -> utf-8 с заменами.
    Возвращает (текст, кодировка_для_записи)."""
    raw = p.read_bytes()
    for enc in ("utf-8", "cp1251"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace"), "utf-8"


def t_edit_file(args):
    p = resolve_path(args.get("path", ""))
    if not p.exists():
        return {"ok": False, "error": f"файл не найден: {p}"}
    try:
        # FIX: раньше файл читался utf-8 с errors="replace" и записывался обратно utf-8 —
        # правка любого cp1251/ANSI файла навсегда превращала кириллицу в ""
        text, enc_used = _read_text_autodetect(p)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    old = str(args.get("old_text") or "")
    new = str(args.get("new_text") or "")
    if old not in text:
        # мягкое сравнение по нормализованным пробелам
        norm = re.sub(r"[ \t]+", " ", text)
        if re.sub(r"[ \t]+", " ", old) not in norm:
            return {"ok": False, "error": "фрагмент не найден в файле",
                    "hint": "прочитай файл (read_file) и скопируй точный фрагмент"}
        return {"ok": False, "error": "фрагмент найден только после нормализации пробелов — уточни old_text"}
    cnt = text.count(old)
    text2 = text.replace(old, new) if args.get("replace_all") else text.replace(old, new, 1)
    p.write_text(text2, encoding=enc_used)
    return {"ok": True, "path": str(p), "encoding": enc_used, "occurrences": cnt,
            "replaced": cnt if args.get("replace_all") else 1}


@tool("search_files", "Найти файлы по имени/маске и по содержимому (grep). Работает по всему диску.",
      OBJ({"path": STR("Где искать (папка)"),
           "name_pattern": STR("Маска имени: *.py, *отчёт*, photo*"),
           "content": STR("Искать эту строку/регулярку внутри файлов"),
           "max_depth": INT("Глубина (1-8, по умолчанию 4)"),
           "limit": INT("Максимум результатов (по умолчанию 60)"),
           "modified_within_days": INT("Только файлы, изменённые за последние N дней")}, ["path"]))
def t_search_files(args):
    base = resolve_path(args.get("path") or str(Path.home()))
    if not base.exists():
        return {"ok": False, "error": f"папка не найдена: {base}"}
    name_pat = args.get("name_pattern") or "*"
    content = args.get("content")
    limit = int(args.get("limit") or 60)
    depth = max(1, min(8, int(args.get("max_depth") or 4)))
    within = args.get("modified_within_days")
    cutoff = (time.time() - float(within) * 86400) if within else None
    rx = None
    if content:
        try:
            rx = re.compile(content, re.I)
        except re.error:
            rx = re.compile(re.escape(content), re.I)
    hits, scanned = [], 0
    base_depth = len(base.parts)
    stack = [(base, 0)]
    while stack and len(hits) < limit:
        cur, d = stack.pop()
        if d > depth:
            continue
        try:
            entries = list(cur.iterdir())
        except Exception:
            continue
        for e in entries:
            try:
                if e.is_symlink():
                    continue
                if e.is_dir():
                    if e.name.lower() in ("node_modules", ".git", "__pycache__", "appdata",
                                          "windows", "$recycle.bin", "system volume information",
                                          ".venv", "venv", "dist", "build"):
                        continue
                    stack.append((e, d + 1))
                else:
                    scanned += 1
                    if cutoff and e.stat().st_mtime < cutoff:
                        continue
                    name_ok = e.match(name_pat) if name_pat and name_pat != "*" else True
                    if not name_ok:
                        continue
                    if rx:
                        if e.stat().st_size > 3_000_000:
                            continue
                        try:
                            txt = e.read_text(encoding="utf-8", errors="ignore")
                        except Exception:
                            continue
                        m = rx.search(txt)
                        if not m:
                            continue
                        s = max(0, m.start() - 60)
                        snippet = txt[s:m.end() + 90].replace("\n", " ")
                        hits.append(f"{e}  ->  ...{snippet.strip()}...")
                    else:
                        st = e.stat()
                        hits.append(f"{sizeof_fmt(st.st_size):>9}  {dt.datetime.fromtimestamp(st.st_mtime):%d.%m.%y}  {e}")
            except Exception:
                continue
    return {"ok": True, "base": str(base), "scanned": scanned, "found": len(hits),
            "truncated": len(hits) >= limit, "results": "\n".join(hits) if hits else "(ничего не найдено)"}


@tool("file_ops", "Операции с файлами и папками: копировать, переместить, удалить, переименовать, создать папку, информация, архивация.",
      OBJ({"action": {"type": "string", "enum": ["copy", "move", "delete", "rename", "mkdir",
                                                 "info", "exists", "zip", "unzip", "trash"],
                      "description": "Действие"},
           "path": STR("Источник / целевой файл или папка"),
           "dest": STR("Куда (для copy/move/rename/zip/unzip)"),
           "force": BOOL("Перезаписывать без спроса")}, ["action", "path"]))
def t_file_ops(args):
    act = str(args.get("action") or "").lower()
    src = resolve_path(args.get("path", ""))
    dest = resolve_path(args.get("dest", "")) if args.get("dest") else None
    try:
        if act == "exists":
            return {"ok": True, "exists": src.exists(), "path": str(src),
                    "is_dir": src.is_dir() if src.exists() else None}
        if act == "info":
            if not src.exists():
                return {"ok": False, "error": "не найдено"}
            if src.is_dir():
                n, sz = 0, 0
                for p in src.rglob("*"):
                    try:
                        if p.is_file():
                            n += 1; sz += p.stat().st_size
                    except Exception:
                        pass
                return {"ok": True, "path": str(src), "type": "dir", "files": n, "size": sizeof_fmt(sz)}
            st = src.stat()
            return {"ok": True, **_file_info(src), "mime": mime_of(str(src)),
                    "created": human_time(st.st_ctime), "bytes": st.st_size}
        if act == "mkdir":
            src.mkdir(parents=True, exist_ok=True)
            return {"ok": True, "created": str(src)}
        if act == "delete":
            if not src.exists():
                return {"ok": False, "error": "не найдено"}
            if not confirm_action(f"УДАЛЕНИЕ {src}"):
                return {"ok": False, "cancelled": True, "reason": "пользователь отказался"}
            if src.is_dir():
                shutil.rmtree(src, ignore_errors=True)
            else:
                os.remove(src)
            return {"ok": True, "deleted": str(src)}
        if act == "trash":
            if not src.exists():
                return {"ok": False, "error": "не найдено"}
            if IS_WIN:
                ps = f"""
$sh = New-Object -ComObject Shell.Application
$item = $sh.Namespace((Split-Path -Path '{str(src)}')).ParseName('{src.name}')
if ($item) {{ $item.InvokeVerb('delete'); 'ok' }} else {{ 'fail' }}
"""
                r = powershell(ps, timeout=30)
                return {"ok": r.get("code") == 0, "path": str(src), "out": (r.get("stdout") or "").strip()}
            return {"ok": False, "error": "trash поддерживается только в Windows"}
        if act == "copy":
            if not dest:
                return {"ok": False, "error": "нужен dest"}
            dest.parent.mkdir(parents=True, exist_ok=True)
            if src.is_dir():
                shutil.copytree(src, dest, dirs_exist_ok=True)
            else:
                shutil.copy2(src, dest)
            return {"ok": True, "from": str(src), "to": str(dest)}
        if act == "move" or act == "rename":
            if not dest:
                return {"ok": False, "error": "нужен dest"}
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src), str(dest))
            return {"ok": True, "from": str(src), "to": str(dest)}
        if act == "zip":
            out = dest or src.with_suffix(".zip")
            out.parent.mkdir(parents=True, exist_ok=True)
            base = shutil.make_archive(str(out.with_suffix("")), "zip",
                                       root_dir=str(src.parent if src.is_file() else src),
                                       base_dir=(src.name if src.is_file() else None))
            return {"ok": True, "archive": base, "size": sizeof_fmt(Path(base).stat().st_size)}
        if act == "unzip":
            out = dest or src.with_suffix("")
            out.mkdir(parents=True, exist_ok=True)
            shutil.unpack_archive(str(src), str(out))
            return {"ok": True, "extracted_to": str(out)}
        return {"ok": False, "error": f"неизвестное действие: {act}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ================================================================ СИСТЕМА
@tool("system_info", "Подробная информация о системе: ОС, CPU, RAM, диски, сеть, батарея, аптайм, температура, видеокарта.",
      OBJ({"section": {"type": "string", "enum": ["all", "cpu", "memory", "disk", "network",
                                                  "battery", "processes", "gpu", "boot"],
                      "description": "Какой раздел показать (по умолчанию all)"}}, []))
def t_system_info(args):
    sec = (args.get("section") or "all").lower()
    out = {}
    try:
        import psutil  # type: ignore
        have_ps = True
    except Exception:
        have_ps = False

    if have_ps:
        import psutil  # type: ignore
        if sec in ("all", "cpu"):
            out["cpu"] = {
                "percent": psutil.cpu_percent(interval=0.6),
                "cores_logical": psutil.cpu_count(),
                "cores_physical": psutil.cpu_count(logical=False),
                "freq_mhz": (psutil.cpu_freq().current if psutil.cpu_freq() else None),
                "loadavg": getattr(os, "getloadavg", lambda: (0, 0, 0))(),
            }
            try:
                temps = psutil.sensors_temperatures()
                if temps:
                    out["temperature"] = {k: [f"{t.label or k}:{t.current}C" for t in v][:4]
                                          for k, v in temps.items()}
            except Exception:
                pass
        if sec in ("all", "memory"):
            vm = psutil.virtual_memory()
            sw = psutil.swap_memory()
            out["memory"] = {"total": sizeof_fmt(vm.total), "used": sizeof_fmt(vm.used),
                             "available": sizeof_fmt(vm.available), "percent": vm.percent,
                             "swap_percent": sw.percent}
        if sec in ("all", "disk"):
            disks = []
            for part in psutil.disk_partitions(all=False):
                try:
                    u = psutil.disk_usage(part.mountpoint)
                    disks.append({"device": part.device, "mount": part.mountpoint,
                                  "fs": part.fstype, "total": sizeof_fmt(u.total),
                                  "free": sizeof_fmt(u.free), "free_percent": round(u.free * 100.0 / max(1, u.total), 1),
                                  "used_percent": u.percent})
                except Exception:
                    continue
            out["disks"] = disks
        if sec in ("all", "network"):
            n = psutil.net_io_counters()
            addrs = []
            for nic, alist in psutil.net_if_addrs().items():
                for a in alist:
                    if a.family.name in ("AF_INET",) and not a.address.startswith("127."):
                        addrs.append(f"{nic}: {a.address}")
            out["network"] = {"sent": sizeof_fmt(n.bytes_sent), "recv": sizeof_fmt(n.bytes_recv),
                              "ipv4": addrs[:6], "hostname": socket.gethostname()}
        if sec in ("all", "processes"):
            procs = []
            for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "username"]):
                try:
                    procs.append(p.info)
                except Exception:
                    continue
            procs.sort(key=lambda x: (x.get("memory_percent") or 0), reverse=True)
            out["top_processes"] = [f"{p.get('pid')} {p.get('name')} cpu={round(p.get('cpu_percent') or 0,1)}% mem={round(p.get('memory_percent') or 0,1)}%"
                                    for p in procs[:18]]
            out["process_count"] = len(procs)
        if sec in ("all", "battery"):
            try:
                b = psutil.sensors_battery()
                if b:
                    out["battery"] = {"percent": round(b.percent, 1), "plugged": b.power_plugged,
                                      "time_left_min": (None if b.secsleft in (psutil.POWER_TIME_UNLIMITED, psutil.POWER_TIME_UNKNOWN)
                                                        else round(b.secsleft / 60))}
                else:
                    out["battery"] = "нет батареи (стационарный ПК)"
            except Exception as e:
                out["battery"] = f"недоступно: {e}"
    else:
        # fallback: PowerShell CIM
        if sec in ("all", "cpu", "memory"):
            j = pwsh_json("""
$os = Get-CimInstance Win32_OperatingSystem
$cs = Get-CimInstance Win32_ComputerSystem
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
[pscustomobject]@{
  os = $os.Caption; version = $os.Version; build = $os.BuildNumber;
  ram_total_gb = [math]::Round($cs.TotalPhysicalMemory/1GB,1);
  ram_free_gb = [math]::Round($os.FreePhysicalMemory/1MB,1);
  cpu = $cpu.Name; cores = $cpu.NumberOfLogicalProcessors; cpu_load = $cpu.LoadPercentage;
  uptime_min = [math]::Round(((Get-Date) - $os.LastBootUpTime).TotalMinutes,0);
  user = $env:USERNAME; pc = $env:COMPUTERNAME
} | ConvertTo-Json -Compress
""", timeout=45)
            out["system"] = j or {"error": "нет psutil и PowerShell не ответил"}
        if sec in ("all", "disk"):
            j = pwsh_json("""
Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
 [pscustomobject]@{ drive=$_.DeviceID; total_gb=[math]::Round($_.Size/1GB,1);
 free_gb=[math]::Round($_.FreeSpace/1GB,1);
 free_percent=[math]::Round(($_.FreeSpace/[math]::Max(1,$_.Size))*100,1) }
} | ConvertTo-Json -Compress
""", timeout=45)
            out["disks"] = j or []
        if sec in ("all", "battery"):
            j = pwsh_json("""
$b = Get-CimInstance Win32_Battery
if ($b) { [pscustomobject]@{percent=$b.EstimatedChargeRemaining; status=$b.BatteryStatus} | ConvertTo-Json -Compress }
else { '"no battery"' }
""", timeout=30)
            out["battery"] = j or "нет батареи"
    if sec in ("all", "gpu"):
        j = pwsh_json("Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM,DriverVersion | ConvertTo-Json -Compress", timeout=30)
        out["gpu"] = j or "недоступно"
    if sec in ("all", "boot"):
        j = pwsh_json("""
$os = Get-CimInstance Win32_OperatingSystem
[pscustomobject]@{ boot=$os.LastBootUpTime.ToString('dd.MM.yyyy HH:mm');
 uptime_hours=[math]::Round(((Get-Date)-$os.LastBootUpTime).TotalHours,1) } | ConvertTo-Json -Compress
""", timeout=30)
        out["boot"] = j or {}
    if sec == "all":
        out["python"] = sys.version.split()[0]
        out["flux_root"] = str(ROOT)
        out["admin_rights"] = bool(os.environ.get("FLUX_ADMIN"))
        out["time"] = human_time()
    return {"ok": True, "section": sec, "data": out}


@tool("run_command", "Выполнить команду в cmd/PowerShell/batch. Полный доступ к системе: установка программ, winget, net, ipconfig, git, ffmpeg и т.д. ОПАСНЫЕ команды требуют подтверждения пользователя.",
      OBJ({"command": STR("Команда, например: winget list, ipconfig /all, dir D:\\, choco install ..."),
           "shell": {"type": "string", "enum": ["cmd", "powershell"], "description": "cmd (по умолчанию) или powershell"},
           "timeout_sec": INT("Таймаут в секундах (по умолчанию 120, макс 900)"),
           "cwd": STR("Рабочая папка"),
           "background": BOOL("true = запустить в фоне и не ждать результата")}, ["command"]))
def t_run_command(args):
    command = str(args.get("command") or "").strip()
    if not command:
        return {"ok": False, "error": "пустая команда"}
    shell_kind = (args.get("shell") or "cmd").lower()
    timeout = max(5, min(900, int(args.get("timeout_sec") or CFG.get("shell_timeout", 120))))
    cwd = resolve_path(args.get("cwd")) if args.get("cwd") else None
    danger = is_dangerous(command)
    if danger and not confirm_action(command):
        return {"ok": False, "cancelled": True, "reason": "пользователь отклонил опасную команду", "command": command}
    tools_log.info("run_command[%s] %s", shell_kind, command[:500])
    if args.get("background"):
        # FIX: раньше команда передавалась в start_program, который считает её ФАЙЛОМ —
        # «notepad++ x.txt» или «echo hi» как background не работали.
        # Теперь — честный detached-процесс нужного шелла.
        try:
            flags = 0x08000000 | 0x00000008 if IS_WIN else 0   # CREATE_NO_WINDOW | DETACHED_PROCESS
            if shell_kind == "powershell":
                argv = ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                        "-Command", command]
            else:
                argv = (["cmd", "/c", command] if IS_WIN else ["/bin/sh", "-c", command])
            p = subprocess.Popen(argv, cwd=str(cwd) if cwd else None,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 stdin=subprocess.DEVNULL, creationflags=flags)
            tools_log.info("run_command[bg] %s pid=%s", command[:300], p.pid)
            return {"ok": True, "background": True, "pid": p.pid, "command": command,
                    "shell": shell_kind, "note": "результат не контролируется — команда работает в фоне"}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}", "command": command}
    if shell_kind == "powershell":
        r = powershell(command, timeout=timeout)
    else:
        r = cmd_run(command, timeout=timeout, cwd=str(cwd) if cwd else None)
    r["command"] = command
    r["dangerous"] = danger
    return r


@tool("run_python", "Выполнить произвольный Python-код (свой код, вычисления, парсинг, автоматизация). Доступны стандартная библиотека + установленные пакеты. Работает в фоне, если background=true.",
      OBJ({"code": STR("Python-код. Результат печатай через print()"),
           "timeout_sec": INT("Таймаут (по умолчанию 120)"),
           "cwd": STR("Рабочая папка"),
           "save_as": STR("Сохранить код в файл (например calc.py) и запустить его"),
           "background": BOOL("Запустить в фоне без ожидания")}, ["code"]))
def t_run_python(args):
    code = str(args.get("code") or "")
    if not code.strip():
        return {"ok": False, "error": "пустой код"}
    timeout = max(5, min(900, int(args.get("timeout_sec") or CFG.get("python_timeout", 120))))
    cwd = resolve_path(args.get("cwd")) if args.get("cwd") else SANDBOX_DIR
    cwd.mkdir(parents=True, exist_ok=True)
    fname = safe_filename(args.get("save_as") or f"flux_py_{int(time.time())}.py")
    if not fname.endswith(".py"):
        fname += ".py"
    script = cwd / fname
    header = "# -*- coding: utf-8 -*-\n# Flux auto-generated script\nimport sys, io\ntry:\n    sys.stdout.reconfigure(encoding='utf-8', errors='replace')\nexcept Exception:\n    pass\n"
    try:
        script.write_text(header + code, encoding="utf-8")
    except Exception as e:
        return {"ok": False, "error": f"не удалось сохранить скрипт: {e}"}
    pylist = _py_cmd_list()
    if not pylist:
        return {"ok": False, "error": "не найден интерпретатор Python для запуска кода "
                                     "(в EXE-режиме нужен отдельный Python в системе)",
                "hint": "установи Python 3.10+ с python.org (галочка Add to PATH) или создай venv рядом с FLUX.exe",
                "script": str(script)}
    if args.get("background"):
        if IS_WIN:
            subprocess.Popen(pylist + [str(script)], cwd=str(cwd), creationflags=0x08000000,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            subprocess.Popen(pylist + [str(script)], cwd=str(cwd),
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return {"ok": True, "background": True, "script": str(script)}
    r = run(pylist + ["-X", "utf8", str(script)], timeout=timeout, cwd=str(cwd))
    r["script"] = str(script)
    tools_log.info("run_python %s -> code=%s", script.name, r.get("code"))
    return r


@tool("create_app", "СОЗДАТЬ ПРОГРАММУ НА ЛЕТУ: генерирует готовое приложение (python-скрипт, .bat, .vbs, HTML-страницу, ярлык) в папке Flux\\data\\apps и может сразу запустить его — в том числе в фоновом режиме.",
      OBJ({"name": STR("Имя программы, например 'Калькулятор' или 'my_tool'"),
           "kind": {"type": "string", "enum": ["python", "pythonw", "batch", "vbs", "html", "shortcut", "service_task"],
                    "description": "python=консоль, pythonw=без окна (фон), batch=.bat, vbs=невидимый фон, html=страница, shortcut=ярлык, service_task=задача в планировщике Windows"},
           "content": STR("Код/содержимое программы"),
           "run_now": BOOL("Запустить сразу после создания"),
           "background": BOOL("Запустить в фоновом режиме (без окна)"),
           "target": STR("Для shortcut/service_task: что запускать (путь или команда)"),
           "startup": BOOL("Для service_task: запускать при входе в Windows"),
           "description": STR("Описание программы")}, ["name", "kind", "content"]))
def t_create_app(args):
    name = safe_filename(args.get("name") or ("app_" + str(int(time.time()))))
    kind = (args.get("kind") or "python").lower()
    content = str(args.get("content") or "")
    folder = APPS_DIR / name
    folder.mkdir(parents=True, exist_ok=True)
    ext = {"python": ".py", "pythonw": ".py", "batch": ".bat", "vbs": ".vbs",
           "html": ".html", "shortcut": ".lnk", "service_task": ".xml"}.get(kind, ".txt")
    main = folder / (name + ext)
    try:
        if kind == "shortcut":
            target = str(args.get("target") or "")
            if not target:
                return {"ok": False, "error": "для shortcut нужен target"}
            lnk = folder / (name + ".lnk")
            # FIX: одинарные кавычки в путях ломали скрипт (и позволяли PS-инъекции)
            t_esc = target.replace("'", "''")
            f_esc = str(folder).replace("'", "''")
            ps = f"""
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut('{str(lnk).replace("'", "''")}')
$sc.TargetPath = '{t_esc}'
$sc.WorkingDirectory = '{f_esc}'
$sc.Description = '{str(args.get('description') or name).replace("'", "''")}'
$sc.Save(); 'ok'
"""
            r = powershell(ps, timeout=30)
            main = lnk
            created = {"ok": r.get("code") == 0, "path": str(lnk), "target": target}
        elif kind == "service_task":
            pyf = find_python() or "python"
            target = str(args.get("target") or f'"{pyf}" "{main}"')
            task_name = f"Flux_{name}"
            startup = "/SC ONLOGON " if args.get("startup") else "/SC ONCE /ST 00:00 "
            r = cmd_run(f'schtasks /Create /TN "{task_name}" /TR "{target}" {startup}/F')
            created = {"ok": r.get("code") == 0, "task": task_name, "detail": clip(r.get("stdout") or r.get("stderr"), 400)}
        else:
            if kind in ("python", "pythonw") and not content.strip():
                return {"ok": False, "error": "нужен content с кодом"}
            main.write_text(content, encoding="utf-8")
            launcher = folder / f"запустить_{name}.bat"
            if kind in ("python", "pythonw"):
                # FIX: в EXE-сборке sys.executable = FLUX.exe — лаунчер перезапускал
                # самого Флюкса вместо созданной программы
                pyq = find_python()
                if not pyq or pyq == "py -3":
                    pybat = "py -3"          # лаунчер через системный py-launcher
                else:
                    pybat = f'"{pyq}"'       # путь (возможно с пробелами) — в кавычках
                launcher.write_text("@echo off\r\nchcp 65001 >nul\r\n"
                                    f'{pybat} "{main}"\r\n'
                                    "if errorlevel 1 pause\r\n", encoding="utf-8")
            else:
                launcher.write_text(f'@echo off\r\nstart "" "{main}"\r\n', encoding="utf-8")
            created = {"ok": True, "path": str(main), "launcher": str(launcher),
                       "size": sizeof_fmt(main.stat().st_size)}
        result = {"ok": bool(created.get("ok")), "app": name, "kind": kind, "folder": str(folder), **created}
        if args.get("run_now") and result.get("ok"):
            result["run"] = t_start_program({
                "program": str(main),
                "background": bool(args.get("background")),
                "shell": "cmd",
            })
        return result
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "trace": exc_text()[-700:]}


@tool("start_program", "Запустить программу, файл, папку или сайт. Умеет искать приложения в меню Пуск по имени, запускать в фоновом режиме и от имени администратора.",
      OBJ({"program": STR("Имя или путь: 'блокнот', 'chrome', 'C:\\Windows\\notepad.exe', 'D:\\files', 'https://...'"),
           "args": STR("Аргументы запуска"),
           "background": BOOL("Запустить без окна (в фоне)"),
           "as_admin": BOOL("От имени администратора (появится UAC)"),
           "cwd": STR("Рабочая папка"),
           "shell": {"type": "string", "enum": ["cmd", "powershell", "auto"], "description": "auto = по расширению"}}, ["program"]))
def t_start_program(args):
    prog = str(args.get("program") or "").strip()
    if not prog:
        return {"ok": False, "error": "не указано что запускать"}
    extra = str(args.get("args") or "").strip()
    background = bool(args.get("background"))
    as_admin = bool(args.get("as_admin"))
    cwd = str(resolve_path(args.get("cwd"))) if args.get("cwd") else None

    # URL
    if re.match(r"^https?://", prog, re.I) or re.match(r"^[a-z]+://", prog, re.I):
        open_path(prog)
        return {"ok": True, "opened_url": prog}

    p = resolve_path(prog)
    target = None
    if p.exists():
        target = str(p)
    else:
        # поиск по меню Пуск / PATH
        found = find_app(prog)
        if found:
            target = found
        else:
            # может это команда типа "notepad" или "calc"
            target = prog
    tools_log.info("start_program %s (bg=%s admin=%s)", target, background, as_admin)
    # FIX: одинарные кавычки/спецсимволы в путях и аргументах ломали PS-скрипт
    # (и позволяли инъекции команд) — экранируем по правилам PowerShell
    t_q = str(target).replace("'", "''")
    e_q = extra.replace("'", "''")
    c_q = (cwd or "").replace("'", "''")
    try:
        if IS_WIN:
            if as_admin:
                ps = f"""
$ErrorActionPreference='Stop'
$p = Start-Process -FilePath '{t_q}' -ArgumentList '{e_q}' -Verb RunAs -PassThru
[pscustomobject]@{{pid=$p.Id}} | ConvertTo-Json -Compress
"""
                r = powershell(ps, timeout=90)
                return {"ok": r.get("code") == 0, "target": target, "as_admin": True,
                        "detail": clip((r.get("stdout") or r.get("stderr") or ""), 300)}
            verb = "Hidden" if background else "Normal"
            ps = f"""
$ErrorActionPreference='Stop'
$psi = @{{ FilePath = '{t_q}'; WindowStyle = '{verb}' }}
if ('{e_q}') {{ $psi.ArgumentList = '{e_q}' }}
if ('{c_q}') {{ $psi.WorkingDirectory = '{c_q}' }}
$p = Start-Process @psi -PassThru
[pscustomobject]@{{ pid = $p.Id; name = $p.ProcessName }} | ConvertTo-Json -Compress
"""
            r = powershell(ps, timeout=60)
            if r.get("code") == 0:
                return {"ok": True, "target": target, "background": background,
                        "detail": (r.get("stdout") or "").strip()}
            # запасной вариант через cmd start
            r2 = cmd_run(f'start {" /min " if background else ""}"" "{target}" {extra}', timeout=30, cwd=cwd)
            return {"ok": r2.get("code") == 0, "target": target, "via": "cmd start",
                    "detail": clip(r2.get("stdout") or r2.get("stderr"), 300)}
        else:
            cmdl = shlex.split(target) + shlex.split(extra)
            subprocess.Popen(cmdl, cwd=cwd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return {"ok": True, "target": target}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "target": target,
                "hint": "проверь точное имя/путь; используй find_app для поиска"}


_APP_CACHE = {"ts": 0.0, "items": []}


def find_app(query: str) -> str | None:
    """Ищет приложение в меню Пуск / Program Files / PATH по нечёткому имени."""
    q = (query or "").strip().lower().replace(".exe", "")
    if not q:
        return None
    if time.time() - _APP_CACHE["ts"] > 900:
        items = []
        roots = [os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs"),
                 os.path.join(os.environ.get("ProgramData", "C:\\ProgramData"),
                              r"Microsoft\Windows\Start Menu\Programs"),
                 os.environ.get("ProgramFiles", r"C:\Program Files"),
                 os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                 os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs")]
        for root in roots:
            if not root or not os.path.isdir(root):
                continue
            for pat in ("**/*.lnk", "**/*.exe"):
                try:
                    for f in glob.glob(os.path.join(root, pat), recursive=True):
                        items.append(f)
                        if len(items) > 4000:
                            break
                except Exception:
                    continue
        # PATH
        for d in os.environ.get("PATH", "").split(os.pathsep):
            try:
                for f in glob.glob(os.path.join(d, "*.exe")):
                    items.append(f)
            except Exception:
                continue
        _APP_CACHE["items"] = items
        _APP_CACHE["ts"] = time.time()
    best, best_score = None, 0
    for it in _APP_CACHE["items"]:
        name = os.path.basename(it).lower()
        score = 0
        if name == q or name == q + ".lnk" or name == q + ".exe":
            score = 100
        elif name.startswith(q):
            score = 70
        elif q in name:
            score = 55
        else:
            continue
        if score > best_score:
            best, best_score = it, score
    return best


@tool("find_app", "Найти установленную программу по названию (меню Пуск, Program Files, PATH). Возвращает путь, чтобы потом запустить.",
      OBJ({"query": STR("Название программы: chrome, steam, photoshop, блокнот...")}, ["query"]))
def t_find_app(args):
    q = str(args.get("query") or "")
    hits = []
    ql = q.lower()
    if time.time() - _APP_CACHE["ts"] > 900:
        find_app(q)  # прогрев кэша
    for it in _APP_CACHE["items"]:
        n = os.path.basename(it).lower()
        if ql in n:
            hits.append(it)
        if len(hits) >= 25:
            break
    return {"ok": True, "query": q, "found": len(hits),
            "results": "\n".join(hits) if hits else "ничего не найдено — попробуй другое название",
            "hint": "запусти через start_program с полным путём"}


@tool("process_list", "Список запущенных процессов: кто ест CPU/память, окна, службы. Можно фильтровать и сортировать.",
      OBJ({"filter": STR("Фильтр по имени (например chrome)"),
           "sort_by": {"type": "string", "enum": ["memory", "cpu", "name"], "description": "Сортировка"},
           "limit": INT("Сколько показать (по умолчанию 25)"),
           "windows_only": BOOL("Только процессы с видимыми окнами")}, []))
def t_process_list(args):
    limit = int(args.get("limit") or 25)
    flt = (args.get("filter") or "").lower()
    sort_by = args.get("sort_by") or "memory"
    rows = []
    try:
        import psutil  # type: ignore
        for p in psutil.process_iter(["pid", "name", "username", "cpu_percent", "memory_percent",
                                      "memory_info", "create_time", "status"]):
            try:
                i = p.info
                if flt and flt not in (i.get("name") or "").lower():
                    continue
                rows.append({
                    "pid": i.get("pid"), "name": i.get("name"), "user": i.get("username"),
                    "cpu": round(i.get("cpu_percent") or 0, 1),
                    "mem_percent": round(i.get("memory_percent") or 0, 2),
                    "mem": sizeof_fmt((i.get("memory_info").rss if i.get("memory_info") else 0)),
                    "status": i.get("status"),
                    "started": human_time(i.get("create_time")) if i.get("create_time") else "",
                })
            except Exception:
                continue
    except Exception:
        r = cmd_run("tasklist /FO CSV /NH", timeout=45)
        for line in (r.get("stdout") or "").splitlines():
            parts = [x.strip('"') for x in line.split('","')]
            if len(parts) >= 5:
                if flt and flt not in parts[0].lower():
                    continue
                rows.append({"name": parts[0], "pid": parts[1], "mem": parts[4]})
    key = {"memory": lambda x: x.get("mem_percent") or 0, "cpu": lambda x: x.get("cpu") or 0,
           "name": lambda x: (x.get("name") or "").lower()}[sort_by]
    rows.sort(key=key, reverse=(sort_by != "name"))
    return {"ok": True, "total": len(rows), "shown": min(limit, len(rows)),
            "processes": rows[:limit]}


@tool("process_kill", "Завершить процесс по PID или имени (закрыть зависшую программу).",
      OBJ({"pid": INT("PID процесса"),
           "name": STR("Имя процесса, например chrome.exe (закроет ВСЕ такие процессы)"),
           "force": BOOL("Принудительно (/F)")}, []), dangerous=True)
def t_process_kill(args):
    pid = args.get("pid")
    name = args.get("name")
    if not pid and not name:
        return {"ok": False, "error": "нужен pid или name"}
    what = f"PID {pid}" if pid else f"процесс {name}"
    if not confirm_action(f"завершить {what}"):
        return {"ok": False, "cancelled": True}
    if pid:
        cmd = f'taskkill {" /F" if args.get("force") else ""} /PID {int(pid)}'
    else:
        # FIX: имя не должно содержать кавычек/спецсимволов cmd
        nm = re.sub(r'["\'&|<>^%]', "", str(name))[:80]
        cmd = f'taskkill {" /F" if args.get("force") else ""} /IM "{nm}"'
    r = cmd_run(cmd, timeout=30)
    return {"ok": r.get("code") == 0, "command": cmd,
            "detail": clip((r.get("stdout") or "") + (r.get("stderr") or ""), 500)}


@tool("system_control", "Управление компьютером: громкость, яркость, микрофон, медиа-клавиши, монитор, блокировка, сон, перезагрузка, выключение, режим не беспокоить.",
      OBJ({"action": {"type": "string", "enum": [
          "volume_set", "volume_up", "volume_down", "mute", "unmute",
          "brightness_set", "brightness_up", "brightness_down",
          "mic_mute", "mic_unmute",
          "play_pause", "next_track", "prev_track", "stop_media",
          "monitor_off", "lock", "sleep", "hibernate", "restart", "shutdown", "cancel_shutdown",
          "shutdown_in", "shutdown_at",
          "empty_recycle_bin", "show_desktop", "eject"], "description": "Действие"},
          "value": NUM("Значение: громкость/яркость 0-100; для shutdown_in — СЕКУНДЫ; для shutdown_at — 'HH:MM'"),
          "delay_sec": INT("Задержка перед shutdown/restart (сек)")}, ["action"]))
def t_system_control(args):
    act = str(args.get("action") or "").lower()
    val = args.get("value")
    DANGER = {"restart", "shutdown", "hibernate", "sleep", "empty_recycle_bin", "monitor_off",
              "shutdown_in", "shutdown_at"}
    if act in DANGER and act != "monitor_off":
        if not confirm_action(f"системное действие: {act}"):
            return {"ok": False, "cancelled": True}
    try:
        if act.startswith("volume") or act in ("mute", "unmute"):
            return _volume(act, val)
        if act.startswith("brightness"):
            return _brightness(act, val)
        if act in ("mic_mute", "mic_unmute"):
            # VK_VOLUME_MUTE для микрофона в Windows 10/11: SendKeys-эквивалент через keybd_event
            vk = 0x91 if False else 0xAD  # 0xAD = VK_VOLUME_MUTE (гарнитуры/микрофоны с кнопкой)
            ps = f"""
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class MK{{[DllImport("user32.dll")]public static extern void keybd_event(byte b,byte s,uint f,UIntPtr e);}}'
[MK]::keybd_event({vk},0,0,[UIntPtr]::Zero); [MK]::keybd_event({vk},0,2,[UIntPtr]::Zero)
'done'
"""
            r = powershell(ps, timeout=20)
            state = "выключен" if act == "mic_mute" else "включён"
            return {"ok": r.get("code") == 0, "action": act,
                    "note": f"микрофон/звук: {state} (системная клавиша mute)",
                    "hint": "точный mute конкретного микрофона делается в Параметры -> Система -> Звук",
                    "detail": clip(r.get("stderr") or "", 200)}
        if act in ("play_pause", "next_track", "prev_track", "stop_media"):
            key = {"play_pause": "173", "next_track": "176", "prev_track": "177", "stop_media": "178"}[act]
            ps = f"""
$w = New-Object -ComObject WScript.Shell
$w.SendKeys([char]{key})
"""
            # используем VK через user32 для надёжности
            vk = {"play_pause": 0xB3, "next_track": 0xB0, "prev_track": 0xB1, "stop_media": 0xB2}[act]
            ps = f"""
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class K{{[DllImport("user32.dll")]public static extern void keybd_event(byte b,byte s,uint f,UIntPtr e);}}'
[K]::keybd_event({vk},0,0,[UIntPtr]::Zero); [K]::keybd_event({vk},0,2,[UIntPtr]::Zero)
'ok'
"""
            r = powershell(ps, timeout=20)
            return {"ok": r.get("code") == 0, "action": act}
        if act == "monitor_off":
            ps = """
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class M{[DllImport("user32.dll")]public static extern int SendMessage(int h,int m,int w,int l);}'
[M]::SendMessage(-1,0x0112,0xF170,2)
"""
            powershell(ps, timeout=15)
            return {"ok": True, "action": "монитор выключен (шевельни мышью чтобы включить)"}
        if act == "show_desktop":
            powershell("$w=New-Object -ComObject Shell.Application; $w.MinimizeAll()", timeout=15)
            return {"ok": True}
        if act == "lock":
            cmd_run("rundll32.exe user32.dll,LockWorkStation", timeout=15)
            return {"ok": True, "action": "заблокировано"}
        if act == "sleep":
            r = cmd_run("rundll32.exe powrprof.dll,SetSuspendState 0,1,0", timeout=30)
            return {"ok": r.get("code") == 0, "action": "сон"}
        if act == "hibernate":
            r = cmd_run("shutdown /h", timeout=30)
            return {"ok": r.get("code") == 0, "action": "гибернация"}
        if act in ("restart", "shutdown"):
            delay = int(args.get("delay_sec") or 15)
            flag = "/r" if act == "restart" else "/s"
            r = cmd_run(f"shutdown {flag} /t {delay} /c \"Flux: {act} через {delay} сек\"", timeout=30)
            return {"ok": r.get("code") == 0, "action": act, "delay_sec": delay,
                    "hint": "отменить: system_control cancel_shutdown"}
        if act == "shutdown_in":
            # v2.0.6: таймер выключения ПК («выключи комп через 2 часа»)
            sec = max(0, min(315360000, int(float(val or 0))))
            if sec <= 0:
                return {"ok": False, "error": "укажи value в секундах (например 7200 = 2 часа)"}
            if not confirm_action(f"выключение ПК через {sec} сек"):
                return {"ok": False, "cancelled": True}
            r = cmd_run(f'sutdown /s /t {sec} /c "Flux: выключение через {sec // 60} мин"', timeout=30)
            return {"ok": r.get("code") == 0, "action": "shutdown_in", "seconds": sec,
                    "fires_in_min": round(sec / 60, 1),
                    "hint": "отмена: system_control cancel_shutdown или скажи «отмени выключение»"}
        if act == "shutdown_at":
            # v2.0.6: выключение в заданное время («выключи комп в 23:30»)
            m = re.fullmatch(r"(\d{1,2})[:.](\d{2})", str(val or "").strip())
            if not m:
                return {"ok": False, "error": "формат value: 'HH:MM', например '23:30'"}
            hh, mi = int(m.group(1)), int(m.group(2))
            if hh > 23 or mi > 59:
                return {"ok": False, "error": "некорректное время"}
            now_dt = dt.datetime.now()
            target = now_dt.replace(hour=hh, minute=mi, second=0, microsecond=0)
            sec = int((target - now_dt).total_seconds())
            if sec <= 0:
                sec += 86400   # время уже прошло сегодня -> завтра
            if not confirm_action(f"выключение ПК в {hh:02d}:{mi:02d} (через {sec // 60} мин)"):
                return {"ok": False, "cancelled": True}
            r = cmd_run(f'sutdown /s /t {sec} /c "Flux: выключение в {hh:02d}:{mi:02d}"', timeout=30)
            return {"ok": r.get("code") == 0, "action": "shutdown_at", "at": f"{hh:02d}:{mi:02d}",
                    "seconds": sec, "hint": "отмена: «отмени выключение»"}
        if act == "cancel_shutdown":
            r = cmd_run("shutdown /a", timeout=20)
            return {"ok": r.get("code") == 0, "action": "выключение отменено",
                    "detail": clip((r.get("stdout") or r.get("stderr")), 300)}
        if act == "empty_recycle_bin":
            ps = "Clear-RecycleBin -Force -ErrorAction SilentlyContinue; 'ok'"
            r = powershell(ps, timeout=60)
            return {"ok": r.get("code") == 0, "action": "корзина очищена"}
        if act == "eject":
            ps = """
$sh = New-Object -ComObject Shell.Application
$sh.Namespace(17).Items() | Where-Object { $_.Type -eq 'CD Drive' -or $_.IsLink -eq $false } | ForEach-Object { $_.InvokeVerb('Eject') }
'ok'
"""
            r = powershell(ps, timeout=30)
            return {"ok": True, "detail": clip(r.get("stdout") or r.get("stderr"), 200)}
        return {"ok": False, "error": f"неизвестное действие {act}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _volume(act: str, val) -> dict:
    """Громкость через nircmd / PowerShell AudioEndpointVolume."""
    if val is not None:
        val = max(0, min(100, int(float(val))))
    ps_common = """
Add-Type -TypeDefinition @'
using System;using System.Runtime.InteropServices;
[Guid("5CDF2C82-841E-4546-9722-0CF74078229A"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioEndpointVolume {
 int f(); int g(); int h(); int i();
 int SetMasterVolumeLevelScalar(float fLevel, System.Guid pguidEventContext);
 int j(); int GetMasterVolumeLevelScalar(out float pfLevel);
 int k(); int l(); int m(); int n();
 int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, System.Guid pguidEventContext);
 int GetMute(out bool pbMute);
}
[Guid("D666063F-1587-4E43-81F1-B948E807363F"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDevice { int Activate(ref System.Guid id, int clsCtx, int activationParams, out IAudioEndpointVolume aev); }
[Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDeviceEnumerator { int f(); int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint); }
[ComImport,Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumeratorComObject { }
public class Audio {
 static IAudioEndpointVolume Vol() {
  var e = (IMMDeviceEnumerator)(new MMDeviceEnumeratorComObject());
  IMMDevice dev; e.GetDefaultAudioEndpoint(0,1,out dev);
  var iid = typeof(IAudioEndpointVolume).GUID; IAudioEndpointVolume v;
  dev.Activate(ref iid,1,0,out v); return v;
 }
 public static float Get() { float v; Vol().GetMasterVolumeLevelScalar(out v); return v*100; }
 public static void Set(float p) { Vol().SetMasterVolumeLevelScalar(p/100f, Guid.Empty); }
 public static bool GetMute() { bool m; Vol().GetMute(out m); return m; }
 public static void SetMute(bool m) { Vol().SetMute(m, Guid.Empty); }
}
'@
"""
    if act == "volume_set" and val is not None:
        r = powershell(ps_common + f"[Audio]::Set({val}); [Audio]::Get()", timeout=40)
        return {"ok": r.get("code") == 0, "action": act, "value": val,
                "now_percent": (r.get("stdout") or "").strip()}
    if act in ("volume_up", "volume_down"):
        delta = int(val or 10)
        op = "+" if act == "volume_up" else "-"
        r = powershell(ps_common + f"$c=[Audio]::Get(); $n=[Math]::Max(0,[Math]::Min(100,$c{op}{delta})); [Audio]::Set($n); $n", timeout=40)
        return {"ok": r.get("code") == 0, "action": act, "now_percent": (r.get("stdout") or "").strip()}
    if act in ("mute", "unmute"):
        m = "true" if act == "mute" else "false"
        r = powershell(ps_common + f"[Audio]::SetMute({m}); 'ok'", timeout=40)
        return {"ok": r.get("code") == 0, "action": act}
    return {"ok": False, "error": "не понял действие с громкостью"}


def _brightness(act: str, val) -> dict:
    if act == "brightness_set" and val is not None:
        v = max(0, min(100, int(float(val))))
        ps = f"""
$m = Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightnessMethods -ErrorAction SilentlyContinue
if ($m) {{ Invoke-CimMethod -InputObject $m -MethodName WmiSetBrightness -Arguments @{{Timeout=1;Brightness={v}}} ; 'set {v}' }}
else {{ 'no wmi brightness (внешний монитор?)' }}
"""
        r = powershell(ps, timeout=30)
        return {"ok": True, "value": v, "detail": (r.get("stdout") or r.get("stderr") or "").strip()}
    step = int(val or 10)
    op = "+" if act == "brightness_up" else "-"
    ps = f"""
$b = (Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightness -ErrorAction SilentlyContinue).CurrentBrightness
if ($b -ne $null) {{
  $n = [Math]::Max(0,[Math]::Min(100, $b {op} {step}))
  $m = Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightnessMethods
  Invoke-CimMethod -InputObject $m -MethodName WmiSetBrightness -Arguments @{{Timeout=1;Brightness=$n}}
  "was $b now $n"
}} else {{ 'no wmi brightness' }}
"""
    r = powershell(ps, timeout=30)
    return {"ok": True, "action": act, "detail": (r.get("stdout") or r.get("stderr") or "").strip()}


# ================================================================ ЭКРАН / ЗВУК
@tool("screen_capture", "Сделать скриншот экрана (или области) и СРАЗУ посмотреть его (модель с vision проанализирует изображение). Может распознать текст (OCR) и найти, что сейчас на экране.",
      OBJ({"monitor": INT("Номер монитора: 0 = все экраны, 1 = первый (по умолчанию 0)"),
           "region": STR("Область 'x,y,w,h' в пикселях (необязательно)"),
           "ocr": BOOL("Распознать текст на скриншоте (нужен tesseract, иначе пропустит)"),
           "analyze": BOOL("true = вернуть изображение модели для анализа (по умолчанию true)"),
           "save_as": STR("Имя файла для сохранения (по умолчанию авто)")}, []))
def t_screen_capture(args):
    mon = int(args.get("monitor") or 0)
    save_as = safe_filename(args.get("save_as") or f"shot_{dt.datetime.now():%Y%m%d_%H%M%S}.png")
    if not save_as.lower().endswith((".png", ".jpg")):
        save_as += ".png"
    out = SCREEN_DIR / save_as
    ok, how = False, ""
    # 1) mss
    try:
        import mss  # type: ignore
        with mss.mss() as sct:
            region = args.get("region")
            if region:
                x, y, w, h = [int(v) for v in str(region).split(",")]
                monitor = {"left": x, "top": y, "width": w, "height": h}
            else:
                monitor = sct.monitors[mon] if mon < len(sct.monitors) else sct.monitors[0]
            img = sct.grab(monitor)
            try:
                from PIL import Image  # type: ignore
                Image.frombytes("RGB", img.size, img.bgra, "raw", "BGRX").save(str(out))
            except Exception:
                import mss.tools as mt  # type: ignore
                mt.to_png(img.rgb, img.size, output=str(out))
            ok, how = True, "mss"
    except Exception as e:
        log.debug("mss fail: %s", e)
    # 2) PowerShell + System.Drawing
    if not ok and IS_WIN:
        ps = f"""
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$bounds = [System.Windows.Forms.Screen]::AllBounds
$rect = if ({mon} -gt 0 -and {mon} -le $bounds.Count) {{ $bounds[{mon}-1] }} else {{ [System.Windows.Forms.SystemInformation]::VirtualScreen }}
$bmp = New-Object System.Drawing.Bitmap $rect.Width, $rect.Height
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($rect.Left, $rect.Top, 0, 0, $bmp.Size)
$bmp.Save('{out}', [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose()
'ok'
"""
        r = powershell(ps, timeout=45)
        ok = out.exists() and out.stat().st_size > 1000
        how = "powershell"
    if not ok:
        return {"ok": False, "error": "не удалось сделать скриншот",
                "hint": "установи: pip install mss pillow"}
    res = {"ok": True, "path": str(out), "size": sizeof_fmt(out.stat().st_size), "engine": how,
           "time": human_time()}
    if args.get("ocr"):
        txt = ocr_image(str(out))
        if txt:
            res["ocr_text"] = clip(txt, 5000)
        else:
            res["ocr_note"] = "tesseract не установлен — OCR недоступен (pip install pytesseract + установщик tesseract)"
    if args.get("analyze", True):
        b64 = file_to_base64(str(out))
        if b64:
            res["_image_b64"] = b64
            res["_image_mime"] = "image/png"
    return res


def ocr_image(path: str) -> str:
    try:
        import pytesseract  # type: ignore
        from PIL import Image  # type: ignore
        return pytesseract.image_to_string(Image.open(path), lang="rus+eng")
    except Exception as e:
        log.debug("ocr: %s", e)
        return ""


@tool("screen_read", "Прочитать текст/OCR с экрана или из картинки: что написано в окне, ошибки, цены, код на скриншоте.",
      OBJ({"path": STR("Путь к картинке (если пусто — сделать свежий скриншот)"),
           "lang": STR("Языки OCR: 'rus+eng' по умолчанию")}, []))
def t_screen_read(args):
    p = args.get("path")
    if not p:
        shot = t_screen_capture({"analyze": False, "ocr": False})
        if not shot.get("ok"):
            return shot
        p = shot["path"]
    p = str(resolve_path(p))
    if not Path(p).exists():
        return {"ok": False, "error": f"картинка не найдена: {p}"}
    txt = ""
    try:
        import pytesseract  # type: ignore
        from PIL import Image  # type: ignore
        txt = pytesseract.image_to_string(Image.open(p), lang=args.get("lang") or "rus+eng")
    except Exception as e:
        return {"ok": False, "error": f"OCR недоступен: {e}",
                "hint": "pip install pytesseract pillow  +  установщик Tesseract-OCR (добавить в PATH)",
                "path": p}
    return {"ok": True, "path": p, "text": clip(txt.strip() or "(текст не распознан)", 8000)}


@tool("audio_record", "Записать звук с микрофона (голосовая заметка, команда, запись разговора).",
      OBJ({"seconds": INT("Длительность записи в секундах (по умолчанию 5, макс 300)"),
           "save_as": STR("Имя файла .wav"),
           "transcribe": BOOL("Распознать речь в текст (нужен SpeechRecognition + интернет)")}, []))
def t_audio_record(args):
    sec = max(1, min(300, int(args.get("seconds") or 5)))
    name = safe_filename(args.get("save_as") or f"rec_{dt.datetime.now():%Y%m%d_%H%M%S}.wav")
    if not name.endswith(".wav"):
        name += ".wav"
    out = AUDIO_DIR / name
    ok = False
    try:
        import sounddevice as sd  # type: ignore
        import soundfile as sf  # type: ignore
        # FIX: 22050 Гц поддерживают не все микрофоны — пробуем несколько частот
        last_e = None
        for rate in (22050, 16000, 44100, 48000):
            try:
                rec = sd.rec(int(sec * rate), samplerate=rate, channels=1, dtype="int16")
                sd.wait()
                sf.write(str(out), rec, rate)
                ok = True
                break
            except Exception as e:
                last_e = e
        if not ok and last_e:
            raise last_e
    except Exception as e:
        log.debug("sounddevice fail: %s", e)
    if not ok:
        try:
            import speech_recognition as sr  # type: ignore
            r = sr.Recognizer()
            with sr.Microphone(sample_rate=16000) as src:
                audio = r.listen(src, timeout=sec + 3, phrase_time_limit=sec)
            with open(out, "wb") as f:
                f.write(audio.get_wav_data())
            ok = True
        except Exception as e:
            return {"ok": False, "error": f"не удалось записать звук: {e}",
                    "hint": "pip install sounddevice soundfile  (или SpeechRecognition PyAudio)"}
    res = {"ok": True, "path": str(out), "seconds": sec, "size": sizeof_fmt(out.stat().st_size)}
    if args.get("transcribe"):
        try:
            import speech_recognition as sr  # type: ignore
            rr = sr.Recognizer()
            with sr.AudioFile(str(out)) as src:
                a = rr.record(src)
            res["text"] = rr.recognize_google(a, language="ru-RU")
        except Exception as e:
            res["transcribe_error"] = str(e)
    return res


@tool("audio_play", "Проиграть звук/музыку/запись: файл, URL, системный звук или текст голосом.",
      OBJ({"path": STR("Путь к аудиофайлу или URL"),
           "text": STR("Произнести этот текст (TTS)"),
           "system_sound": {"type": "string", "enum": ["beep", "ding", "error", "ok", "notify"],
                            "description": "Системный звук"},
           "stop": BOOL("Остановить текущее воспроизведение")}, []))
def t_audio_play(args):
    if args.get("stop"):
        if IS_WIN:
            cmd_run("taskkill /F /IM wmplayer.exe >nul 2>&1 & nircmd.exe mediastop >nul 2>&1", timeout=15)
        return {"ok": True, "action": "stopped"}
    if args.get("text"):
        from . import say as _say
        _say(str(args["text"]), priority=True)
        return {"ok": True, "spoken": clip(args["text"], 200)}
    if args.get("system_sound"):
        try:
            import winsound  # type: ignore
            mapping = {"beep": (880, 250), "ding": (1200, 180), "error": (300, 500),
                       "ok": (1000, 150), "notify": (1400, 120)}
            f, d = mapping.get(str(args["system_sound"]), (880, 200))
            winsound.Beep(f, d)
            return {"ok": True, "sound": args["system_sound"]}
        except Exception:
            return {"ok": False, "error": "winsound недоступен"}
    p = str(args.get("path") or "")
    if not p:
        return {"ok": False, "error": "нужен path, text или system_sound"}
    if re.match(r"^https?://", p, re.I):
        fn = DOWNLOAD_DIR / safe_filename(p.split("/")[-1].split("?")[0] or "audio.mp3")
        d = download(p, fn)
        if not d.get("ok"):
            return d
        p = str(fn)
    p = str(resolve_path(p))
    if not Path(p).exists():
        return {"ok": False, "error": f"файл не найден: {p}"}
    from . import play_sound_file
    play_sound_file(p)
    return {"ok": True, "playing": p}


@tool("clipboard", "Прочитать или записать буфер обмена Windows (текст, ссылки, скопированный код).",
      OBJ({"action": {"type": "string", "enum": ["get", "set"], "description": "get = прочитать, set = записать"},
           "text": STR("Текст для записи (для action=set)")}, ["action"]))
def t_clipboard(args):
    act = args.get("action") or "get"
    try:
        if IS_WIN:
            if act == "get":
                r = powershell("Get-Clipboard -Raw", timeout=20)
                return {"ok": r.get("code") == 0, "text": clip(r.get("stdout") or "", 8000)}
            txt = str(args.get("text") or "")
            # FIX: here-string @'...'@ ломался, если в тексте была строка, начинающаяся с '@
            import tempfile
            tf = Path(tempfile.gettempdir()) / f"flux_clip_{os.getpid()}.txt"
            tf.write_text(txt, encoding="utf-8")
            r = powershell(f"Set-Clipboard -Value (Get-Content -Raw -Encoding UTF8 '{str(tf)}')", timeout=20)
            try:
                tf.unlink()
            except Exception:
                pass
            return {"ok": r.get("code") == 0, "set_chars": len(txt)}
        else:
            if act == "get":
                r = run(["xclip", "-selection", "clipboard", "-o"], timeout=10)
                return {"ok": r.get("ok"), "text": clip(r.get("stdout") or "", 8000)}
            p = subprocess.Popen(["xclip", "-selection", "clipboard"], stdin=subprocess.PIPE)
            p.communicate(str(args.get("text") or "").encode("utf-8"))
            return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@tool("notify", "Показать всплывающее уведомление на экране (тост) + звук + озвучка. Используй для важных сообщений пользователю.",
      OBJ({"title": STR("Заголовок уведомления"),
           "message": STR("Текст уведомления"),
           "speak": BOOL("Озвучить голосом (по умолчанию true)"),
           "seconds": INT("Сколько показывать (по умолчанию 12)")}, ["title", "message"]))
def t_notify(args):
    from . import say as _say
    title = str(args.get("title") or "Flux")
    msg = str(args.get("message") or "")
    toast(title, msg, seconds=int(args.get("seconds") or 12), sound=True)
    if args.get("speak", True):
        _say(f"{title}. {msg}", priority=True)
    return {"ok": True, "notified": title}


# ================================================================ СЕТЬ / ФАЙЛЫ ИЗ ИНЕТА
@tool("download_file", "Скачать файл из интернета (программу, архив, картинку, документ) в папку Загрузки Flux или по указанному пути.",
      OBJ({"url": STR("Прямая ссылка на файл"),
           "path": STR("Куда сохранить (папка или полный путь). По умолчанию Flux\\data\\media\\downloads"),
           "open_after": BOOL("Открыть после скачивания")}, ["url"]))
def t_download_file(args):
    from . import download
    url = str(args.get("url") or "")
    if not re.match(r"^https?://", url, re.I):
        return {"ok": False, "error": "нужна http(s) ссылка"}
    dest = args.get("path")
    if dest:
        dp = resolve_path(dest)
        if dp.suffix:
            target = dp
        else:
            dp.mkdir(parents=True, exist_ok=True)
            fname = safe_filename(urllib.parse.unquote(url.split("/")[-1].split("?")[0]) or "download.bin")
            target = dp / fname
    else:
        fname = safe_filename(urllib.parse.unquote(url.split("/")[-1].split("?")[0]) or "download.bin")
        target = DOWNLOAD_DIR / fname
    r = download(url, target, timeout=300)
    if r.get("ok") and args.get("open_after"):
        open_path(str(target))
    return r


@tool("network_diagnostics", "Диагностика сети: пинг, трассировка, DNS, скорость, открытые порты, WiFi, активные соединения. Полезно когда 'интернет не работает'.",
      OBJ({"action": {"type": "string", "enum": ["ping", "trace", "dns", "speed", "ports", "wifi",
                                                 "connections", "adapters", "public_ip"],
                      "description": "Что проверить"},
           "host": STR("Хост/IP (по умолчанию 8.8.8.8)"),
           "ports": STR("Порты через запятую: 80,443,8888")}, ["action"]))
def t_network_diagnostics(args):
    act = str(args.get("action") or "ping").lower()
    host = str(args.get("host") or "8.8.8.8")
    try:
        if act == "ping":
            r = cmd_run(f"ping -n 4 {host}", timeout=40)
            return {"ok": r.get("code") == 0, "host": host, "output": clip(r.get("stdout") or "", 2000)}
        if act == "trace":
            r = cmd_run(f"tracert -d -h 15 -w 700 {host}", timeout=120)
            return {"ok": True, "host": host, "output": clip(r.get("stdout") or "", 3000)}
        if act == "dns":
            r = cmd_run(f"nslookup {host}", timeout=30)
            return {"ok": r.get("code") == 0, "output": clip((r.get("stdout") or "") + (r.get("stderr") or ""), 1500)}
        if act == "public_ip":
            ip = ""
            for svc in ("https://api.ipify.org", "https://ifconfig.me/ip", "https://icanhazip.com"):
                st, body = http_get_text(svc, timeout=10)
                if st == 200 and body.strip():
                    ip = body.strip()[:60]
                    break
            return {"ok": bool(ip), "public_ip": ip, "local_ip": _local_ip()}
        if act == "speed":
            return _speed_test()
        if act == "ports":
            from . import port_open
            ports = [int(x) for x in re.split(r"[,\s]+", str(args.get("ports") or "80,443,8888")) if x.strip().isdigit()]
            res = {p: port_open(host, p, 1.5) for p in ports[:12]}
            return {"ok": True, "host": host, "ports": res}
        if act == "wifi":
            r = cmd_run("netsh wlan show interfaces", timeout=25)
            r2 = cmd_run("netsh wlan show networks mode=bssid", timeout=25)
            return {"ok": True, "interfaces": clip(r.get("stdout") or "", 1500),
                    "networks": clip(r2.get("stdout") or "", 1500)}
        if act == "connections":
            r = cmd_run("netstat -ano | findstr ESTABLISHED", timeout=30)
            return {"ok": True, "output": clip(r.get("stdout") or "", 4000)}
        if act == "adapters":
            j = pwsh_json("Get-NetIPConfiguration | Select-Object InterfaceAlias,IPv4Address,IPv4DefaultGateway,DNSServer | ConvertTo-Json -Depth 4 -Compress", timeout=30)
            return {"ok": True, "adapters": j or "недоступно"}
        return {"ok": False, "error": f"неизвестное действие {act}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def _speed_test() -> dict:
    """Грубый замер скорости через публичный файл."""
    urls = ["https://speed.cloudflare.com/__down?bytes=25000000",
            "http://speedtest.tele2.net/10MB.zip"]
    for u in urls:
        try:
            t0 = time.time()
            req = urllib.request.Request(u, headers={"User-Agent": "FluxSpeedTest"})
            with urllib.request.urlopen(req, timeout=40) as r:
                data = r.read(25_000_000)
            dt_s = max(0.05, time.time() - t0)
            mbps = (len(data) * 8 / 1_000_000) / dt_s
            return {"ok": True, "download_mbps": round(mbps, 1), "bytes": len(data),
                    "seconds": round(dt_s, 2), "source": u}
        except Exception:
            continue
    return {"ok": False, "error": "не удалось измерить скорость (нет доступа к тестовым серверам)"}


# ================================================================ БЕЗОПАСНОСТЬ ПК
@tool("security_scan", "Проверка безопасности ПК: статус Защитника Windows, последние угрозы/вирусы, обновления, подозрительные процессы, автозагрузка, открытые порты, брандмауэр.",
      OBJ({"check": {"type": "string", "enum": ["all", "defender", "threats", "updates", "startup",
                                                "suspicious", "firewall", "full_scan", "quick_scan"],
                     "description": "Что проверить"},
           "fix": BOOL("Попробовать исправить найденные проблемы (включить защиту и т.п.)")}, []))
def t_security_scan(args):
    check = (args.get("check") or "all").lower()
    out = {}
    if check in ("all", "defender"):
        j = pwsh_json("""
$ErrorActionPreference='SilentlyContinue'
$s = Get-MpComputerStatus
[pscustomobject]@{
  antivirus_enabled = $s.AntivirusEnabled; realtime = $s.RealTimeProtectionEnabled;
  signatures_age_days = $s.AntivirusSignatureAge; last_scan = $s.QuickScanEndTime;
  engine = $s.AMEngineVersion; product = $s.AMProductVersion;
  tamper = $s.IsTamperProtected; behavior = $s.BehaviorMonitorEnabled
} | ConvertTo-Json -Compress
""", timeout=60)
        out["defender"] = j or {"note": "Get-MpComputerStatus недоступен (не Windows Defender или нет прав)"}
    if check in ("all", "threats"):
        j = pwsh_json("""
$ErrorActionPreference='SilentlyContinue'
$t = Get-MpThreatDetection | Select-Object -First 12 InitialDetectionTime, ThreatID, ProcessName, Resources
if ($t) { $t | ConvertTo-Json -Depth 3 -Compress } else { '[]' }
""", timeout=60)
        out["threats_detected"] = j if j not in (None, []) else "угроз не обнаружено"
    if check in ("all", "updates"):
        j = pwsh_json("""
$ErrorActionPreference='SilentlyContinue'
$s = New-Object -ComObject Microsoft.Update.Session
$sr = $s.CreateUpdateSearcher()
$c = $sr.Search("IsInstalled=0")
[pscustomobject]@{ pending = $c.Updates.Count;
  titles = @($c.Updates | Select-Object -First 8 | ForEach-Object { $_.Title }) } | ConvertTo-Json -Compress
""", timeout=120)
        out["windows_update"] = j or {"note": "не удалось проверить обновления (нужны права/время)"}
    if check in ("all", "startup"):
        j = pwsh_json("""
Get-CimInstance Win32_StartupCommand | Select-Object Name, Command, Location | ConvertTo-Json -Compress
""", timeout=60)
        out["startup_items"] = j or []
    if check in ("all", "suspicious"):
        susp = []
        try:
            import psutil  # type: ignore
            for p in psutil.process_iter(["pid", "name", "exe", "username", "create_time"]):
                try:
                    i = p.info
                    exe = (i.get("exe") or "").lower()
                    nm = (i.get("name") or "").lower()
                    if not exe:
                        continue
                    flags = []
                    if "\\temp\\" in exe or "\\appdata\\local\\temp" in exe:
                        flags.append("запуск из TEMP")
                    if re.search(r"(miner|xmrig|coinhive|keylog|rat\b)", nm):
                        flags.append("подозрительное имя")
                    if i.get("create_time") and (time.time() - i["create_time"]) < 120 and "\\downloads\\" in exe:
                        flags.append("свежий запуск из Загрузок")
                    if flags:
                        susp.append({"pid": i["pid"], "name": nm, "exe": exe, "why": flags})
                except Exception:
                    continue
        except Exception:
            pass
        out["suspicious_processes"] = susp or "явных подозрений нет"
    if check in ("all", "firewall"):
        r = powershell("Get-NetFirewallProfile | Select-Object Name,Enabled | ConvertTo-Json -Compress", timeout=45)
        try:
            out["firewall"] = json.loads((r.get("stdout") or "").strip() or "null")
        except Exception:
            out["firewall"] = (r.get("stdout") or "").strip()[:300]
    if check in ("quick_scan", "full_scan"):
        arg = "-QuickScan" if check == "quick_scan" else "-Scan"
        if check == "full_scan":
            # FIX: полное сканирование идёт 20-60 минут — раньше инструмента (и весь агент)
            # висел всё это время. Запускаем в фоне.
            try:
                subprocess.Popen(
                    ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", f"Start-MpScan {arg}"],
                    creationflags=0x08000000 if IS_WIN else 0,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                out["scan"] = {"ok": True, "type": check, "started_background": True,
                               "detail": "полное сканирование запущено в фоне; результат: security_scan threats / журнал Защитника"}
            except Exception as e:
                out["scan"] = {"ok": False, "type": check, "error": str(e)}
        else:
            r = powershell(f"Start-MpScan {arg}", timeout=1500)
            out["scan"] = {"ok": r.get("code") == 0, "type": check,
                           "detail": clip((r.get("stdout") or r.get("stderr")), 400)}
    if args.get("fix"):
        fixes = []
        r = powershell("Set-MpPreference -DisableRealtimeMonitoring $false; 'realtime on'", timeout=60)
        fixes.append(r.get("stdout"))
        out["fixes_applied"] = fixes
    problems = []
    d = out.get("defender") or {}
    if isinstance(d, dict):
        if d.get("realtime") is False:
            problems.append("Защита в реальном времени ОТКЛЮЧЕНА")
        if isinstance(d.get("signatures_age_days"), int) and d["signatures_age_days"] > 7:
            problems.append(f"Базы антивируса устарели ({d['signatures_age_days']} дн.)")
    if isinstance(out.get("threats_detected"), list) and out["threats_detected"]:
        problems.append(f"Обнаружено угроз: {len(out['threats_detected'])}")
    out["problems"] = problems or "критичных проблем не найдено"
    return {"ok": True, "check": check, "report": out}


@tool("system_events", "Журнал Windows: ошибки приложений, синие экраны (BSOD), неожиданные выключения, сбои служб за последние N часов. Полезно понять 'почему ПК глючил/выключился'.",
      OBJ({"hours": INT("За сколько часов смотреть (по умолчанию 24, макс 720)"),
           "log": {"type": "string", "enum": ["system", "application", "security", "all"],
                   "description": "Какой журнал"},
           "level": {"type": "string", "enum": ["error", "warning", "critical", "all"],
                     "description": "Уровень событий"},
           "limit": INT("Максимум событий (по умолчанию 30)")}, []))
def t_system_events(args):
    hours = max(1, min(720, int(args.get("hours") or 24)))
    logs = {"system": "System", "application": "Application", "security": "Security",
            "all": "System,Application"}.get((args.get("log") or "system").lower(), "System")
    level = (args.get("level") or "error").lower()
    lvl_ps = {"error": "1,2", "warning": "1,2,3", "critical": "1", "all": "1,2,3,4"}.get(level, "1,2")
    limit = max(1, min(200, int(args.get("limit") or 30)))
    # FIX: log=all раньше смотрел только System (брался logs.split(',')[0])
    lognames = ",".join(f"'{x.strip()}'" for x in logs.split(","))
    ps = f"""
$ErrorActionPreference='SilentlyContinue'
$since = (Get-Date).AddHours(-{hours})
Get-WinEvent -FilterHashtable @{{ LogName = @({lognames}); Level = {lvl_ps}; StartTime = $since }} -MaxEvents {limit} |
 Select-Object TimeCreated, Id, LevelDisplayName, ProviderName, @{{n='Msg';e={{ ($_.Message -split \"`n\")[0] }}}} |
 ConvertTo-Json -Depth 3 -Compress
"""
    j = pwsh_json(ps, timeout=90)
    events = j if isinstance(j, list) else ([j] if j else [])
    bsod = None
    r = pwsh_json("""
$ErrorActionPreference='SilentlyContinue'
Get-WinEvent -FilterHashtable @{LogName='System'; Id=1001; ProviderName='Microsoft-Windows-WER-SystemErrorReporting'} -MaxEvents 3 |
 Select-Object TimeCreated, Message | ConvertTo-Json -Compress
""", timeout=60)
    if r:
        bsod = r
    dumps = []
    try:
        for f in glob.glob(r"C:\Windows\Minidump\*.dmp"):
            dumps.append({"file": f, "modified": human_time(os.path.getmtime(f))})
    except Exception:
        pass
    return {"ok": True, "hours": hours, "log": logs, "level": level, "count": len(events),
            "events": events, "bsod_reports": bsod, "minidumps": dumps[-5:],
            "hint": "если событий нет — за этот период ошибок не было"}
