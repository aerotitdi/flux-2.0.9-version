# -*- coding: utf-8 -*-
"""
FLUX :: core/tools_time.py
Время, таймеры, напоминания, будильники, повторяющиеся задачи + фоновый планировщик.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import re
import threading
import time
import uuid
from pathlib import Path

from . import (CFG, SCHEDULE_FILE, beep, clip, exc_text, human_time, jload, jsave, log,
               now, powershell, say, toast, tools_log)
from .tools_system import (ARR, BOOL, INT, NUM, OBJ, STR, cmd_run, is_dangerous,
                           confirm_action, resolve_path, run, tool)

# ---------------------------------------------------------------- хранилище
_lock = threading.RLock()


def _load() -> list:
    d = jload(SCHEDULE_FILE, default={"items": []})
    if isinstance(d, dict):
        return d.get("items", [])
    if isinstance(d, list):
        return d
    return []


def _save(items: list):
    jsave(SCHEDULE_FILE, {"items": items, "updated": human_time()})


RU_MONTHS = {"январ": 1, "феврал": 2, "марта": 3, "март": 3, "апрел": 4, "мая": 5, "май": 5,
             "июн": 6, "июл": 7, "август": 8, "авг": 8, "сентябр": 9, "октябр": 10,
             "ноябр": 11, "декабр": 12}
RU_WEEKDAYS = {"понедельник": 0, "вторник": 1, "среду": 2, "среда": 2, "четверг": 3,
               "пятницу": 4, "пятница": 4, "субботу": 5, "суббота": 5, "воскресенье": 6,
               "воскресение": 6}
RU_PARTS = {"утра": 0, "утром": 0, "дня": 12, "днем": 12, "вечера": 18, "вечером": 18, "ночи": 23}


def _to_24h(h: int, part: str) -> int:
    """FIX: раньше было h%12 + RU_PARTS[part], из-за чего «9 вечера» давало hour=27
    (ValueError — напоминание не создавалось), «11 дня» -> 23:00, «12 ночи» -> 23:00.
    Правильный перевод 12-часового формата в 24-часовой по смысловым диапазонам:
      утра  : 5 утра=5,  11 утра=11, 12 утра=0
      дня   : 1 дня=13,  6 дня=18,   11 дня=11, 12 дня=12
      вечера: 9 вечера=21, 11 вечера=23, 12 вечера=0
      ночи  : 12 ночи=0, 2 ночи=2"""
    h12 = h % 12
    if part in ("утра", "утром"):
        return h12
    if part in ("дня", "днем"):
        if h == 12:
            return 12
        return h + 12 if h <= 10 else h     # 11 дня считаем утренними 11:00
    if part in ("вечера", "вечером"):
        return 0 if h == 12 else h12 + 12
    if part == "ночи":
        return h12                          # 12 ночи -> 0, 2 ночи -> 2
    return h


def _parse_when(when: str) -> dt.datetime:
    """Гибкий разбор времени:
    '19:30' · 'завтра 9:00' · 'послезавтра 8 вечера' · '2026-10-07 08:15' · '+2h' ·
    'через 30 минут' · 'в пятницу' · 'в пятницу в 15:00' · '8 утра' · 'полночь' · 'полдень' ·
    '12 октября' · '12.10.2026 15:00' · 'каждый день 9:00' (дата+время)."""
    s = (when or "").strip().lower().replace("ё", "е")
    base = now()
    if not s:
        return base
    s = re.sub(r"^(?:в|на|к)\s+", "", s) if re.match(r"^(?:в|на|к)\s+\d", s) else s
    s = s.replace("полночь", "00:00").replace("полдень", "12:00")
    # день недели
    wd = None
    for name, idx in RU_WEEKDAYS.items():
        if name in s:
            wd = idx
            s = s.replace(name, " ")
            break
    # месяц словом
    for name, num in RU_MONTHS.items():
        if name in s:
            s = re.sub(r"(\d{1,2})\s*" + name + r"(?:я)?", lambda m, n=num: f"{m.group(1)}.{n:02d}", s)
            s = s.replace(name, " ")
            break
    # "8 утра/вечера/дня/ночи"
    m = re.search(r"(\d{1,2})\s*(утра|утром|дня|днем|вечера|вечером|ночи)", s)
    if m:
        h = _to_24h(int(m.group(1)), m.group(2))
        s = (s[:m.start()] + f" {h:02d}:00 " + s[m.end():]).strip()
    # относительное
    m = re.fullmatch(r"\+?\s*(\d+(?:[.,]\d+)?)\s*(сек|секунд\w*|s|sec|мин|минут\w*|m|min|ч|час\w*|h|hour\w*|дн|день|дней|d|day\w*|нед|недел\w*|w|week\w*)", s)
    if m:
        val = float(m.group(1).replace(",", "."))
        unit = m.group(2)
        mult = 1
        if unit.startswith(("сек", "s")):
            mult = 1
        elif unit.startswith(("мин", "m")):
            mult = 60
        elif unit.startswith(("ч", "h")):
            mult = 3600
        elif unit.startswith(("дн", "д", "d")):
            mult = 86400
        elif unit.startswith(("нед", "w")):
            mult = 604800
        return base + dt.timedelta(seconds=val * mult)
    day_offset = 0
    if wd is not None:
        delta = (wd - base.weekday()) % 7
        delta = delta or 7
        day_offset += delta
    if "послезавтра" in s:
        day_offset = 2
        s = s.replace("послезавтра", "")
    elif "завтра" in s or "tomorrow" in s:
        day_offset = 1
        s = re.sub(r"завтра|tomorrow", "", s)
    elif "сегодня" in s or "today" in s:
        s = re.sub(r"сегодня|today", "", s)
    s = s.strip(" в,.")
    # осталось только смещение дня без времени ("завтра", "в пятницу") -> ставим 09:00
    if not re.sub(r"[\s:.,]", "", s):
        s = "09:00"
    # ISO
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%d.%m.%Y %H:%M",
                "%d.%m.%Y %H:%M:%S", "%d.%m %H:%M", "%d.%m.%y %H:%M"):
        try:
            d = dt.datetime.strptime(s, fmt)
            no_year = (d.year == 1900)
            if no_year:
                d = d.replace(year=base.year)
            if d < base and day_offset == 0:
                # FIX: формат «день.месяц» без года — если дата уже прошла, переносим
                # на СЛЕДУЮЩИЙ ГОД (раньше добавлялся 1 день: «25.12» 26 декабря
                # превращалось в 26.12 вместо 25.12 следующего года)
                if no_year and "%Y" not in fmt and "%y" not in fmt:
                    try:
                        d = d.replace(year=base.year + 1)
                    except ValueError:      # 29.02 -> 28.02
                        d = d.replace(year=base.year + 1, day=28)
                else:
                    d += dt.timedelta(days=1)
            return d + dt.timedelta(days=day_offset)
        except ValueError:
            continue
    m = re.search(r"(\d{1,2})[:.\s](\d{2})", s)
    if m:
        h, mi = int(m.group(1)), int(m.group(2))
        d = base.replace(hour=h, minute=mi, second=0, microsecond=0) + dt.timedelta(days=day_offset)
        if d < base and day_offset == 0:
            d += dt.timedelta(days=1)
        return d
    m = re.fullmatch(r"(\d{1,2})", s)
    if m:  # просто час
        h = int(m.group(1))
        d = base.replace(hour=h, minute=0, second=0, microsecond=0) + dt.timedelta(days=day_offset)
        if d < base:
            d += dt.timedelta(days=1)
        return d
    # русские слова
    m = re.search(r"через\s+(\d+(?:[.,]\d+)?)\s*(сек\w*|мин\w*|час\w*|ч\b|дн\w*|недел\w*)", s)
    if m:
        val = float(m.group(1).replace(",", "."))
        u = m.group(2)
        mult = 1 if u.startswith("сек") else 60 if u.startswith("мин") else 3600 if u.startswith(("час", "ч")) \
            else 86400 if u.startswith("дн") else 604800
        return base + dt.timedelta(seconds=val * mult)
    raise ValueError(f"не понял время: '{when}'")


def _next_repeat(item: dict, fired_at: dt.datetime) -> dt.datetime | None:
    rep = str(item.get("repeat") or "").lower()
    if rep in ("none", "", "0"):
        return None
    if rep.startswith("every_"):
        try:
            sec = int(rep.split("_", 1)[1])
            return fired_at + dt.timedelta(seconds=max(20, sec))
        except Exception:
            return None
    if rep in ("daily", "день", "ежедневно"):
        return fired_at + dt.timedelta(days=1)
    if rep in ("hourly", "час"):
        return fired_at + dt.timedelta(hours=1)
    if rep in ("weekly", "неделя"):
        return fired_at + dt.timedelta(weeks=1)
    if rep.startswith("weekdays"):
        d = fired_at + dt.timedelta(days=1)
        while d.weekday() >= 5:
            d += dt.timedelta(days=1)
        return d.replace(hour=fired_at.hour, minute=fired_at.minute, second=0, microsecond=0)
    if rep.startswith("cron:"):
        return _cron_next(rep[5:], fired_at)
    if rep.startswith("at:"):
        # at:09:30 daily-like
        return None
    return None


def _cron_next(expr: str, after: dt.datetime) -> dt.datetime | None:
    """Мини-cron: 'мин час [день] [месяц] [день_недели]'. Поддержка * , / -"""
    parts = expr.split()
    if len(parts) < 2:
        return None
    fields = []
    for i, p in enumerate(parts[:5]):
        fields.append(_cron_field(p, i))
    d = after.replace(second=0, microsecond=0) + dt.timedelta(minutes=1)
    for _ in range(60 * 24 * 400):
        if (d.minute in fields[0] and d.hour in fields[1] and
            (len(fields) < 3 or d.day in fields[2]) and
            (len(fields) < 4 or d.month in fields[3]) and
            (len(fields) < 5 or ((d.weekday() + 1) % 7) in fields[4])):
            return d
        d += dt.timedelta(minutes=1)
    return None


def _cron_field(spec: str, idx: int) -> set:
    ranges = {"m": (0, 59), "h": (0, 23), "d": (1, 31), "mo": (1, 12), "dw": (0, 6)}
    lo, hi = list(ranges.values())[idx]
    out = set()
    for part in spec.split(","):
        part = part.strip()
        if part in ("*", "?"):
            out |= set(range(lo, hi + 1))
        elif "/" in part:
            base, step = part.split("/")
            step = int(step)
            start = lo if base == "*" else int(base)
            out |= set(range(start, hi + 1, step))
        elif "-" in part:
            a, b = part.split("-")
            out |= set(range(int(a), int(b) + 1))
        elif part.isdigit():
            out.add(int(part))
    return out or set(range(lo, hi + 1))


def _fmt_item(it: dict) -> str:
    when = it.get("when") or ""
    rep = it.get("repeat") or "none"
    kind = it.get("type") or "reminder"
    status = "выполнено" if it.get("done") else ("пауза" if it.get("paused") else "активно")
    return (f"[{it.get('id')}] {kind} | {when} | повтор: {rep} | {status} | {it.get('text')}")


# ---------------------------------------------------------------- инструменты
@tool("get_time", "Текущие дата и время системы, день недели, часовой пояс, аптайм ПК, время до/после события, разница дат. ВСЕГДА используй для любых вопросов про время, вместо догадок.",
      OBJ({"timezone": STR("Часовой пояс, например Europe/Moscow (по умолчанию системный)"),
           "format": {"type": "string", "enum": ["full", "short", "iso", "unix"], "description": "Формат ответа"},
           "diff_to": STR("Посчитать время до этой даты/времени (например '2026-12-31 00:00' или '18:00')")}, []))
def t_get_time(args):
    t = now()
    tzname = args.get("timezone")
    out = {}
    if tzname:
        try:
            import zoneinfo
            z = zoneinfo.ZoneInfo(tzname)
            tz_t = dt.datetime.now(z)
            out = {"timezone": tzname, "datetime": tz_t.strftime("%d.%m.%Y %H:%M:%S %Z"),
                   "iso": tz_t.isoformat(), "weekday": _ru_weekday(tz_t.weekday())}
        except Exception as e:
            out = {"timezone_error": str(e)}
    if not out:
        out = {"local_datetime": t.strftime("%d.%m.%Y %H:%M:%S"),
               "iso": t.isoformat(timespec="seconds"),
               "date": t.strftime("%d.%m.%Y"), "time": t.strftime("%H:%M:%S"),
               "weekday": _ru_weekday(t.weekday()), "year": t.year,
               "unix": int(t.timestamp()),
               "timezone": time.strftime("%Z") or time.tzname[0],
               # FIX: учитываем летнее время (altzone), раньше offset зимой и летом был одинаковым
               "utc_offset_hours": round(-(time.altzone if (time.daylight and time.localtime().tm_isdst)
                                           else time.timezone) / 3600, 1)}
    fmt = args.get("format")
    if fmt == "short":
        out = {"time": t.strftime("%H:%M"), "date": t.strftime("%d.%m.%Y")}
    elif fmt == "iso":
        out = {"iso": t.isoformat(timespec="seconds")}
    elif fmt == "unix":
        out = {"unix": int(t.timestamp())}
    if args.get("diff_to"):
        try:
            target = _parse_when(str(args["diff_to"]))
            delta = target - t
            total_min = int(delta.total_seconds() // 60)
            out["diff_to"] = {"target": target.strftime("%d.%m.%Y %H:%M"),
                              "days": delta.days, "hours": (total_min // 60) % 24,
                              "minutes": total_min % 60, "total_minutes": total_min,
                              "human": _human_delta(delta)}
        except Exception as e:
            out["diff_error"] = str(e)
    # аптайм
    # FIX: time.boottime есть только в Linux — на Windows uptime_hours был всегда null.
    try:
        up = None
        if hasattr(time, "boottime"):
            up = time.time() - time.boottime()
        elif os.name == "nt":
            import ctypes
            up = ctypes.windll.kernel32.GetTickCount64() / 1000.0
        if up is not None:
            out["uptime_hours"] = round(up / 3600, 1)
    except Exception:
        pass
    return {"ok": True, **out}


def _ru_weekday(i: int) -> str:
    return ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"][i % 7]


def _human_delta(d: dt.timedelta) -> str:
    sec = int(abs(d.total_seconds()))
    days, rem = divmod(sec, 86400)
    hours, rem = divmod(rem, 3600)
    mins, secs = divmod(rem, 60)
    parts = []
    if days:
        parts.append(f"{days} дн")
    if hours:
        parts.append(f"{hours} ч")
    if mins:
        parts.append(f"{mins} мин")
    if secs and not days and not hours:
        parts.append(f"{secs} сек")
    sign = "осталось " if d.total_seconds() >= 0 else "прошло "
    return sign + " ".join(parts)


@tool("timer", "Таймер с оповещением: обратный отсчёт, который по окончании выдаст звук + голос + всплывающее окно. Можно несколько таймеров сразу, ставить на паузу, отменять, смотреть остаток.",
      OBJ({"action": {"type": "string", "enum": ["start", "list", "cancel", "pause", "resume", "snooze"],
                      "description": "Действие"},
           "seconds": NUM("Длительность в секундах (например 300 = 5 минут)"),
           "minutes": NUM("Длительность в минутах (можно вместо seconds)"),
           "hours": NUM("Длительность в часах"),
           "label": STR("Подпись таймера: 'чайник', 'тренировка'..."),
           "id": STR("ID таймера для cancel/pause/resume"),
           "snooze_minutes": INT("На сколько минут отложить (для snooze)")}, ["action"]))
def t_timer(args):
    act = (args.get("action") or "start").lower()
    with _lock:
        items = _load()
        if act == "list":
            timers = [i for i in items if i.get("type") == "timer" and not i.get("done")]
            return {"ok": True, "count": len(timers),
                    "timers": [_fmt_item(i) for i in timers] or "активных таймеров нет"}
        if act in ("cancel", "pause", "resume", "snooze"):
            tid = str(args.get("id") or "").strip()
            lab = str(args.get("label") or "").strip().lower()
            target = None
            # FIX: раньше пустой id + пустой label давали "" in text == True для ЛЮБОГО
            # элемента — «отмени таймер» без параметров убивало первый попавшийся
            # (иногда даже напоминание). Теперь ищем только таймеры и только по непустым критериям.
            for i in items:
                if i.get("type") != "timer" or i.get("done"):
                    continue
                if (tid and i.get("id") == tid) or (not tid and lab and lab in str(i.get("text", "")).lower()):
                    target = i
                    break
            if not target:
                return {"ok": False, "error": f"таймер '{tid}' не найден",
                        "list": [_fmt_item(i) for i in items if i.get("type") == "timer"]}
            if act == "cancel":
                target["done"] = True
                target["cancelled"] = True
                _save(items)
                return {"ok": True, "cancelled": target["id"], "text": target.get("text")}
            if act == "pause":
                target["paused"] = True
                target["paused_at"] = human_time()
                _save(items)
                return {"ok": True, "paused": target["id"]}
            if act == "resume":
                target["paused"] = False
                _save(items)
                return {"ok": True, "resumed": target["id"]}
            if act == "snooze":
                mins = int(args.get("snooze_minutes") or 5)
                target["when_ts"] = time.time() + mins * 60
                target["when"] = human_time(target["when_ts"])
                target["done"] = False
                _save(items)
                return {"ok": True, "snoozed": target["id"], "new_time": target["when"]}
        # start
        total = 0.0
        total += float(args.get("seconds") or 0)
        total += float(args.get("minutes") or 0) * 60
        total += float(args.get("hours") or 0) * 3600
        if total <= 0:
            return {"ok": False, "error": "укажи seconds, minutes или hours"}
        total = max(5, int(total))
        label = str(args.get("label") or "таймер")
        when = now() + dt.timedelta(seconds=total)
        item = {
            "id": "t_" + uuid.uuid4().hex[:7],
            "type": "timer",
            "text": f"⏱ Таймер «{label}» завершён!",
            "speak_text": f"Таймер {label} сработал. Прошло {total // 60} минут {total % 60} секунд.",
            "when": human_time(when.timestamp()),
            "when_ts": when.timestamp(),
            "repeat": "none",
            "action": {"kind": "notify", "sound": True, "speak": True, "window": True},
            "created": human_time(),
            "done": False, "paused": False, "fired_count": 0,
        }
        items.append(item)
        _save(items)
        return {"ok": True, "id": item["id"], "label": label, "seconds": total,
                "fires_at": item["when"],
                "message": f"таймер на {total // 60} мин {total % 60} сек установлен — сработает в {item['when']}"}


@tool("reminder", "Напоминание / будильник: сработает в указанное время (звук + голос + всплывающее окно), может повторяться (каждый день, по будням, каждые N минут, cron). Работает даже если Flux перезапустили — напоминания сохраняются.",
      OBJ({"action": {"type": "string", "enum": ["add", "list", "cancel", "snooze", "done", "update"],
                      "description": "Действие"},
           "text": STR("Текст напоминания: 'выпить воды', 'созвон в 15:00'..."),
           "when": STR("Когда: '19:30', 'завтра 9:00', '+30 мин', 'через 2 часа', '2026-10-07 08:15'"),
           "repeat": {"type": "string", "enum": ["none", "daily", "weekdays", "hourly", "weekly",
                                                 "every_300", "every_1800", "every_3600", "cron:0 9 * * *"],
                      "description": "Повтор: daily=каждый день, weekdays=по будням, every_N=каждые N секунд, cron:мин час день мес дн_нед"},
           "id": STR("ID напоминания для cancel/snooze/done"),
           "snooze_minutes": INT("Отложить на N минут"),
           "run_command": STR("Дополнительно выполнить команду Windows при срабатывании"),
           "open_path": STR("Дополнительно открыть файл/сайт при срабатывании"),
           "ask_ai": BOOL("При срабатывании передать текст Флюксу, чтобы он сам решил что делать и сообщил пользователю")}, ["action"]))
def t_reminder(args):
    act = (args.get("action") or "add").lower()
    with _lock:
        items = _load()
        if act == "list":
            act_items = [i for i in items if i.get("type") == "reminder" and not i.get("done")]
            done_items = [i for i in items if i.get("type") == "reminder" and i.get("done")][-8:]
            return {"ok": True, "active": len(act_items),
                    "reminders": [_fmt_item(i) for i in act_items] or "активных напоминаний нет",
                    "recent_done": [_fmt_item(i) for i in done_items]}
        if act in ("cancel", "done", "snooze", "update"):
            tid = str(args.get("id") or "")
            target = None
            for i in items:
                if i.get("id") == tid:
                    target = i; break
            if not target and args.get("text"):
                q = str(args["text"]).lower()
                for i in items:
                    if q in str(i.get("text", "")).lower() and not i.get("done"):
                        target = i; break
            if not target:
                return {"ok": False, "error": "напоминание не найдено",
                        "list": [_fmt_item(i) for i in items if not i.get("done")]}
            if act in ("cancel", "done"):
                target["done"] = True
                target["finished"] = human_time()
                _save(items)
                return {"ok": True, act: target["id"], "text": target.get("text")}
            if act == "snooze":
                mins = int(args.get("snooze_minutes") or 10)
                target["when_ts"] = time.time() + mins * 60
                target["when"] = human_time(target["when_ts"])
                target["done"] = False
                _save(items)
                return {"ok": True, "snoozed_to": target["when"], "minutes": mins}
            if act == "update":
                if args.get("when"):
                    w = _parse_when(str(args["when"]))
                    target["when_ts"] = w.timestamp(); target["when"] = human_time(w.timestamp())
                if args.get("text"):
                    target["text"] = str(args["text"])
                if args.get("repeat"):
                    target["repeat"] = str(args["repeat"])
                _save(items)
                return {"ok": True, "updated": _fmt_item(target)}
        # add
        text = str(args.get("text") or "").strip()
        if not text:
            return {"ok": False, "error": "нужен текст напоминания"}
        when_raw = str(args.get("when") or "+1 час")
        try:
            when = _parse_when(when_raw)
        except Exception as e:
            return {"ok": False, "error": str(e),
                    "hint": "примеры: '19:30', 'завтра 9:00', '+30 мин', '2026-12-31 23:00'"}
        action = {"kind": "notify", "sound": True, "speak": True, "window": True}
        if args.get("run_command"):
            action["command"] = str(args["run_command"])
        if args.get("open_path"):
            action["open"] = str(args["open_path"])
        if args.get("ask_ai"):
            action["ask_ai"] = True
        # дедупликация: такое же напоминание на то же время уже есть?
        for i in items:
            if (not i.get("done") and i.get("type") == "reminder"
                    and str(i.get("raw_text", "")).lower() == text.lower()
                    and abs(float(i.get("when_ts") or 0) - when.timestamp()) < 120):
                return {"ok": True, "duplicate": True, "id": i["id"], "text": text,
                        "when": i.get("when"),
                        "message": f"такое напоминание уже есть: «{text}» -> {i.get('when')}"}
        item = {
            "id": "r_" + uuid.uuid4().hex[:7],
            "type": "reminder",
            "text": f"🔔 Напоминание: {text}",
            "raw_text": text,
            "speak_text": f"Напоминаю: {text}",
            "when": human_time(when.timestamp()),
            "when_ts": when.timestamp(),
            "repeat": str(args.get("repeat") or "none"),
            "action": action,
            "created": human_time(), "done": False, "paused": False, "fired_count": 0,
        }
        items.append(item)
        _save(items)
        delta = when - now()
        return {"ok": True, "id": item["id"], "text": text, "when": item["when"],
                "repeat": item["repeat"],
                "in": _human_delta(delta),
                "message": f"напоминание создано: «{text}» -> {item['when']} (повтор: {item['repeat']})"}


# ---------------------------------------------------------------- планировщик
class Scheduler(threading.Thread):
    """Фоновый поток: проверяет расписание каждые 2 секунды и срабатывает."""

    def __init__(self, app=None):
        super().__init__(daemon=True, name="flux-scheduler")
        self.app = app
        self.stop_flag = threading.Event()
        self.last_tick = 0.0
        self.fired_log = []

    def stop(self):
        self.stop_flag.set()

    def run(self):
        log.info("scheduler started")
        # при старте — догнать пропущенные (не старше 12 часов)
        try:
            self._catchup()
        except Exception:
            log.warning("catchup error: %s", exc_text()[-400:])
        while not self.stop_flag.is_set():
            try:
                self.tick()
            except Exception as e:
                log.warning("scheduler tick: %s", e)
            self.stop_flag.wait(2.0)

    def _catchup(self):
        missed_items = []
        with _lock:
            items = _load()
            changed = False
            t = time.time()
            for i in items:
                if i.get("done") or i.get("paused"):
                    continue
                ts = float(i.get("when_ts") or 0)
                if ts and t - ts > 5 and t - ts < 12 * 3600:
                    missed_items.append(i)
                    nxt = _next_repeat(i, now())
                    if nxt:
                        i["when_ts"] = nxt.timestamp(); i["when"] = human_time(nxt.timestamp())
                        i["done"] = False
                    else:
                        i["done"] = True
                    changed = True
            if changed:
                _save(items)
        for i in missed_items:   # оповещения — вне блокировки расписания
            try:
                self._fire(i, missed=True)
            except Exception as e:
                log.warning("catchup fire %s: %s", i.get("id"), e)

    def tick(self):
        t = time.time()
        due = []
        with _lock:
            items = _load()
            changed = False
            for i in items:
                if i.get("done") or i.get("paused"):
                    continue
                ts = float(i.get("when_ts") or 0)
                if ts and t >= ts:
                    if t - ts > 12 * 3600:
                        # FIX: _catchup пропускает опоздавшие больше чем на 12 часов,
                        # но tick тут же их всё равно «стрелял» при каждом запуске —
                        # недельной давности напоминание звенело снова и снова.
                        # Помечаем выполненным без оповещения.
                        i["done"] = True
                        i["missed"] = True
                        i["finished"] = human_time()
                        changed = True
                        continue
                    due.append(i)
                    nxt = _next_repeat(i, now())
                    if nxt:
                        i["when_ts"] = nxt.timestamp()
                        i["when"] = human_time(nxt.timestamp())
                        i["fired_count"] = int(i.get("fired_count") or 0) + 1
                    else:
                        i["done"] = True
                        i["finished"] = human_time()
                    changed = True
            if changed:
                _save(items)
        # FIX: оповещения (beep/toast/say ~1 сек на каждое) выполнялись ПОД блокировкой
        # расписания — теперь вне её.
        for i in due:
            try:
                self._fire(i)
            except Exception as e:
                log.warning("fire %s: %s", i.get("id"), e)

    def _fire(self, item: dict, missed: bool = False):
        text = item.get("text") or "напоминание"
        if missed:
            text = "(пропущено, пока Flux не работал) " + text
        log.info("FIRE %s :: %s", item.get("id"), text)
        self.fired_log.append({"id": item.get("id"), "text": text, "at": human_time(), "missed": missed})
        act = item.get("action") or {}
        speak_text = item.get("speak_text") or text
        if act.get("sound", True):
            for _ in range(3):
                beep(1046, 220); time.sleep(0.06)
        if act.get("window", True):
            toast("FLUX :: напоминание", text, seconds=20)
        if act.get("speak", True):
            say(speak_text, priority=True)
        if act.get("command"):
            try:
                cmd_run(str(act["command"]), timeout=120)
            except Exception as e:
                log.warning("reminder command: %s", e)
        if act.get("open"):
            try:
                from . import open_path
                open_path(str(act["open"]))
            except Exception:
                pass
        if act.get("ask_ai") and self.app is not None:
            try:
                self.app.inject_proactive(f"Сработало напоминание: {item.get('raw_text') or text}. "
                                          f"Скажи пользователю кратко и по делу, предложи помощь.")
            except Exception:
                pass
        # запись в журнал событий
        try:
            from .tools_brain import add_event
            add_event("reminder", text)
        except Exception:
            pass


SCHEDULER: Scheduler | None = None


def start_scheduler(app=None) -> Scheduler:
    global SCHEDULER
    if SCHEDULER is None:
        SCHEDULER = Scheduler(app)
        SCHEDULER.start()
    elif app is not None:
        SCHEDULER.app = app
    return SCHEDULER


@tool("schedule_list", "Показать всё расписание: таймеры, напоминания, повторяющиеся задачи, историю срабатываний, ближайшие события.",
      OBJ({"include_done": BOOL("Показывать выполненные"), "limit": INT("Максимум строк (50)")}, []))
def t_schedule_list(args):
    with _lock:
        items = _load()
    if not args.get("include_done"):
        items = [i for i in items if not i.get("done")]
    items.sort(key=lambda x: float(x.get("when_ts") or 0))
    limit = int(args.get("limit") or 50)
    t = time.time()
    rows = []
    for i in items[:limit]:
        ts = float(i.get("when_ts") or 0)
        left = _human_delta(dt.timedelta(seconds=ts - t)) if ts else "?"
        rows.append(f"[{i.get('id')}] {i.get('type')} | {i.get('when')} ({left}) | repeat={i.get('repeat')} | {i.get('text')}")
    hist = []
    if SCHEDULER:
        hist = [f"{h['at']} {h['text']}" for h in SCHEDULER.fired_log[-10:]]
    return {"ok": True, "count": len(rows), "items": rows or "расписание пустое",
            "recent_fired": hist}


@tool("stopwatch", "Секундомер: запуск/стоп/сброс/круги. Для замеров времени выполнения задач.",
      OBJ({"action": {"type": "string", "enum": ["start", "stop", "lap", "reset", "status"], "description": "Действие"},
           "label": STR("Метка круга")}, ["action"]))
def t_stopwatch(args):
    store = _SW_FILE
    data = jload(store, default={"running": False, "started": None, "accum": 0.0, "laps": []})
    act = args.get("action")
    t = time.time()
    if act == "start":
        if not data.get("running"):
            data["running"] = True
            data["started"] = t
    elif act == "stop":
        if data.get("running"):
            data["accum"] = float(data.get("accum") or 0) + (t - float(data["started"]))
            data["running"] = False
    elif act == "reset":
        data = {"running": False, "started": None, "accum": 0.0, "laps": []}
    elif act == "lap":
        cur = _sw_now(data)
        data.setdefault("laps", []).append({"label": args.get("label") or f"круг {len(data['laps']) + 1}",
                                            "total": round(cur, 2), "at": human_time()})
    elif act == "status":
        pass
    jsave(store, data)
    return {"ok": True, "action": act, "elapsed_sec": round(_sw_now(data), 2),
            "running": data.get("running"), "laps": data.get("laps", [])[-10:]}


# FIX: Path(__file__) в собранном EXE указывает на временный каталог _MEIPASS —
# данные секундомера терялись после каждого запуска. Используем MEMORY_DIR из core.
from . import MEMORY_DIR as _MEMORY_DIR
_SW_FILE = _MEMORY_DIR / "stopwatch.json"


def _sw_now(data: dict) -> float:
    acc = float(data.get("accum") or 0)
    if data.get("running") and data.get("started"):
        acc += time.time() - float(data["started"])
    return acc
