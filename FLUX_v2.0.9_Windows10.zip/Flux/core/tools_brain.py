# -*- coding: utf-8 -*-
"""
FLUX :: core/tools_brain.py
Память, заметки, список дел, журнал событий, ПРОАКТИВНЫЙ сторож системы
(сам замечает проблемы и сообщает пользователю: диск, память, CPU, батарея,
температура, вирусы/Защитник, сбои программ, BSOD, обновления).
"""
from __future__ import annotations

import datetime as dt
import json
import os
import re
import threading
import time
from pathlib import Path

from . import (CFG, FACTS_FILE, IS_WIN, MEMORY_FILE, NOTES_FILE, beep, clip, exc_text,
               human_time, jload, jsave, log, now, powershell, pwsh_json, say, sizeof_fmt,
               toast, tools_log)
from .tools_system import (ARR, BOOL, INT, NUM, OBJ, STR, resolve_path, run, tool)

EVENTS_FILE = MEMORY_FILE.parent / "events.jsonl"
HEALTH_FILE = MEMORY_FILE.parent / "health.json"
_mem_lock = threading.RLock()


def _purge_corrupted() -> None:
    """FIX v2.0.5: записи, испорченные старым багом декодирования (символы U+FFFD ''),
    вычищаются один раз при старте, чтобы панель и журнал не светили кракозябрами вечно."""
    try:
        if EVENTS_FILE.exists():
            txt = EVENTS_FILE.read_text(encoding="utf-8", errors="replace")
            if "\ufffd" in txt:
                lines = [ln for ln in txt.splitlines() if "\ufffd" not in ln]
                EVENTS_FILE.write_text("\n".join(lines) + ("\n" if lines else ""),
                                       encoding="utf-8")
                log.info("events.jsonl: удалено испорченных строк: %d",
                         len(txt.splitlines()) - len(lines))
    except Exception:
        pass
    try:
        if HEALTH_FILE.exists():
            raw = HEALTH_FILE.read_text(encoding="utf-8", errors="replace")
            if "\ufffd" in raw:
                HEALTH_FILE.write_text("{}", encoding="utf-8")
                log.info("health.json: сброшен (содержал испорченный текст)")
    except Exception:
        pass


_purge_corrupted()


# ================================================================ ПАМЯТЬ
def _mem() -> dict:
    d = jload(MEMORY_FILE, default={})
    if not isinstance(d, dict):
        d = {}
    d.setdefault("user", {})
    d.setdefault("facts", [])
    d.setdefault("preferences", {})
    d.setdefault("history_index", [])
    return d


@tool("memory", "Долговременная память Флюкса: запоминает факты о пользователе, его предпочтения, важные данные (имена, пароли от Wi-Fi НЕ хранить, проекты, привычки). Память сохраняется между перезапусками и подмешивается в контекст. Используй когда пользователь говорит 'запомни', или когда узнал что-то важное о нём/системе.",
      OBJ({"action": {"type": "string", "enum": ["remember", "recall", "forget", "list", "set_user", "set_pref"],
                      "description": "remember=добавить факт, recall=найти, forget=удалить, list=всё, set_user=поле профиля, set_pref=настройка"},
           "text": STR("Что запомнить (для remember) или поисковый запрос (для recall)"),
           "key": STR("Ключ профиля/настройки: name, city, work, language, tone, timezone..."),
           "value": STR("Значение для set_user/set_pref"),
           "tags": ARR(STR("Тег"), "Теги для поиска: проект, работа, личное"),
           "importance": {"type": "string", "enum": ["low", "normal", "high"], "description": "Важность (high всегда в контексте)"},
           "id": STR("ID факта для forget")}, ["action"]))
def t_memory(args):
    act = (args.get("action") or "list").lower()
    with _mem_lock:
        m = _mem()
        if act == "remember":
            text = str(args.get("text") or "").strip()
            if not text:
                return {"ok": False, "error": "пустой текст"}
            # дедупликация
            for f in m["facts"]:
                if f.get("text", "").lower() == text.lower():
                    f["updated"] = human_time()
                    f["hits"] = int(f.get("hits") or 0) + 1
                    jsave(MEMORY_FILE, m)
                    return {"ok": True, "updated_existing": f["id"], "text": text}
            item = {"id": "m_" + dt.datetime.now().strftime("%y%m%d%H%M%S") + f"_{len(m['facts']) % 97}",
                    "text": text, "tags": args.get("tags") or [], "importance": args.get("importance") or "normal",
                    "created": human_time(), "updated": human_time(), "hits": 0}
            m["facts"].append(item)
            m["facts"] = m["facts"][-400:]
            jsave(MEMORY_FILE, m)
            return {"ok": True, "remembered": text, "id": item["id"], "total_facts": len(m["facts"])}
        if act == "recall":
            q = str(args.get("text") or "").lower().strip()
            words = [w for w in re.split(r"[\s,]+", q) if len(w) > 2] or [q]
            scored = []
            for f in m["facts"]:
                blob = (f.get("text", "") + " " + " ".join(f.get("tags") or [])).lower()
                sc = sum(1 for w in words if w in blob)
                if f.get("importance") == "high":
                    sc += 0.5
                if sc:
                    scored.append((sc, f))
            scored.sort(key=lambda x: x[0], reverse=True)
            hits = [f for _, f in scored[:12]]
            for f in hits:
                f["hits"] = int(f.get("hits") or 0) + 1
            jsave(MEMORY_FILE, m)
            return {"ok": True, "query": q, "found": len(hits),
                    "results": [{"id": f["id"], "text": f["text"], "tags": f.get("tags"),
                                 "importance": f.get("importance"), "created": f.get("created")} for f in hits]
                    or "в памяти ничего нет по этому запросу"}
        if act == "forget":
            fid = str(args.get("id") or "")
            q = str(args.get("text") or "").lower()
            before = len(m["facts"])
            m["facts"] = [f for f in m["facts"]
                          if f.get("id") != fid and not (q and q in f.get("text", "").lower())]
            jsave(MEMORY_FILE, m)
            return {"ok": True, "removed": before - len(m["facts"])}
        if act == "set_user":
            k, v = str(args.get("key") or ""), str(args.get("value") or "")
            if not k:
                return {"ok": False, "error": "нужен key"}
            m["user"][k] = v
            jsave(MEMORY_FILE, m)
            return {"ok": True, "user_field": k, "value": v}
        if act == "set_pref":
            k, v = str(args.get("key") or ""), args.get("value")
            if not k:
                return {"ok": False, "error": "нужен key"}
            m["preferences"][k] = v
            jsave(MEMORY_FILE, m)
            return {"ok": True, "preference": k, "value": v}
        # list
        return {"ok": True, "user": m["user"], "preferences": m["preferences"],
                "facts_count": len(m["facts"]),
                "facts": [{"id": f["id"], "text": f["text"], "importance": f.get("importance"),
                           "tags": f.get("tags")} for f in m["facts"][-60:]]}


def memory_context_block(max_chars: int = 2600) -> str:
    """Блок памяти для системного промпта."""
    m = _mem()
    lines = []
    if m["user"]:
        lines.append("ПРОФИЛЬ ПОЛЬЗОВАТЕЛЯ: " + "; ".join(f"{k}={v}" for k, v in list(m["user"].items())[:14]))
    if m["preferences"]:
        lines.append("ПРЕДПОЧТЕНИЯ: " + "; ".join(f"{k}={v}" for k, v in list(m["preferences"].items())[:14]))
    hi = [f for f in m["facts"] if f.get("importance") == "high"][-10:]
    rest = [f for f in m["facts"] if f.get("importance") != "high"][-14:]
    if hi:
        lines.append("ВАЖНОЕ (high): " + " | ".join(f["text"][:150] for f in hi))
    if rest:
        lines.append("ЗАПОМНЕНО: " + " | ".join(f["text"][:120] for f in rest))
    return "\n".join(lines)[:max_chars]


def add_event(kind: str, text: str, level: str = "info"):
    try:
        # FIX: журнал событий никогда не обрезался — за месяцы работы файл раздувался
        # на сотни МБ и тормозил recent_events(). При >2 МБ оставляем хвост.
        try:
            if EVENTS_FILE.exists() and EVENTS_FILE.stat().st_size > 2_000_000:
                lines = EVENTS_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
                EVENTS_FILE.write_text("\n".join(lines[-1000:]) + "\n", encoding="utf-8")
        except Exception:
            pass
        with open(EVENTS_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps({"t": now().isoformat(timespec="seconds"), "kind": kind,
                                "level": level, "text": str(text)[:600]}, ensure_ascii=False) + "\n")
    except Exception:
        pass


def recent_events(kind: str = "", limit: int = 30) -> list:
    out = []
    try:
        with open(EVENTS_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                except Exception:
                    continue
                if kind and e.get("kind") != kind:
                    continue
                out.append(e)
    except Exception:
        pass
    return out[-limit:]


# ================================================================ ЗАМЕТКИ / ДЕЛА
@tool("notes", "Заметки и список дел (to-do): создавать, добавлять пункты, отмечать выполненными, искать, удалять. Хранится в data/memory/notes.json.",
      OBJ({"action": {"type": "string", "enum": ["create", "append", "list", "read", "todo_add",
                                                 "todo_done", "todo_list", "delete", "search"],
                      "description": "Действие"},
           "title": STR("Название заметки/списка"),
           "text": STR("Текст / пункт списка / запрос поиска"),
           "index": INT("Номер пункта для todo_done"),
           "priority": {"type": "string", "enum": ["low", "normal", "high"], "description": "Важность задачи"}}, ["action"]))
def t_notes(args):
    act = (args.get("action") or "list").lower()
    with _mem_lock:
        d = jload(NOTES_FILE, default={"notes": {}, "todos": []})
        d.setdefault("notes", {}); d.setdefault("todos", [])
        title = str(args.get("title") or "").strip()
        if act == "create":
            if not title:
                return {"ok": False, "error": "нужен title"}
            d["notes"][title] = {"text": str(args.get("text") or ""), "created": human_time(),
                                 "updated": human_time()}
            jsave(NOTES_FILE, d)
            return {"ok": True, "created": title, "chars": len(str(args.get("text") or ""))}
        if act == "append":
            if title not in d["notes"]:
                d["notes"][title] = {"text": "", "created": human_time()}
            d["notes"][title]["text"] = (d["notes"][title]["text"] + "\n" + str(args.get("text") or "")).strip()
            d["notes"][title]["updated"] = human_time()
            jsave(NOTES_FILE, d)
            return {"ok": True, "appended_to": title, "chars": len(d["notes"][title]["text"])}
        if act == "read":
            if title not in d["notes"]:
                return {"ok": False, "error": f"заметка '{title}' не найдена", "titles": list(d["notes"])}
            n = d["notes"][title]
            return {"ok": True, "title": title, "text": n["text"], "updated": n.get("updated")}
        if act == "delete":
            if title in d["notes"]:
                del d["notes"][title]
                jsave(NOTES_FILE, d)
                return {"ok": True, "deleted": title}
            return {"ok": False, "error": "не найдено", "titles": list(d["notes"])}
        if act == "search":
            q = str(args.get("text") or title or "").lower()
            hits = [f"[{t}] {v['text'][:200]}" for t, v in d["notes"].items() if q in t.lower() or q in v["text"].lower()]
            return {"ok": True, "query": q, "found": len(hits), "results": hits or "ничего не найдено"}
        if act == "todo_add":
            txt = str(args.get("text") or "").strip()
            if not txt:
                return {"ok": False, "error": "нужен text"}
            d["todos"].append({"id": len(d["todos"]) + 1, "text": txt, "done": False,
                               "priority": args.get("priority") or "normal",
                               "list": title or "общее", "created": human_time()})
            jsave(NOTES_FILE, d)
            return {"ok": True, "added": txt, "open_todos": sum(1 for t in d["todos"] if not t["done"])}
        if act == "todo_done":
            idx = args.get("index")
            q = str(args.get("text") or "").lower()
            done = []
            for t in d["todos"]:
                if (idx is not None and t["id"] == int(idx)) or (q and q in t["text"].lower() and not t["done"]):
                    t["done"] = True; t["finished"] = human_time(); done.append(t["text"])
                    if idx is None:
                        break
            jsave(NOTES_FILE, d)
            return {"ok": True, "completed": done or "не найдено",
                    "open_todos": sum(1 for t in d["todos"] if not t["done"])}
        if act == "todo_list":
            todos = [t for t in d["todos"] if not t["done"]]
            order = {"high": 0, "normal": 1, "low": 2}
            todos.sort(key=lambda t: order.get(t.get("priority"), 1))
            return {"ok": True, "open": len(todos),
                    "todos": [f"#{t['id']} [{t.get('priority')}] {t['text']} ({t.get('list')})" for t in todos][:60]
                    or "список дел пуст"}
        # list
        return {"ok": True, "notes": {t: {"chars": len(v["text"]), "updated": v.get("updated")}
                                      for t, v in d["notes"].items()},
                "open_todos": sum(1 for t in d["todos"] if not t["done"]),
                "total_todos": len(d["todos"])}


# ================================================================ ЗДОРОВЬЕ СИСТЕМЫ
_last = {"threats": None, "events": 0.0, "events_data": [], "full": 0.0, "full_data": {}}


def sample_health(full: bool = False) -> dict:
    """Быстрый срез состояния ПК. full=True — тяжёлые проверки (журналы, Defender)."""
    h = {"time": human_time()}
    # --- psutil или PowerShell
    try:
        import psutil  # type: ignore
        h["cpu_percent"] = psutil.cpu_percent(interval=0.35)
        vm = psutil.virtual_memory()
        h["memory_percent"] = vm.percent
        h["memory_free"] = sizeof_fmt(vm.available)
        disks = []
        for part in psutil.disk_partitions(all=False):
            try:
                u = psutil.disk_usage(part.mountpoint)
                disks.append({"drive": part.device or part.mountpoint, "free_percent": round(u.free * 100.0 / u.total, 1),
                              "free": sizeof_fmt(u.free), "total": sizeof_fmt(u.total)})
            except Exception:
                continue
        h["disks"] = disks
        try:
            b = psutil.sensors_battery()
            if b:
                h["battery"] = {"percent": round(b.percent, 1), "plugged": bool(b.power_plugged)}
        except Exception:
            pass
        try:
            temps = psutil.sensors_temperatures() or {}
            mx = 0
            for k, arr in temps.items():
                for t in arr:
                    mx = max(mx, float(t.current or 0))
            if mx:
                h["temperature_c"] = round(mx, 1)
        except Exception:
            pass
        try:
            procs = []
            for p in psutil.process_iter(["pid", "name", "memory_percent", "cpu_percent"]):
                procs.append(p.info)
            procs.sort(key=lambda x: x.get("memory_percent") or 0, reverse=True)
            h["top_mem"] = [f"{p.get('name')} {round(p.get('memory_percent') or 0,1)}%" for p in procs[:5]]
            h["process_count"] = len(procs)
        except Exception:
            pass
    except Exception:
        j = pwsh_json("""
$os=Get-CimInstance Win32_OperatingSystem; $cs=Get-CimInstance Win32_ComputerSystem; $cpu=Get-CimInstance Win32_Processor|Select -First 1
$d=Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3"|%{[pscustomobject]@{drive=$_.DeviceID;free_percent=[math]::Round($_.FreeSpace/[math]::Max(1,$_.Size)*100,1);free=[math]::Round($_.FreeSpace/1GB,1)}}
[pscustomobject]@{cpu_percent=$cpu.LoadPercentage;memory_percent=[math]::Round(($cs.TotalPhysicalMemory-$os.FreePhysicalMemory*1KB)/$cs.TotalPhysicalMemory*100,1);memory_free=[math]::Round($os.FreePhysicalMemory/1MB,1);disks=$d}|ConvertTo-Json -Depth 3 -Compress
""", timeout=60)
        if j:
            h.update(j)
    # --- сеть
    try:
        import socket
        socket.create_connection(("1.1.1.1", 53), timeout=2).close()
        h["internet"] = True
    except Exception:
        h["internet"] = False
    # --- тяжёлые проверки (кэшируются)
    if full and IS_WIN and time.time() - _last["full"] > 600:
        _last["full"] = time.time()
        fd = {}
        try:
            fd["defender"] = pwsh_json("""
$ErrorActionPreference='SilentlyContinue'
$s=Get-MpComputerStatus
[pscustomobject]@{realtime=$s.RealTimeProtectionEnabled;antivirus=$s.AntivirusEnabled;sig_age=$s.AntivirusSignatureAge;tamper=$s.IsTamperProtected}|ConvertTo-Json -Compress
""", timeout=60)
            fd["threats"] = pwsh_json("""
$ErrorActionPreference='SilentlyContinue'
$t=Get-MpThreatDetection|Select -First 6 InitialDetectionTime,ProcessName,Resources
if($t){$t|ConvertTo-Json -Depth 3 -Compress}else{'[]'}
""", timeout=60)
            fd["errors_24h"] = pwsh_json("""
$ErrorActionPreference='SilentlyContinue'
$e=Get-WinEvent -FilterHashtable @{LogName='System';Level=1,2;StartTime=(Get-Date).AddHours(-24)} -MaxEvents 15
[pscustomobject]@{count=@($e).Count; items=@($e|Select -First 6|%{[pscustomobject]@{id=$_.Id;src=$_.ProviderName;msg=(($_.Message -split "`n")[0])}})}|ConvertTo-Json -Depth 4 -Compress
""", timeout=90)
            fd["app_crashes"] = pwsh_json("""
$ErrorActionPreference='SilentlyContinue'
$e=Get-WinEvent -FilterHashtable @{LogName='Application';Id=1000,1001,1002;StartTime=(Get-Date).AddHours(-24)} -MaxEvents 10
[pscustomobject]@{count=@($e).Count; items=@($e|%{[pscustomobject]@{id=$_.Id;src=$_.ProviderName;time=$_.TimeCreated.ToString('dd.MM HH:mm');msg=(($_.Message -split "`n")[0])}})}|ConvertTo-Json -Depth 4 -Compress
""", timeout=90)
            fd["pending_updates"] = pwsh_json("""
$ErrorActionPreference='SilentlyContinue'
$p=Get-HotFix|Sort InstalledOn -Desc|Select -First 3 Description,HotFixID,InstalledOn
[pscustomobject]@{last_installed=@($p|%{$_.HotFixID+' '+(Get-Date $_.InstalledOn -Format 'dd.MM.yyyy')})}|ConvertTo-Json -Compress
""", timeout=60)
        except Exception as e:
            fd["error"] = str(e)
        _last["full_data"] = fd
    if _last["full_data"]:
        h["security"] = _last["full_data"]
    return h


def analyze_health(h: dict) -> list:
    """Возвращает список ПРОБЛЕМ (пусто = всё хорошо)."""
    problems = []
    th = CFG.get("thresholds") or {}
    cpu_lim = float(th.get("cpu_percent", 96))
    mem_lim = float(th.get("memory_percent", 93))
    disk_lim = float(th.get("disk_free_percent", 8))
    bat_lim = float(th.get("battery_percent", 15))
    temp_lim = float(th.get("temperature_c", 88))
    try:
        if h.get("cpu_percent") is not None and float(h["cpu_percent"]) >= cpu_lim:
            problems.append(f"CPU загружен на {h['cpu_percent']}% — возможна зависшая программа. Топ: {h.get('top_mem')}")
    except Exception:
        pass
    try:
        if h.get("memory_percent") is not None and float(h["memory_percent"]) >= mem_lim:
            problems.append(f"Память занята на {h['memory_percent']}% (свободно {h.get('memory_free')}). Стоит закрыть тяжёлые программы.")
    except Exception:
        pass
    for d in (h.get("disks") or []):
        try:
            if float(d.get("free_percent", 100)) <= disk_lim:
                problems.append(f"Мало места на диске {d.get('drive')}: свободно {d.get('free_percent')}% ({d.get('free')}).")
        except Exception:
            continue
    b = h.get("battery")
    if isinstance(b, dict) and not b.get("plugged") and float(b.get("percent", 100)) <= bat_lim:
        problems.append(f"Батарея разряжена: {b.get('percent')}% — подключи зарядку.")
    try:
        if h.get("temperature_c") and float(h["temperature_c"]) >= temp_lim:
            problems.append(f"Высокая температура: {h['temperature_c']}°C — проверь охлаждение/пыль.")
    except Exception:
        pass
    if h.get("internet") is False:
        problems.append("Нет подключения к интернету (проверка 1.1.1.1:53 не прошла).")
    sec = h.get("security") or {}
    d = sec.get("defender") or {}
    if isinstance(d, dict):
        if d.get("realtime") is False or d.get("antivirus") is False:
            problems.append("⚠ Защита Windows ОТКЛЮЧЕНА (real-time protection off) — ПК без антивирусной защиты!")
        try:
            if int(d.get("sig_age") or 0) > 10:
                problems.append(f"Базы антивируса устарели на {d.get('sig_age')} дн. — запусти обновление/сканирование.")
        except Exception:
            pass
    th_ = sec.get("threats")
    if isinstance(th_, list) and th_:
        names = []
        for t in th_[:4]:
            if isinstance(t, dict):
                names.append(str(t.get("ProcessName") or t.get("Resources") or "?")[:80])
        problems.append(f"🦠 ОБНАРУЖЕНЫ УГРОЗЫ ({len(th_)}): {', '.join(names)} — требуется немедленная проверка!")
    ac = sec.get("app_crashes") or {}
    if isinstance(ac, dict) and int(ac.get("count") or 0) >= 3:
        items = "; ".join((i.get("msg") or "")[:70] for i in (ac.get("items") or [])[:3])
        problems.append(f"За 24ч зафиксировано {ac.get('count')} сбоев программ: {items}")
    ev = sec.get("errors_24h") or {}
    if isinstance(ev, dict) and int(ev.get("count") or 0) >= 8:
        problems.append(f"В журнале Windows {ev.get('count')} критических ошибок за 24 часа.")
    return problems


@tool("system_health", "Проверка 'здоровья' ПК прямо сейчас: ресурсы, диски, батарея, температура, интернет, антивирус/угрозы, сбои программ и ошибки в журнале. Возвращает список проблем и рекомендации. Используй при жалобах 'ПК тормозит', 'что-то не так', 'проверь систему', а также перед проактивным сообщением.",
      OBJ({"full": BOOL("true = полная проверка (журналы Windows, Defender, угрозы). Медленнее, но детальнее."),
           "speak_problems": BOOL("Озвучить найденные проблемы"),
           "notify": BOOL("Показать всплывающее окно, если есть проблемы")}, []))
def t_system_health(args):
    full = bool(args.get("full", True))
    t0 = time.time()
    h = sample_health(full=full)
    problems = analyze_health(h)
    res = {"ok": True, "seconds": round(time.time() - t0, 1), "snapshot": h,
           "problems": problems or [], "status": "ПРОБЛЕМЫ ЕСТЬ" if problems else "всё в норме",
           "recommendations": _recommendations(problems, h)}
    if problems:
        add_event("health", "; ".join(problems)[:500], level="warn")
        if args.get("notify", True):
            toast("FLUX :: проверка системы", problems[0][:180], seconds=15)
        if args.get("speak_problems"):
            say("Внимание. " + problems[0][:220], priority=True)
    else:
        add_event("health", "проверка пройдена, проблем нет", level="ok")
    return res


def _recommendations(problems: list, h: dict) -> list:
    recs = []
    p = " ".join(problems).lower()
    if "cpu" in p:
        recs.append("Открой Диспетчер задач (Ctrl+Shift+Esc) и сними задачу с самого прожорливого процесса; я могу сделать это сам: process_list + process_kill.")
    if "память" in p or "memory" in p:
        recs.append("Закрой браузеры с сотней вкладок; могу выгрузить конкретный процесс.")
    if "места" in p or "диск" in p:
        recs.append("Очистка: Win+R -> cleanmgr, или я могу найти самые большие файлы (search_files) и удалить мусор (Temp, кэш браузеров).")
    if "угроз" in p or "вирус" in p:
        recs.append("Срочно: security_scan quick_scan, затем full_scan; проверь автозагрузку (security_scan startup).")
    if "защита windows отключена" in p or "отключена" in p:
        recs.append("Включи защиту: security_scan с fix=true, либо Параметры -> Обновление и безопасность -> Безопасность Windows.")
    if "батарея" in p:
        recs.append("Подключи зарядное устройство; при работе от батареи включи режим экономии энергии.")
    if "температура" in p:
        recs.append("Проверь вентиляторы и пыль; снизь нагрузку; при перегреве ноутбук может выключиться.")
    if "интернет" in p:
        recs.append("Диагностика: network_diagnostics ping / dns / adapters; перезапусти роутер; проверь Wi-Fi.")
    if "сбоев программ" in p or "журнал" in p:
        recs.append("Смотри детали: system_events log=application level=error hours=24.")
    if not recs:
        recs.append("Система в норме. Могу поставить регулярную проверку напоминанием (reminder repeat=daily).")
    return recs


# ================================================================ ПРОАКТИВНЫЙ СТОРОЖ
class Watchdog(threading.Thread):
    """Сам следит за системой и САМ начинает разговор, если случилось важное."""

    def __init__(self, app=None):
        super().__init__(daemon=True, name="flux-watchdog")
        self.app = app
        self.stop_flag = threading.Event()
        self.alerted: dict[str, float] = {}
        self.cpu_high_since: float | None = None
        self.history: list[dict] = []
        self.interval = int(CFG.get("proactive_interval_sec", 180))
        self.last_full = 0.0

    def stop(self):
        self.stop_flag.set()

    def set_app(self, app):
        self.app = app

    def run(self):
        if not CFG.get("proactive", True):
            log.info("watchdog disabled by config")
            return
        log.info("watchdog started (interval %ss)", self.interval)
        self.stop_flag.wait(min(45, self.interval))
        while not self.stop_flag.is_set():
            try:
                self.cycle()
            except Exception as e:
                log.warning("watchdog cycle: %s | %s", e, exc_text()[-300:])
            self.stop_flag.wait(self.interval)

    def cycle(self):
        checks = set(CFG.get("proactive_checks") or [])
        do_full = ("defender" in checks or "crashes" in checks) and (time.time() - self.last_full > 1800)
        if do_full:
            self.last_full = time.time()
        h = sample_health(full=do_full)
        problems = analyze_health(h)
        self.history.append({"t": human_time(), "cpu": h.get("cpu_percent"),
                             "mem": h.get("memory_percent"), "problems": len(problems)})
        self.history = self.history[-120:]
        jsave(HEALTH_FILE, {"last": h, "problems": problems, "history": self.history[-40:],
                            "updated": human_time()})
        # устойчивая высокая нагрузка на CPU
        cpu = float(h.get("cpu_percent") or 0)
        lim = float((CFG.get("thresholds") or {}).get("cpu_percent", 96))
        sustained = float((CFG.get("thresholds") or {}).get("cpu_sustained_sec", 240))
        if cpu >= lim:
            if self.cpu_high_since is None:
                self.cpu_high_since = time.time()
            elif time.time() - self.cpu_high_since >= sustained:
                problems.append(f"CPU держится ≥{lim}% уже {int(time.time() - self.cpu_high_since)} сек.")
        else:
            self.cpu_high_since = None
        # дедупликация/кулдаун: одно и то же не чаще 1 раза в 45 минут
        t = time.time()
        fresh = []
        for p in problems:
            key = re.sub(r"\d+", "N", p)[:60]
            if t - self.alerted.get(key, 0) > 2700:
                self.alerted[key] = t
                fresh.append(p)
        if not fresh:
            return
        # v2.0.9: раз в цикл сторожа тихо освежаем протухший токен qwen из браузера
        try:
            if CFG.get("qwen_auto_token", True):
                from . import qwen_web as _QW
                qs = _QW.token_status()
                want = (self.app is not None and self.app.llm.provider == "qwen_web") or \
                       "qwen_web" in (CFG.get("auto_fallback_providers") or [])
                if want and qs["state"] in ("expired", "none"):
                    ar = _QW.auto_refresh_token(force=True)
                    if ar.get("updated"):
                        add_event("qwen", f"авто-токен обновлён из {ar.get('source')} ({ar.get('detail')})",
                                  level="ok")
        except Exception:
            pass
        severity = "critical" if any(("УГРОЗ" in p.upper() or "ОТКЛЮЧЕНА" in p.upper()) for p in fresh) else "warning"
        msg = " | ".join(fresh)[:600]
        log.warning("PROACTIVE[%s]: %s", severity, msg)
        add_event("proactive", msg, level=severity)
        toast(f"FLUX :: важно ({severity})", msg[:200], seconds=22)
        if CFG.get("proactive_speak", True):
            say("Внимание, это важно. " + fresh[0][:250], priority=True)
        if self.app is not None:
            try:
                self.app.inject_proactive(
                    "ПРОАКТИВНОЕ ОПОВЕЩЕНИЕ СИСТЕМЫ (обнаружено автоматически, не запрос пользователя):\n"
                    + msg + "\n\nКратко и по делу сообщи пользователю об этом, оцени серьёзность и "
                            "предложи конкретное действие (можешь сразу выполнить диагностику инструментами). "
                            "Если это критично (вирусы/отключённый антивирус/перегрев/место на диске) — начни с предупреждения.")
            except Exception as e:
                log.warning("inject_proactive: %s", e)

    def startup_report(self) -> dict:
        """Проверка при запуске: что важно сказать пользователю сразу."""
        try:
            h = sample_health(full=True)
            self.last_full = time.time()
            problems = analyze_health(h)
            return {"ok": True, "problems": problems, "snapshot": h}
        except Exception as e:
            return {"ok": False, "error": str(e)}


WATCHDOG: Watchdog | None = None


def start_watchdog(app=None) -> Watchdog:
    global WATCHDOG
    # FIX: после disable поток завершался, но объект оставался — повторный enable
    # вызывал лишь set_app() и сторож больше никогда не работал до перезапуска Flux.
    if WATCHDOG is None or not WATCHDOG.is_alive():
        WATCHDOG = Watchdog(app)
        WATCHDOG.start()
    elif app is not None:
        WATCHDOG.set_app(app)
    return WATCHDOG


@tool("proactive_watchdog", "Управление проактивным сторожем: статус, история наблюдений, включить/выключить, изменить интервал, немедленная проверка. Сторож САМ следит за ПК и сообщает о важном (вирусы, перегрев, мало места, сбои).",
      OBJ({"action": {"type": "string", "enum": ["status", "history", "enable", "disable", "check_now", "set_interval"],
                      "description": "Действие"},
           "seconds": INT("Интервал проверок в секундах (для set_interval, мин 60)")}, ["action"]))
def t_watchdog(args):
    act = args.get("action") or "status"
    global WATCHDOG
    if act == "status":
        w = WATCHDOG
        return {"ok": True, "enabled": bool(CFG.get("proactive", True)),
                "running": bool(w and w.is_alive()),
                "interval_sec": CFG.get("proactive_interval_sec"),
                "checks": CFG.get("proactive_checks"),
                "thresholds": CFG.get("thresholds"),
                "alerts_sent": len(w.alerted) if w else 0,
                "last_snapshot": (jload(HEALTH_FILE, default={}) or {}).get("problems", [])}
    if act == "history":
        d = jload(HEALTH_FILE, default={}) or {}
        return {"ok": True, "updated": d.get("updated"), "problems": d.get("problems"),
                "history": d.get("history", [])[-25:], "recent_events": recent_events("proactive", 12)}
    if act == "enable":
        CFG.set("proactive", True)
        start_watchdog(WATCHDOG.app if WATCHDOG else None)
        return {"ok": True, "message": "проактивный контроль включён"}
    if act == "disable":
        CFG.set("proactive", False)
        if WATCHDOG:
            WATCHDOG.stop()
        return {"ok": True, "message": "проактивный контроль выключен"}
    if act == "set_interval":
        s = max(60, int(args.get("seconds") or 180))
        CFG.set("proactive_interval_sec", s)
        if WATCHDOG:
            WATCHDOG.interval = s
        return {"ok": True, "interval_sec": s}
    if act == "check_now":
        r = t_system_health({"full": True, "notify": True})
        if WATCHDOG:
            try:
                WATCHDOG.cycle()
            except Exception:
                pass
        return r
    return {"ok": False, "error": f"неизвестное действие {act}"}


@tool("events_log", "Журнал событий Флюкса: что он делал, какие проблемы находил, напоминания, ошибки. Полезно для отчётов и 'что происходило пока меня не было'.",
      OBJ({"kind": STR("Фильтр: health, proactive, reminder, tool, error, llm (пусто = всё)"),
           "limit": INT("Сколько последних событий (по умолчанию 30)")}, []))
def t_events_log(args):
    ev = recent_events(str(args.get("kind") or ""), int(args.get("limit") or 30))
    return {"ok": True, "count": len(ev),
            "events": [f"{e.get('t')} [{e.get('level')}] {e.get('kind')}: {e.get('text')}" for e in ev]
            or "журнал пуст"}
