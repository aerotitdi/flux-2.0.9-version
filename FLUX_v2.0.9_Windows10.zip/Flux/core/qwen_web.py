# -*- coding: utf-8 -*-
"""
FLUX :: core/qwen_web.py
ПРЯМОЙ клиент web-API chat.qwen.ai (встроенный «мост», без отдельного процесса).
Портирован из qwen-bridge (github.com/aerotitdi/flux-upgrader) на stdlib urllib,
чтобы работать внутри Flux/FLUX.exe без aiohttp и без лишнего окна.

Даёт бесплатный qwen3.8-max (и другие веб-модели) без лимитов xkiro,
включая суффиксы:  qwen3.8-max:search (поиск в интернете силами сайта),
                    qwen3.8-max:think  (форс-рассуждения),
                    qwen3.8-max:fast   (без рассуждений).

Токен: файл qwen_web.key рядом с flux.py / env QWEN_TOKEN / config["qwen_token"].
Как получить: F12 на https://chat.qwen.ai -> Console -> выполнить token_snippet.js
(лежит в tools/) -> токен eyJ... в буфере обмена.
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
import uuid
from pathlib import Path

from . import CFG, ROOT, USER_AGENT, log

BASE_URL = "https://chat.qwen.ai"
WUM_URL = "https://sg-wum.alibaba.com/w/wu.json"
TOKEN_FILE = ROOT / "qwen_web.key"

TEXTISH = ("t2t", "search", "deep_research", "web_dev", "full_stack", "artifacts")
SUFFIXES = ("search", "think", "fast")
FALLBACK_MODELS = ["qwen3.8-max", "qwen3.8-omni-flash", "qwen3.7-max", "qwen3.7-plus",
                   "qwen3.6-plus", "qwen3.5-plus", "qwen3-coder-plus", "qwen3-vl-plus"]

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36")


class QwenWebError(Exception):
    def __init__(self, msg: str, status: int = 502):
        super().__init__(msg)
        self.status = status


# ---------------------------------------------------------------- токен
def get_qwen_token() -> str:
    import os
    t = (os.environ.get("QWEN_TOKEN") or "").strip()
    if not t:
        try:
            if TOKEN_FILE.exists():
                t = TOKEN_FILE.read_text(encoding="utf-8").strip()
        except Exception:
            t = ""
    if not t:
        t = str(CFG.get("qwen_token") or "").strip()
    return t.strip().strip('"').strip("'")


def save_qwen_token(token: str) -> Path:
    TOKEN_FILE.write_text(token.strip(), encoding="utf-8")
    try:
        import os
        os.chmod(TOKEN_FILE, 0o600)
    except Exception:
        pass
    return TOKEN_FILE


def parse_model(model: str) -> tuple:
    """'qwen3.8-max:search' -> ('qwen3.8-max', 'search')"""
    if ":" in model:
        base, suf = model.rsplit(":", 1)
        if suf in SUFFIXES:
            return base, suf
    return model, None


# ---------------------------------------------------------------- клиент
class QwenWeb:
    """Синхронный клиент web-API chat.qwen.ai (OpenAI-подобный результат)."""

    def __init__(self, token: str = "", cookie: str = "", base: str | None = None,
                 thinking: str | None = None, clean_chats: bool = True):
        self.token = token or get_qwen_token()
        self.cookie = cookie or str(CFG.get("qwen_cookie") or "").strip()
        # FIX: дефолты base/thinking были непустыми и ПОДМЕНЯЛИ конфиг (qwen_base_url,
        # qwen_thinking) — клиент всегда ходил на chat.qwen.ai с режимом auto
        self.base = str(base or CFG.get("qwen_base_url") or BASE_URL).rstrip("/")
        self.thinking = str(thinking or CFG.get("qwen_thinking") or "auto").lower()
        self.clean_chats = bool(CFG.get("qwen_clean_chats", True)) if clean_chats else clean_chats
        self._mid = None
        self._mid_lock = threading.Lock()
        self._models = {"ids": [], "meta": {}, "ts": 0.0}
        self._lock = threading.Lock()

    # ------------------------------------------------------------ служебное
    def ready(self) -> bool:
        return bool(self.token or self.cookie)

    def _midtoken(self, session_get, force=False):
        """bx-umidtoken — антибот-маркер Aliyun WAF (из wu.json), кэш."""
        with self._mid_lock:
            if self._mid and not force:
                return self._mid
            try:
                import urllib.request
                req = urllib.request.Request(WUM_URL, headers={"User-Agent": UA})
                with urllib.request.urlopen(req, timeout=10) as r:
                    text = r.read().decode("utf-8", "replace")
                m = re.search(r"(?:umx\.wu|__fycb)\('([^']+)'\)", text)
                self._mid = m.group(1) if m else None
            except Exception as e:
                log.debug("qwen_web midtoken: %s", e)
                self._mid = None
            return self._mid

    def _headers(self, force_mid=False) -> dict:
        h = {
            "User-Agent": UA,
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.5",
            "Origin": self.base,
            "Referer": self.base + "/",
            "Content-Type": "application/json",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "X-Requested-With": "XMLHttpRequest",
            "source": "web",
            "version": "0.2.63",
            "X-Accel-Buffering": "no",
            "x-request-id": str(uuid.uuid4()),
        }
        if self.cookie:
            h["Cookie"] = self.cookie
        if self.token:
            h["Authorization"] = "Bearer " + self.token
        mid = self._midtoken(None, force=force_mid)
        if mid:
            h["bx-umidtoken"] = mid
            h["bx-v"] = "2.5.36"
        return h

    def _req(self, path: str, method="GET", payload=None, timeout=30, force_mid=False):
        import urllib.request
        import urllib.error
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload is not None else None
        req = urllib.request.Request(self.base + path, data=data,
                                     headers=self._headers(force_mid), method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, r.read(), dict(r.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read(4000), dict(e.headers or {})
        except Exception as e:
            raise QwenWebError(f"{type(e).__name__}: {e}", -1) from e

    # ------------------------------------------------------------ модели
    def models(self, refresh=False) -> list:
        """[{id, types, search: bool}] — живьём с сайта, с фолбэком."""
        with self._lock:
            if not refresh and self._models["ids"] and time.time() - self._models["ts"] < 3600:
                ids, meta = self._models["ids"], self._models["meta"]
            else:
                ids, meta = [], {}
                try:
                    st, body, _h = self._req("/api/models", timeout=15)
                    if st == 200:
                        for m in (json.loads(body.decode("utf-8", "replace")) or {}).get("data") or []:
                            types = ((m.get("info") or {}).get("meta") or {}).get("chat_type") or []
                            if any(t in TEXTISH for t in types):
                                ids.append(m["id"])
                                meta[m["id"]] = list(types)
                except Exception as e:
                    log.debug("qwen_web models: %s", e)
                if not ids:
                    ids = list(FALLBACK_MODELS)
                    meta = {i: ["t2t", "search"] for i in ids}
                self._models = {"ids": ids, "meta": meta, "ts": time.time()}
        out = []
        for i in ids:
            t = meta.get(i, ["t2t"])
            out.append({"id": i, "types": t, "search": "search" in t})
        return out

    def model_ids_with_suffixes(self) -> list:
        out = []
        for m in self.models():
            out.append(m["id"])
            if m["search"]:
                out.append(m["id"] + ":search")
        return out

    # ------------------------------------------------------------ сообщения
    @staticmethod
    def _content_text(content) -> str:
        if content is None:
            return ""
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = []
            for p in content:
                if isinstance(p, dict):
                    if p.get("type") == "text" and p.get("text"):
                        parts.append(p["text"])
                    elif p.get("type") in ("image_url", "image"):
                        parts.append("[изображение]")
                elif isinstance(p, str):
                    parts.append(p)
            return "\n".join(parts)
        return str(content)

    def _build_chain(self, messages: list, model: str, chat_type: str,
                     thinking_mode: str | None) -> list:
        system_chunks, chain, parent = [], [], None
        now = int(time.time() * 1000)
        for i, m in enumerate(messages):
            role = (m.get("role") or "user").lower()
            text = self._content_text(m.get("content"))
            if role == "system":
                system_chunks.append(text)
                continue
            if role not in ("user", "assistant"):
                text = f"[{role}] {text}"
                role = "user"
            if role == "user" and system_chunks and not chain:
                text = "[System instructions]\n" + "\n".join(system_chunks) + "\n\n" + text
            fid = str(uuid.uuid4())
            chain.append({"fid": fid, "parentId": parent, "childrenIds": [], "role": role,
                          "content": text, "user_action": "chat", "files": [],
                          "timestamp": now + i, "models": [model], "chat_type": chat_type,
                          "sub_chat_type": chat_type,
                          "extra": {"meta": {"subChatType": chat_type}}})
            parent = fid
        if system_chunks and not chain:
            fid = str(uuid.uuid4())
            chain.append({"fid": fid, "parentId": None, "childrenIds": [], "role": "user",
                          "content": "\n".join(system_chunks), "user_action": "chat",
                          "files": [], "timestamp": now, "models": [model],
                          "chat_type": chat_type, "sub_chat_type": chat_type,
                          "extra": {"meta": {"subChatType": chat_type}}})
            parent = None
        if not chain:
            raise QwenWebError("пустой messages", 400)
        mode = (thinking_mode or self.thinking).strip().lower()
        if mode == "fast":
            fc = {"thinking_enabled": False, "output_schema": "phase", "thinking_budget": 81920}
        elif mode == "thinking":
            fc = {"auto_thinking": False, "thinking_mode": "Thinking", "thinking_enabled": True,
                  "output_schema": "phase", "research_mode": "normal", "auto_search": True}
        else:
            fc = {"auto_thinking": True, "thinking_mode": "Auto", "thinking_enabled": True,
                  "output_schema": "phase", "research_mode": "normal", "auto_search": True}
        chain[-1]["feature_config"] = fc
        return chain

    def _create_chat(self, model: str) -> str:
        payload = {"title": "New Chat", "models": [model], "chat_mode": "normal",
                   "chat_type": "t2t", "timestamp": int(time.time() * 1000), "project_id": ""}
        st, body, _h = self._req("/api/v2/chats/new", "POST", payload, timeout=30)
        txt = body.decode("utf-8", "replace")
        if st in (401, 403):
            raise QwenWebError(f"{st}: токен отклонён chat.qwen.ai — обнови токен "
                               f"(tools/token_snippet.js или меню/панель)", 401)
        if st == 429:
            raise QwenWebError("429: rate limit web-аккаунта qwen", 429)
        if st >= 400:
            raise QwenWebError(f"chats/new HTTP {st}: {txt[:200]}", st)
        try:
            data = json.loads(txt)
            cid = (data.get("data") or {}).get("id")
            if data.get("success") and cid:
                return cid
            # FIX v2.0.8: сайт может ответить HTTP 200 с success:false и кодом
            # unauthorized/"Token has expired" — раньше это ретраилось 4 раза как 502
            # вместо понятной подсказки и авто-фолбэка на другой провайдер
            blob = json.dumps(data, ensure_ascii=False).lower()
            if "unauthorized" in blob or "expired" in blob or "log in" in blob:
                raise QwenWebError(_expired_hint(), 401)
        except QwenWebError:
            raise
        except Exception:
            pass
        raise QwenWebError(f"chats/new: {txt[:200]}", 502)

    def _delete_chat(self, chat_id: str):
        try:
            self._req(f"/api/v2/chats/{chat_id}", "DELETE", timeout=15)
        except Exception:
            pass

    # ------------------------------------------------------------ чат
    def chat(self, messages: list, model: str = "qwen3.8-max", stream: bool = True,
             on_delta=None, timeout: int = 300) -> dict:
        """Возвращает {content, reasoning, usage, model, finish_reason} — как LLM._stream."""
        if not self.ready():
            raise QwenWebError("нет токена chat.qwen.ai: получи его через tools/token_snippet.js "
                               "(F12 → Console на https://chat.qwen.ai) и сохрани: меню → API-ключ "
                               "или файл qwen_web.key", 401)
        base_model, suffix = parse_model(model)
        types = ["t2t"]
        for m in self.models():
            if m["id"] == base_model:
                types = m["types"]
                break
        chat_type = "search" if (suffix == "search" and "search" in types) else "t2t"
        thinking_mode = {"think": "thinking", "fast": "fast"}.get(suffix)
        chain = self._build_chain(messages, base_model, chat_type, thinking_mode)
        # вариант B: только последнее сообщение (если сайт не примет историю)
        last_users = [m for m in chain if m["role"] == "user"]
        solo = [dict((last_users or chain)[-1], parentId=None)]
        variants = [chain, solo] if len(chain) > 1 else [chain]

        last_exc = None
        for attempt in range(4):
            msgs = variants[min(attempt, len(variants) - 1)]
            chat_id = None
            try:
                chat_id = self._create_chat(base_model)
                payload = {"stream": True, "version": "2.1", "incremental_output": True,
                           "chat_id": chat_id, "chat_mode": "normal", "model": base_model,
                           "parent_id": msgs[-1]["parentId"], "messages": msgs,
                           "timestamp": int(time.time() * 1000)}
                result = self._completions_stream(payload, chat_id, stream, on_delta, timeout)
                if self.clean_chats:
                    threading.Thread(target=self._delete_chat, args=(chat_id,), daemon=True).start()
                    chat_id = None
                result["model"] = model
                return result
            except QwenWebError as e:
                last_exc = e
                if chat_id and self.clean_chats:
                    threading.Thread(target=self._delete_chat, args=(chat_id,), daemon=True).start()
                if e.status == 401:
                    raise
                if e.status == 429 and attempt < 3:
                    self._mid = None
                    time.sleep(2)
                    continue
                if attempt == 0 and len(variants) > 1:
                    continue   # повтор без истории
                raise
            except Exception as e:
                last_exc = QwenWebError(f"{type(e).__name__}: {e}", -1)
                if attempt == 0 and len(variants) > 1:
                    continue
                raise last_exc
        raise last_exc or QwenWebError("upstream failed", 502)

    def _completions_stream(self, payload: dict, chat_id: str, stream: bool,
                            on_delta, timeout: int) -> dict:
        import urllib.request
        import codecs
        req = urllib.request.Request(
            f"{self.base}/api/v2/chat/completions?chat_id={chat_id}",
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers=self._headers(), method="POST")
        try:
            resp = urllib.request.urlopen(req, timeout=timeout)
        except Exception as e:
            code = getattr(e, "code", -1)
            raise QwenWebError(f"completions: {getattr(e, 'reason', e)}", code or -1) from e
        decoder = codecs.getincrementaldecoder("utf-8")("replace")
        text_parts, reason_parts, usage = [], [], {}
        thinking = False
        got_any = False
        buf = ""
        try:
            while True:
                chunk = resp.read(8192)
                if not chunk:
                    buf += decoder.decode(b"", True)
                else:
                    buf += decoder.decode(chunk)
                while "\n" in buf:
                    line, buf = buf.split("\n", 1)
                    line = line.strip("\r")
                    if not line.startswith("data:"):
                        continue
                    p = line[5:].strip()
                    if not p or p == "[DONE]":
                        continue
                    try:
                        j = json.loads(p)
                    except Exception:
                        continue
                    if j.get("error"):
                        eblob = json.dumps(j["error"], ensure_ascii=False).lower()
                        if "unauthorized" in eblob or "expired" in eblob or "log in" in eblob:
                            raise QwenWebError(_expired_hint(), 401)
                        raise QwenWebError(f"upstream error: {j['error'].get('code')}: "
                                           f"{j['error'].get('details')}", 502)
                    if j.get("usage"):
                        usage = j["usage"]
                    for ch in (j.get("choices") or []):
                        d = ch.get("delta") or {}
                        content = d.get("content")
                        if not content:
                            continue
                        got_any = True
                        phase = d.get("phase")
                        if phase == "think":
                            thinking = True
                            reason_parts.append(content)
                        elif phase == "answer":
                            thinking = False
                            text_parts.append(content)
                            if stream and on_delta:
                                try:
                                    on_delta(content)
                                except Exception:
                                    pass
                        else:
                            (reason_parts if thinking else text_parts).append(content)
                if not chunk:
                    break
        finally:
            try:
                resp.close()
            except Exception:
                pass
        if not got_any:
            raise QwenWebError("пустой ответ от chat.qwen.ai", 502)
        u = usage or {}
        pt = int(u.get("prompt_tokens") or u.get("input_tokens") or 0)
        ct = int(u.get("completion_tokens") or u.get("output_tokens") or 0)
        return {"content": "".join(text_parts), "reasoning": "".join(reason_parts),
                "usage": {"prompt_tokens": pt, "completion_tokens": ct,
                          "total_tokens": u.get("total_tokens") or (pt + ct)},
                "finish_reason": "stop", "tool_calls": []}


def _expired_hint() -> str:
    return ("⌛ токен chat.qwen.ai ИСТЁК (сайт просит войти снова). Обнови его: "
            "1) открой https://chat.qwen.ai и войди; 2) F12 → Console → вставь содержимое "
            "tools/token_snippet.js → Enter; 3) вставь токен в панель (блок API-ключи → Qwen-мост), "
            "в меню (API-ключ) или в файл qwen_web.key. Пока токен не обновлён, Flux автоматически "
            "работает через другой готовый провайдер (xkiro/ollama).")


def token_status() -> dict:
    """Статус JWT-токена qwen: none | ok | expired + срок годности из claims exp."""
    import base64
    import datetime as dt
    tok = get_qwen_token()
    if not tok:
        return {"state": "none", "detail": "токен не задан"}
    try:
        part = tok.split(".")[1]
        part += "=" * (-len(part) % 4)
        claims = json.loads(base64.urlsafe_b64decode(part.encode()))
        exp = int(claims.get("exp") or 0)
        if not exp:
            return {"state": "ok", "detail": "токен задан (срок не указан в JWT)"}
        left = exp - time.time()
        when = dt.datetime.fromtimestamp(exp).strftime("%d.%m.%Y %H:%M")
        if left <= 0:
            return {"state": "expired", "detail": f"истёк {when}",
                    "days": round(left / 86400, 1)}
        return {"state": "ok", "detail": f"действует до {when}",
                "days": round(left / 86400, 1)}
    except Exception:
        return {"state": "ok", "detail": "токен задан (format не распознан)"}


# ============================================================ АВТО-ТОКЕН ИЗ БРАУЗЕРА
# localStorage браузеров НЕ шифруется (в отличие от cookie), а токен chat.qwen.ai
# лежит там по ключу "token". Читаем LevelDB-файлы (Chromium) и sqlite (Firefox)
# ТОЛЬКО ЛОКАЛЬНО и только на чтение — токен никуда не отправляется.

def _jwt_exp(tok: str):
    import base64
    try:
        part = tok.split(".")[1]
        part += "=" * (-len(part) % 4)
        return int(json.loads(base64.urlsafe_b64decode(part.encode())).get("exp") or 0) or None
    except Exception:
        return None


def _scan_jwt_bytes(data: bytes) -> list:
    """Ищет JWT и как UTF-16LE (Chromium localStorage), и как ASCII (firefox/прочее)."""
    out = []
    for m in re.finditer(rb"e\x00y\x00J\x00", data):
        j, chars = m.start(), []
        while j + 1 < len(data):
            c, hi = data[j], data[j + 1]
            if hi == 0 and 0x20 <= c <= 0x7e:
                chars.append(chr(c))
                j += 2
            else:
                break
        s = re.match(r"[A-Za-z0-9_\-.]+", "".join(chars))
        if s and s.group(0).count(".") >= 2 and len(s.group(0)) > 60:
            out.append(s.group(0))
    for m in re.finditer(rb"eyJ[A-Za-z0-9_\-.]{60,}", data):
        out.append(m.group(0).decode("ascii", "replace"))
    seen, res = set(), []
    for t in out:
        t = t.strip('"').strip("'").rstrip(".")
        if t not in seen and t.count(".") == 2 and _jwt_exp(t):
            seen.add(t)
            res.append(t)
    return res


def _storage_files() -> list:
    """(source_name, kind, path) — где искать localStorage браузеров."""
    out = []
    la = os.environ.get("LOCALAPPDATA", "")
    ap = os.environ.get("APPDATA", "")
    home = str(Path.home())
    chrom_roots = []
    if la:
        for b in ("Google\\Chrome\\User Data", "Microsoft\\Edge\\User Data",
                  "BraveSoftware\\Brave-Browser\\User Data", "Chromium\\User Data",
                  "Vivaldi\\User Data"):
            chrom_roots.append(os.path.join(la, b))
    if ap:
        chrom_roots += [os.path.join(ap, "Opera Software\\Opera Stable"),
                        os.path.join(ap, "Opera Software\\Opera GX Stable")]
    for base in (home + "/.config/google-chrome", home + "/.config/microsoft-edge",
                 home + "/.config/BraveSoftware/Brave-Browser"):
        chrom_roots.append(base)
    for extra in (CFG.get("qwen_token_scan_dirs") or []):
        chrom_roots.append(str(extra))
    for root in chrom_roots:
        try:
            for prof in Path(root).glob("*/Local Storage/leveldb"):
                for f in list(prof.glob("*.log")) + list(prof.glob("*.ldb")):
                    out.append((f"{Path(root).name}::{prof.parent.parent.parent.name}", "leveldb", f))
        except Exception:
            continue
    ff_roots = []
    if ap:
        ff_roots.append(os.path.join(ap, "Mozilla\\Firefox\\Profiles"))
    ff_roots.append(home + "/.mozilla/firefox")
    for root in ff_roots:
        try:
            for f in Path(root).glob("*/webappsstore.sqlite"):
                out.append(("Firefox", "sqlite", f))
        except Exception:
            continue
    return out


def extract_token_from_browsers() -> dict:
    """Ищет свежий токен chat.qwen.ai в localStorage браузеров.
    Возвращает {token, source, exp} или {}."""
    best = None
    for src, kind, path in _storage_files():
        try:
            if path.stat().st_size > 60_000_000:
                continue
            if kind == "leveldb":
                data = path.read_bytes()
                if b"chat.qwen.ai" not in data and b"c\x00h\x00a\x00t\x00.\x00q\x00w\x00e\x00n" not in data:
                    continue
                for tok in _scan_jwt_bytes(data):
                    exp = _jwt_exp(tok)
                    if exp and (best is None or exp > best[0]):
                        best = (exp, tok, src)
            else:
                import sqlite3
                con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=2)
                try:
                    rows = con.execute(
                        "SELECT value FROM webappsstore2 WHERE scope LIKE '%qwen%' AND key='token'"
                    ).fetchall()
                except Exception:
                    rows = []
                con.close()
                for (v,) in rows:
                    tok = str(v).strip('"').strip("'")
                    exp = _jwt_exp(tok)
                    if exp and (best is None or exp > best[0]):
                        best = (exp, tok, src)
        except Exception as e:
            log.debug("qwen scan %s: %s", path, e)
            continue
    if not best:
        return {}
    return {"token": best[1], "source": best[2], "exp": best[0]}


def auto_refresh_token(force: bool = False) -> dict:
    """Авто-обновление токена qwen из браузера.
    force=True — перепроверить даже если текущий токен ещё живой."""
    if not CFG.get("qwen_auto_token", True):
        return {"updated": False, "reason": "авто-токен выключен (qwen_auto_token=false)"}
    cur = token_status()
    if not force and cur["state"] == "ok" and float(cur.get("days") or 99) > 0.25:
        return {"updated": False, "reason": f"текущий токен ещё жив ({cur['detail']})"}
    r = extract_token_from_browsers()
    if not r.get("token"):
        return {"updated": False,
                "reason": "в браузерах не найден токен chat.qwen.ai — открой сайт в браузере "
                          "(войди в аккаунт), сайт сам положит свежий токен в localStorage, "
                          "после чего повтори авто-токен"}
    if r["token"] == get_qwen_token() and cur["state"] == "ok":
        return {"updated": False, "reason": f"токен из {r['source']} уже используется"}
    save_qwen_token(r["token"])
    global _CLIENT
    _CLIENT["v"] = None
    st = token_status()
    log.info("qwen auto-token: обновлён из %s (%s)", r["source"], st["detail"])
    return {"updated": True, "source": r["source"], "detail": st["detail"]}


_CLIENT = {"v": None, "sig": ""}


def get_client() -> QwenWeb:
    """Единственный живой клиент; пересоздаётся при смене токена/настроек."""
    sig = f"{get_qwen_token()}|{CFG.get('qwen_cookie')}|{CFG.get('qwen_thinking')}|{CFG.get('qwen_base_url')}"
    if _CLIENT["v"] is None or _CLIENT["sig"] != sig:
        _CLIENT["v"] = QwenWeb()
        _CLIENT["sig"] = sig
    return _CLIENT["v"]
