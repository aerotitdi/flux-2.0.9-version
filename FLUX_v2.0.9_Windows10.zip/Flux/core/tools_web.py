# -*- coding: utf-8 -*-
"""
FLUX :: core/tools_web.py
Веб: поиск через локальный SearXNG (Docker, http://localhost:8888),
резервные поисковики без Docker, чтение страниц, скачивание, перевод, погода.
"""
from __future__ import annotations

import json
import re
import time
import urllib.parse
from pathlib import Path

from . import (CFG, DOWNLOAD_DIR, clip, download, exc_text, html_to_text, http_get_text,
               http_json, log, safe_filename, tools_log)
from .tools_system import OBJ, STR, INT, BOOL, ARR, NUM, resolve_path, tool


# ---------------------------------------------------------------- SearXNG
def searxng_base() -> str:
    return str(CFG.get("searxng_url") or "http://localhost:8888").rstrip("/")


def searxng_alive(timeout: float = 2.0) -> bool:
    from . import port_open
    u = urllib.parse.urlparse(searxng_base())
    return port_open(u.hostname or "localhost", int(u.port or 80), timeout)


def _searxng_page(base: str, params: dict) -> tuple:
    url = base + "/search?" + urllib.parse.urlencode(params)
    st, body = http_json(url, "GET", timeout=25)
    if st != 200 or not isinstance(body, dict):
        # SearXNG может требовать POST
        st, body = http_json(base + "/search", "POST",
                             headers={"Content-Type": "application/x-www-form-urlencoded",
                                      "Accept": "application/json"},
                             raw_body=urllib.parse.urlencode(params), timeout=25)
    return st, body


def searxng_search(query: str, limit: int = 6, categories: str = "general",
                   lang: str = "ru", time_range: str = "") -> dict:
    """v2.0.6: пагинация — до 250 результатов за один запрос (SearXNG отдаёт ~10-20/стр)."""
    base = searxng_base()
    results, seen, answers, infoboxes = [], set(), [], []
    pages = max(1, min(25, -(-limit // 10)))   # потолок страниц
    st = None
    for pageno in range(1, pages + 1):
        params = {
            "q": query,
            "format": "json",
            "categories": categories,
            "language": lang,
            "safesearch": "0",
            "pageno": str(pageno),
        }
        if time_range:
            params["time_range"] = time_range
        st, body = _searxng_page(base, params)
        if st != 200 or not isinstance(body, dict):
            if pageno == 1:
                return {"ok": False, "status": st, "error": str(body)[:300]}
            break
        if pageno == 1:
            answers = body.get("answers") or []
            infoboxes = [(i.get("infobox") or "")[:200] for i in (body.get("infoboxes") or [])[:2]]
        page_rows = body.get("results") or []
        if not page_rows:
            break
        for r in page_rows:
            title = (r.get("title") or "").strip()
            url_ = (r.get("url") or "").strip()
            content = (r.get("content") or "").strip()
            if not url_ or url_ in seen:
                continue
            seen.add(url_)
            results.append({
                "title": title[:200],
                "url": url_,
                "snippet": content[:500],
                "engine": ",".join(r.get("engines") or [])[:40],
                "published": r.get("publishedDate") or "",
            })
            if len(results) >= limit:
                break
        if len(results) >= limit:
            break
    return {"ok": True, "engine": "searxng", "count": len(results),
            "results": results[:limit], "answers": answers[:3],
            "infoboxes": infoboxes, "query": query, "pages_read": pageno}


# ---------------------------------------------------------------- резервные поисковики
def ddg_search(query: str, limit: int = 6) -> dict:
    """DuckDuckGo HTML-выдача (без ключей и без Docker)."""
    url = "https://html.duckduckgo.com/html/?" + urllib.parse.urlencode({"q": query, "kl": "ru-ru"})
    st, body = http_get_text(url, timeout=25)
    if st != 200:
        return {"ok": False, "error": f"ddg http {st}"}
    results = []
    for m in re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', body, re.S):
        href, title = m.group(1), re.sub(r"<[^>]+>", "", m.group(2)).strip()
        if href.startswith("//duckduckgo.com/l/?uddg="):
            href = urllib.parse.unquote(href.split("uddg=")[1].split("&")[0])
        elif href.startswith("/l/?"):
            href = urllib.parse.unquote(href.split("uddg=")[-1].split("&")[0])
        results.append({"title": title[:200], "url": href, "snippet": ""})
        if len(results) >= limit:
            break
    # сниппеты
    snips = re.findall(r'class="result__snippet"[^>]*>(.*?)</a>', body, re.S)
    for i, s in enumerate(snips[:len(results)]):
        results[i]["snippet"] = re.sub(r"<[^>]+>", "", s).strip()[:400]
    if not results:
        return {"ok": False, "error": "ddg: пустая выдача (возможно, блокировка)"}
    return {"ok": True, "engine": "duckduckgo-html", "count": len(results), "results": results}


def bing_search(query: str, limit: int = 6) -> dict:
    url = "https://www.bing.com/search?" + urllib.parse.urlencode({"q": query, "setlang": "ru", "count": limit})
    st, body = http_get_text(url, timeout=25, headers={"Accept-Language": "ru-RU,ru;q=0.9"})
    if st != 200:
        return {"ok": False, "error": f"bing http {st}"}
    results = []
    for m in re.finditer(r'<li class="b_algo".*?<h2><a href="([^"]+)"[^>]*>(.*?)</a></h2>(.*?)</li>', body, re.S):
        href, title, rest = m.group(1), re.sub(r"<[^>]+>", "", m.group(2)).strip(), m.group(3)
        sn = re.search(r'<p[^>]*>(.*?)</p>', rest, re.S)
        results.append({"title": title[:200], "url": href,
                        "snippet": (re.sub(r"<[^>]+>", "", sn.group(1)).strip()[:400] if sn else "")})
        if len(results) >= limit:
            break
    if not results:
        return {"ok": False, "error": "bing: пустая выдача"}
    return {"ok": True, "engine": "bing-html", "count": len(results), "results": results}


def wikipedia_search(query: str, limit: int = 3, lang: str = "ru") -> dict:
    try:
        api = f"https://{lang}.wikipedia.org/w/api.php?" + urllib.parse.urlencode({
            "action": "query", "list": "search", "srsearch": query, "srlimit": limit,
            "format": "json", "utf8": 1})
        st, body = http_json(api, timeout=20)
        if st != 200 or not isinstance(body, dict):
            return {"ok": False, "error": f"http {st}"}
        items = []
        for r in (body.get("query", {}).get("search") or []):
            items.append({"title": r.get("title"), "snippet": re.sub(r"<[^>]+>", "", r.get("snippet") or "")[:400],
                          "url": f"https://{lang}.wikipedia.org/wiki/" + urllib.parse.quote(str(r.get("title")).replace(" ", "_"))})
        return {"ok": True, "engine": "wikipedia", "count": len(items), "results": items}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def web_search_all(query: str, limit: int = 6, categories: str = "general", time_range: str = "") -> dict:
    """SearXNG -> ddg -> bing (авто-фолбэк)."""
    attempts = []
    if CFG.get("searxng_enabled", True):
        if searxng_alive(1.2):
            r = searxng_search(query, limit, categories, time_range=time_range)
            attempts.append({"engine": "searxng", "ok": r.get("ok"), "note": r.get("error", "")[:120]})
            if r.get("ok") and r.get("results"):
                r["attempts"] = attempts
                r["docker_searxng"] = True
                return r
        else:
            attempts.append({"engine": "searxng", "ok": False,
                             "note": "не запущен (docker: install_searxng.bat или docker compose up -d)"})
    _fb = {"ddg": ddg_search, "bing": bing_search}
    # FIX: настройка web_fallbacks в config.json существовала, но порядок был зашит в код
    order = [x for x in (CFG.get("web_fallbacks") or ["ddg", "bing"]) if x in _fb] or ["ddg", "bing"]
    for name in order:
        fn = _fb[name]
        try:
            r = fn(query, limit)
            attempts.append({"engine": name, "ok": r.get("ok"), "note": r.get("error", "")[:120]})
            if r.get("ok") and r.get("results"):
                r["attempts"] = attempts
                r["docker_searxng"] = False
                return r
        except Exception as e:
            attempts.append({"engine": name, "ok": False, "note": str(e)[:120]})
    w = wikipedia_search(query, limit=min(limit, 3))
    attempts.append({"engine": "wikipedia", "ok": w.get("ok")})
    if w.get("ok") and w.get("results"):
        w["attempts"] = attempts
        return w
    return {"ok": False, "error": "все поисковые движки недоступны", "attempts": attempts,
            "hint": "проверь интернет; запусти SearXNG: cd /d D:\\Flux && docker compose up -d"}


def fmt_results(res: dict, with_snippets: bool = True) -> str:
    if not res.get("ok"):
        return f"[поиск не удался] {res.get('error')} | попытки: {res.get('attempts')}"
    lines = [f"Движок: {res.get('engine')} | найдено: {res.get('count')}"]
    for a in (res.get("answers") or []):
        lines.append(f"❗ Ответ: {a}")
    for i, r in enumerate(res.get("results") or [], 1):
        lines.append(f"{i}. {r.get('title')}")
        lines.append(f"   {r.get('url')}")
        if with_snippets and r.get("snippet"):
            lines.append(f"   {r['snippet'][:300]}")
    return "\n".join(lines)


# ================================================================ ИНСТРУМЕНТЫ
@tool("web_search", "Поиск в интернете. Основной движок — локальный SearXNG в Docker (http://localhost:8888, агрегирует Google/Bing/DDG/Wikipedia/YouTube и т.д.). Если Docker не запущен — автоматически использует резервные движки. Используй для любых свежих данных: новости, цены, погода, документация, факты.",
      OBJ({"query": STR("Поисковый запрос (можно на русском)"),
           "limit": INT("Сколько результатов вернуть (по умолчанию 6, макс 250)"),
           "categories": {"type": "string", "enum": ["general", "news", "images", "videos", "it",
                                                     "science", "music", "files", "social media", "shopping"],
                          "description": "Категория SearXNG"},
           "time_range": {"type": "string", "enum": ["", "day", "week", "month", "year"],
                          "description": "Свежесть: day=за сутки, week=за неделю..."},
           "engine": {"type": "string", "enum": ["auto", "searxng", "ddg", "bing", "wikipedia"],
                      "description": "auto (по умолчанию) = SearXNG с авто-фолбэком"},
           "with_snippets": BOOL("Включать описания результатов (по умолчанию true)")}, ["query"]))
def t_web_search(args):
    q = str(args.get("query") or "").strip()
    if not q:
        return {"ok": False, "error": "пустой запрос"}
    limit = max(1, min(250, int(args.get("limit") or CFG.get("search_results", 6))))
    eng = (args.get("engine") or "auto").lower()
    tools_log.info("web_search [%s] %s", eng, q[:200])
    if eng == "searxng":
        res = searxng_search(q, limit, args.get("categories") or "general",
                             time_range=args.get("time_range") or "")
    elif eng == "ddg":
        res = ddg_search(q, limit)
    elif eng == "bing":
        res = bing_search(q, limit)
    elif eng == "wikipedia":
        res = wikipedia_search(q, min(limit, 5))
    else:
        res = web_search_all(q, limit, args.get("categories") or "general",
                             time_range=args.get("time_range") or "")
    res["formatted"] = fmt_results(res, args.get("with_snippets", True))
    return res


@tool("fetch_url", "Открыть веб-страницу и прочитать её текст (статьи, документация, форумы, новости). Поддерживает извлечение основного контента и JSON-API.",
      OBJ({"url": STR("Ссылка"),
           "extract": {"type": "string", "enum": ["text", "links", "main", "raw"],
                       "description": "text=весь текст, main=только статья, links=ссылки, raw=HTML"},
           "max_chars": INT("Максимум символов (по умолчанию 12000)"),
           "query": STR("Искать в странице этот текст и вернуть фрагменты вокруг него")}, ["url"]))
def t_fetch_url(args):
    url = str(args.get("url") or "").strip()
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    maxc = int(args.get("max_chars") or 12000)
    st, body = http_get_text(url, timeout=35)
    if st != 200:
        return {"ok": False, "status": st, "error": body[:400], "url": url}
    mode = args.get("extract") or "main"
    if mode == "raw":
        return {"ok": True, "url": url, "content_type": "html", "content": clip(body, maxc)}
    if mode == "links":
        links = []
        for m in re.finditer(r'<a[^>]+href="([^"#]+)"[^>]*>(.*?)</a>', body, re.S | re.I):
            href = urllib.parse.urljoin(url, m.group(1))
            txt = re.sub(r"<[^>]+>", " ", m.group(2)).strip()
            if href.startswith("http") and txt:
                links.append(f"{txt[:90]} -> {href}")
            if len(links) >= 60:
                break
        return {"ok": True, "url": url, "links": "\n".join(dict.fromkeys(links))}
    text = ""
    try:
        import trafilatura  # type: ignore
        text = trafilatura.extract(body, url=url, include_comments=False, favor_recall=True) or ""
    except Exception:
        text = ""
    if not text:
        m = re.search(r"(?is)<(article|main)[^>]*>(.*?)</\1>", body)
        chunk = m.group(2) if m else body
        text = html_to_text(chunk, limit=maxc * 2)
    title = ""
    mt = re.search(r"(?is)<title[^>]*>(.*?)</title>", body)
    if mt:
        title = re.sub(r"\s+", " ", mt.group(1)).strip()[:200]
    out = {"ok": True, "url": url, "title": title, "chars": len(text),
           "content": clip(text.strip(), maxc)}
    if args.get("query"):
        rx = re.compile(re.escape(str(args["query"])), re.I)
        frags = []
        for m in rx.finditer(text):
            s = max(0, m.start() - 220)
            frags.append(text[s:m.end() + 320].replace("\n", " "))
            if len(frags) >= 5:
                break
        out["matches"] = frags or "совпадений не найдено"
    return out


@tool("web_research", "ГЛУБОКОЕ ИССЛЕДОВАНИЕ: ищет по нескольким запросам, открывает лучшие страницы и возвращает готовую выжимку с источниками. Используй для сложных тем, сравнений, 'найди и разберись'.",
      OBJ({"topic": STR("Тема исследования"),
           "queries": ARR(STR("Список поисковых запросов (2-5 штук)"), "Разные формулировки для полноты"),
           "pages_to_read": INT("Сколько страниц открыть (по умолчанию 3, макс 12)"),
           "language": STR("Язык источников: ru / en / both (по умолчанию both)")}, ["topic"]))
def t_web_research(args):
    topic = str(args.get("topic") or "")
    queries = args.get("queries") or [topic]
    if isinstance(queries, str):
        queries = [queries]
    queries = [str(q) for q in queries if str(q).strip()][:5]
    pages_n = max(1, min(12, int(args.get("pages_to_read") or 3)))
    seen, all_results, texts = set(), [], []
    for q in queries:
        r = web_search_all(q, limit=5)
        for item in (r.get("results") or []):
            u = item.get("url")
            if u and u not in seen:
                seen.add(u)
                item["via_query"] = q
                all_results.append(item)
    # ранжируем: предпочитаем НЕ-wikipedia и длинные сниппеты
    # FIX: раньше wikipedia получала +60 — ровно наоборот задуманному
    def score(it):
        s = len(it.get("snippet") or "")
        u = it.get("url") or ""
        if "wikipedia.org" in u:
            s -= 60
        if any(d in u for d in ("youtube.com", "facebook.com", "instagram.com", "tiktok.com")):
            s -= 300
        return s
    all_results.sort(key=score, reverse=True)
    for it in all_results[:pages_n]:
        try:
            st, body = http_get_text(it["url"], timeout=30)
            if st == 200:
                txt = html_to_text(body, limit=7000)
                if len(txt) > 400:
                    texts.append(f"### {it.get('title')}\nURL: {it['url']}\n{txt[:5000]}")
        except Exception:
            continue
    return {"ok": True, "topic": topic, "queries_used": queries,
            "sources": [{"title": i.get("title"), "url": i.get("url"), "snippet": i.get("snippet")}
                        for i in all_results[:12]],
            "pages_read": len(texts),
            "digest": ("\n\n".join(texts))[:22000] or "не удалось открыть страницы — используй sources",
            "instruction": "Сделай вывод по digest и обязательно укажи ссылки источников."}


@tool("weather", "Погода сейчас и прогноз (Open-Meteo, без ключа). Город можно указать названием — геокодинг встроен.",
      OBJ({"city": STR("Город, например: Москва, Kazan, New York. Пусто = определить по IP"),
           "days": INT("Прогноз на N дней (1-7, по умолчанию 3)")}, []))
def t_weather(args):
    city = str(args.get("city") or "").strip()
    days = max(1, min(7, int(args.get("days") or 3)))
    lat = lon = None
    name = city
    if city:
        geo = "https://geocoding-api.open-meteo.com/v1/search?" + urllib.parse.urlencode(
            {"name": city, "count": 1, "language": "ru", "format": "json"})
        st, body = http_json(geo, timeout=20)
        if st == 200 and isinstance(body, dict) and body.get("results"):
            r0 = body["results"][0]
            lat, lon, name = r0.get("latitude"), r0.get("longitude"), r0.get("name")
    if lat is None:
        st, body = http_json("https://ipapi.co/json/", timeout=15)
        if st == 200 and isinstance(body, dict):
            lat, lon = body.get("latitude"), body.get("longitude")
            name = name or body.get("city") or "по IP"
    if lat is None:
        return {"ok": False, "error": "не удалось определить координаты — укажи город явно"}
    wurl = ("https://api.open-meteo.com/v1/forecast?" + urllib.parse.urlencode({
        "latitude": lat, "longitude": lon,
        "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,pressure_msl",
        "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset",
        "timezone": "auto", "forecast_days": days}))
    st, body = http_json(wurl, timeout=25)
    if st != 200 or not isinstance(body, dict):
        return {"ok": False, "error": f"open-meteo http {st}"}
    codes = {0: "ясно", 1: "преимущественно ясно", 2: "переменная облачность", 3: "пасмурно",
             45: "туман", 48: "изморозь", 51: "лёгкая морось", 53: "морось", 55: "сильная морось",
             61: "небольшой дождь", 63: "дождь", 65: "сильный дождь", 66: "ледяной дождь",
             71: "небольшой снег", 73: "снег", 75: "сильный снег", 77: "снежные зёрна",
             80: "ливень", 81: "сильный ливень", 82: "очень сильный ливень",
             85: "снегопад", 86: "сильный снегопад", 95: "гроза", 96: "гроза с градом", 99: "сильная гроза с градом"}
    cur = body.get("current") or {}
    daily = body.get("daily") or {}
    forecast = []
    for i in range(len(daily.get("time") or [])):
        forecast.append({
            "date": daily["time"][i],
            "weather": codes.get(daily.get("weather_code", [None])[i], "?"),
            "t_max": daily.get("temperature_2m_max", [None])[i],
            "t_min": daily.get("temperature_2m_min", [None])[i],
            "precip_prob": daily.get("precipitation_probability_max", [None])[i],
            "wind": daily.get("wind_speed_10m_max", [None])[i],
            "sunrise": daily.get("sunrise", [None])[i],
            "sunset": daily.get("sunset", [None])[i],
        })
    return {"ok": True, "place": name, "coords": f"{lat},{lon}",
            "now": {"temp_c": cur.get("temperature_2m"), "feels_like": cur.get("apparent_temperature"),
                    "weather": codes.get(cur.get("weather_code"), "?"),
                    "humidity": cur.get("relative_humidity_2m"),
                    "wind_kmh": cur.get("wind_speed_10m"), "pressure_hpa": cur.get("pressure_msl"),
                    "local_time": cur.get("time")},
            "forecast": forecast, "source": "open-meteo.com"}


@tool("translate", "Перевести текст или веб-страницу (Google translate без ключа). Любой язык <-> русский/английский.",
      OBJ({"text": STR("Текст для перевода (или URL страницы)"),
           "target": STR("Код языка назначения: ru, en, de, es, zh... (по умолчанию ru)"),
           "source": STR("Код исходного языка (по умолчанию авто)")}, ["text"]))
def t_translate(args):
    text = str(args.get("text") or "")
    if re.match(r"^https?://", text, re.I):
        r = t_fetch_url({"url": text, "extract": "main", "max_chars": 12000})
        text = r.get("content") or ""
        if not text:
            return r
    target = (args.get("target") or "ru").lower()[:5]
    source = (args.get("source") or "auto").lower()[:5]
    # авто-определение по символам + защита от "перевода в тот же язык"
    if source == "auto":
        has_cyr = bool(re.search(r"[А-Яа-яЁё]", text[:400]))
        has_lat = bool(re.search(r"[A-Za-z]", text[:400]))
        source = "ru" if has_cyr and not has_lat else ("en" if has_lat and not has_cyr else "auto")
    if source == target:
        target = "en" if target == "ru" else "ru"
    url = "https://translate.googleapis.com/translate_a/single?" + urllib.parse.urlencode({
        "client": "gtx", "sl": source, "tl": target, "dt": "t", "q": text[:5000]})
    st, body = http_json(url, timeout=25)
    if st != 200 or not isinstance(body, list):
        # резерв: MyMemory
        url2 = "https://api.mymemory.translated.net/get?" + urllib.parse.urlencode(
            {"q": text[:1500], "langpair": f"{source if source != 'auto' else 'ru'}|{target}"})
        st, body = http_json(url2, timeout=25)
        if st == 200 and isinstance(body, dict):
            return {"ok": True, "engine": "mymemory",
                    "translated": body.get("responseData", {}).get("translatedText", "")}
        return {"ok": False, "error": f"перевод недоступен http {st}"}
    out = []
    detected = None
    for part in body:
        if isinstance(part, list):
            for seg in part:
                if isinstance(seg, list) and seg and isinstance(seg[0], str):
                    out.append(seg[0])
    try:
        detected = body[-1][0] if isinstance(body[-1], list) else None
    except Exception:
        pass
    return {"ok": True, "engine": "google-gtx", "detected_lang": detected, "target": target,
            "translated": "".join(out), "original_chars": len(text)}


@tool("download_media", "Скачать видео/аудио с YouTube и 1000+ сайтов через yt-dlp (если установлен), либо просто файл по прямой ссылке.",
      OBJ({"url": STR("Ссылка на видео/аудио/файл"),
           "format": {"type": "string", "enum": ["best", "audio", "video_720", "video_1080"],
                      "description": "Что качать"},
           "dest": STR("Папка назначения (по умолчанию Flux\\data\\media\\downloads)")}, ["url"]))
def t_download_media(args):
    url = str(args.get("url") or "")
    dest = resolve_path(args.get("dest") or str(DOWNLOAD_DIR))
    dest.mkdir(parents=True, exist_ok=True)
    fmt = args.get("format") or "best"
    have = _which("yt-dlp")
    if have:
        # FIX: cmd.exe не понимает одинарные кавычки — форматы 720/1080 не работали
        fmap = {"best": "-f \"bv*+ba/b\"", "audio": "-x --audio-format mp3",
                "video_720": "-f \"bv*[height<=720]+ba/b[height<=720]\"",
                "video_1080": "-f \"bv*[height<=1080]+ba/b[height<=1080]\""}
        from .tools_system import cmd_run
        cmd = f'"{have}" {fmap.get(fmt, "")} -o "{dest}\\%(title)s.%(ext)s" --no-playlist --restrict-filenames "{url}"'
        r = cmd_run(cmd, timeout=900)
        files = sorted(dest.glob("*"), key=lambda p: p.stat().st_mtime, reverse=True)[:3]
        return {"ok": r.get("code") == 0, "engine": "yt-dlp", "command": cmd,
                "output": clip((r.get("stdout") or "") + (r.get("stderr") or ""), 1500),
                "files": [str(f) for f in files]}
    # простая закачка по прямой ссылке
    d = download(url, dest / safe_filename(url.split("/")[-1].split("?")[0] or "media.bin"))
    if d.get("ok"):
        d["engine"] = "direct"
        return d
    return {"ok": False, "error": "yt-dlp не установлен, а прямая ссылка не скачалась",
            "hint": "установи: pip install yt-dlp  (и ffmpeg для склейки)"}


def _which(name: str) -> str | None:
    import shutil as _sh
    return _sh.which(name) or _sh.which(name + ".exe")


@tool("searxng_status", "Статус локального SearXNG в Docker: работает ли, какие движки доступны, как запустить/перезапустить.",
      OBJ({"action": {"type": "string", "enum": ["status", "start", "restart", "stop", "logs", "engines"],
                      "description": "Что сделать с контейнером"},
           "fix": BOOL("Если не работает — попробовать запустить автоматически")}, []))
def t_searxng_status(args):
    from .tools_system import cmd_run
    act = args.get("action") or "status"
    base = searxng_base()
    alive = searxng_alive(1.5)
    info = {"url": base, "alive": alive}
    if act == "status":
        if alive:
            st, body = http_json(base + "/config", timeout=10)
            if st == 200 and isinstance(body, dict):
                info["engines_count"] = len(body.get("engines") or [])
                info["instance_name"] = body.get("instance_name")
                info["default_lang"] = body.get("default_lang")
        else:
            r = cmd_run("docker ps -a --filter name=flux-searxng --format \"{{.Names}} {{.Status}}\"", timeout=30)
            info["docker_container"] = (r.get("stdout") or "").strip() or "контейнер не создан"
            info["hint"] = "запусти: install_searxng.bat  или  cd /d D:\\Flux && docker compose up -d"
            if args.get("fix"):
                from . import ROOT as _ROOT
                r2 = cmd_run("docker compose up -d", timeout=300, cwd=str(_ROOT))
                info["fix_attempt"] = clip((r2.get("stdout") or "") + (r2.get("stderr") or ""), 800)
                time.sleep(6)
                info["alive_after_fix"] = searxng_alive(2.0)
        return {"ok": True, **info}
    if act == "engines":
        st, body = http_json(base + "/config", timeout=15)
        if st == 200 and isinstance(body, dict):
            engs = [f"{e.get('name')} ({','.join(e.get('categories') or [])})"
                    for e in (body.get("engines") or []) if e.get("enabled")]
            return {"ok": True, "count": len(engs), "engines": "\n".join(engs[:120])}
        return {"ok": False, "error": "SearXNG недоступен", **info}
    cmdmap = {"start": "docker start flux-searxng", "stop": "docker stop flux-searxng",
              "restart": "docker restart flux-searxng", "logs": "docker logs --tail 60 flux-searxng"}
    r = cmd_run(cmdmap[act], timeout=120)
    return {"ok": r.get("code") == 0, "action": act,
            "output": clip((r.get("stdout") or "") + (r.get("stderr") or ""), 2500)}
