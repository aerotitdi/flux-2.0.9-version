@echo off
chcp 65001 >nul
echo.
echo  ============================================================
echo    FLUX :: удаление
echo    папка: %~dp0
echo  ============================================================
echo.
taskkill /FI "WINDOWTITLE eq FLUX*" /F >nul 2>&1
if exist "%~dp0data\flux_bg.stop" del "%~dp0data\flux_bg.stop" >nul 2>&1
echo stop> "%~dp0data\flux_bg.stop"
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*flux.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1

echo  [1/5] Снимаю автозагрузку ...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v FluxAI /f >nul 2>&1
schtasks /Delete /TN "FluxWatchdog" /F >nul 2>&1

echo  [2/5] Удаляю задачи планировщика, созданные Flux ...
for /f "tokens=*" %%t in ('schtasks /Query /FO CSV /NH 2^>nul ^| findstr /i "\\Flux_"') do (
  for /f "tokens=1 delims=," %%n in ("%%t") do schtasks /Delete /TN %%~n /F >nul 2>&1
)

echo  [3/5] Удаляю контейнер SearXNG ...
docker rm -f flux-searxng >nul 2>&1

echo  [4/5] Удаляю ярлыки и запись в реестре ...
del /q "%USERPROFILE%\Desktop\FLUX Ассистент.lnk" >nul 2>&1
del /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\FLUX AI.lnk" >nul 2>&1
del /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\FLUX (фон).lnk" >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\FluxAI" /f >nul 2>&1

echo  [5/5] Готово.
echo.
choice /c YN /m "  Удалить ВСЮ папку %~dp0 вместе с данными (сессии, память, скриншоты)"
if errorlevel 2 goto :keep
cd /d "%TEMP%"
rd /s /q "%~dp0." >nul 2>&1
echo  Папка удалена.
goto :end
:keep
echo  Данные оставлены в %~dp0
:end
echo.
pause
