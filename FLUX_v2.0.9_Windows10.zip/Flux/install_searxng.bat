@echo off
chcp 65001 >nul
setlocal
set "DEST=%~dp0"
set "DEST=%DEST:~0,-1%"

echo.
echo  ============================================================
echo    FLUX :: установка веб-поиска SearXNG в Docker
echo    адрес: http://localhost:8888
echo  ============================================================
echo.

where docker >nul 2>&1
if errorlevel 1 (
  echo  [X] Docker не установлен.
  echo      Скачай Docker Desktop: https://www.docker.com/products/docker-desktop/
  echo      После установки перезагрузи ПК и запусти этот файл снова.
  echo.
  echo      [i] Flux без SearXNG всё равно ищет в интернете через
  echo          DuckDuckGo/Bing — просто качество и приватность ниже.
  choice /c YN /m "  Открыть страницу загрузки Docker"
  if not errorlevel 2 start "" "https://www.docker.com/products/docker-desktop/"
  pause & exit /b 1
)

docker info >nul 2>&1
if errorlevel 1 (
  echo  [!] Docker установлен, но демон не запущен.
  echo      Запусти Docker Desktop, дождись значка кита в трее и повтори.
  start "" "C:\Program Files\Docker\Docker\Docker Desktop.exe" 2>nul
  pause & exit /b 1
)

echo  [1/3] Docker в порядке.
if not exist "%DEST%\searxng\settings.yml" (
  echo  [!] Нет %DEST%\searxng\settings.yml — создаю минимальный.
  mkdir "%DEST%\searxng" 2>nul
  > "%DEST%\searxng\settings.yml" echo use_default_settings: true
  >>"%DEST%\searxng\settings.yml" echo search:
  >>"%DEST%\searxng\settings.yml" echo   formats: [html, json]
  >>"%DEST%\searxng\settings.yml" echo server:
  >>"%DEST%\searxng\settings.yml" echo   secret_key: "flux-secret-8f3a1c"
  >>"%DEST%\searxng\settings.yml" echo   limiter: false
)

echo  [2/3] Запускаю контейнер flux-searxng ...
docker rm -f flux-searxng >nul 2>&1
docker run -d --name flux-searxng --restart unless-stopped -p 8888:8080 -v "%DEST%\searxng:/etc/searxng" -e "SEARXNG_BASE_URL=http://localhost:8888/" -e "SEARXNG_SECRET=flux-secret-8f3a1c" searxng/searxng:latest
if errorlevel 1 (
  echo  [!] docker run не сработал, пробую docker compose ...
  cd /d "%DEST%"
  docker compose up -d
)

echo  [3/3] Жду запуска SearXNG ...
set "OK="
for /l %%i in (1,1,40) do (
  if not defined OK (
    timeout /t 3 /nobreak >nul
    powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing 'http://localhost:8888/' -TimeoutSec 4; if ($r.StatusCode -eq 200) { 'UP' } } catch { }" 2>nul | findstr "UP" >nul
    if not errorlevel 1 set "OK=1"
  )
)

if defined OK (
  echo.
  echo  [OK] SearXNG работает: http://localhost:8888
  echo       JSON-API для Flux: http://localhost:8888/search?q=test^&format=json
  start "" "http://localhost:8888"
) else (
  echo.
  echo  [!] SearXNG не ответил за 2 минуты. Смотри логи:
  echo      docker logs flux-searxng
  echo      Типичная причина: settings.yml перезаписан — удали контейнер и повтори:
  echo      docker rm -f flux-searxng
)
echo.
pause
endlocal
