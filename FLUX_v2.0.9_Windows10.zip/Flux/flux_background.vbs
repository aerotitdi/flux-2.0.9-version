' ============================================================
'  FLUX :: фоновый режим с авто-перезапуском (watchdog)
'  Запуск: двойной клик. Окно не появляется.
'  Остановка: flux_stop.bat  (или Диспетчер задач)
'
'  FIX v2.0.4:
'   - защита от двойного запуска через WMI (реальный процесс, а не
'     lock-файл, который устаревал через 90 секунд и позволял
'     запустить второго Флюкса)
'   - поддержка FLUX.exe (фоновый режим собранной сборки)
' ============================================================
Option Explicit
Dim shell, fso, root, exe, script, cmd, rc, restarts, lockFile
Set shell = CreateObject("WScript.Shell")
Set fso   = CreateObject("Scripting.FileSystemObject")

root   = fso.GetParentFolderName(WScript.ScriptFullName)
script = root & "\flux.py"
exe    = root & "\FLUX.exe"
lockFile = root & "\data\flux_bg.lock"

If Not fso.FolderExists(root & "\data") Then fso.CreateFolder(root & "\data")

' ---------- защита от двойного запуска: ищем живой процесс ----------
Function AlreadyRunning()
    On Error Resume Next
    AlreadyRunning = False
    Dim wmi, procs, p, cl
    Set wmi = GetObject("winmgmts:\\.\root\cimv2")
    Set procs = wmi.ExecQuery("SELECT ProcessId, CommandLine FROM Win32_Process")
    For Each p In procs
        cl = p.CommandLine
        If Not IsNull(cl) Then
            If InStr(LCase(cl), "flux.py") > 0 Or InStr(LCase(cl), "flux.exe") > 0 Then
                ' не считаем сам этот скрипт и flux_stop
                If InStr(LCase(cl), "flux_background.vbs") = 0 And InStr(LCase(cl), "stop") = 0 Then
                    AlreadyRunning = True
                    Exit Function
                End If
            End If
        End If
    Next
End Function

If AlreadyRunning() Then
    WScript.Quit 0
End If

' ---------- чем запускать: FLUX.exe или python ----------
Dim py
If fso.FileExists(exe) Then
    py = """" & exe & """ --background --no-boot-check --no-menu"
ElseIf fso.FileExists(root & "\venv\Scripts\pythonw.exe") Then
    py = """" & root & "\venv\Scripts\pythonw.exe"" """ & script & """ --background --no-boot-check"
ElseIf fso.FileExists(root & "\venv\Scripts\python.exe") Then
    py = """" & root & "\venv\Scripts\python.exe"" """ & script & """ --background --no-boot-check"
Else
    py = "pythonw """ & script & """ --background --no-boot-check"
End If

shell.CurrentDirectory = root
restarts = 0

Do While True
    On Error Resume Next
    Dim f : Set f = fso.CreateTextFile(lockFile, True) : f.Write Now : f.Close
    On Error Goto 0

    rc = shell.Run(py, 0, True)

    If fso.FileExists(root & "\data\flux_bg.stop") Then
        fso.DeleteFile root & "\data\flux_bg.stop", True
        Exit Do
    End If

    restarts = restarts + 1
    If restarts > 30 Then Exit Do   ' защита от бесконечного цикла падений
    WScript.Sleep 5000
Loop

If fso.FileExists(lockFile) Then fso.DeleteFile lockFile, True
