@echo off
chcp 65001 >nul
title FLUX :: AI-ассистент
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "FLUX_VERBOSE=0"

rem FIX v2.0.4: сначала определяем интерпретатор, потом ОДИН запуск.
rem Раньше при любом ненулевом коде (в т.ч. нормальном выходе с ошибкой внутри)
rem flux.py запускался ВТОРОЙ раз уже другим python'ом.
set "PYCMD="
if exist "%~dp0venv\Scripts\python.exe" (
  set "PYCMD=%~dp0venv\Scripts\python.exe"
) else (
  py -3 -c "import sys" >nul 2>&1
  if not errorlevel 1 (
    set "PYCMD=py -3"
  ) else (
    set "PYCMD=python"
  )
)

%PYCMD% "%~dp0flux.py" %*
if errorlevel 1 (
  echo.
  echo  [X] Flux завершился с ошибкой. Смотри data\logs\flux.log
  echo      Диагностика:  flux_check.bat
  pause
)
