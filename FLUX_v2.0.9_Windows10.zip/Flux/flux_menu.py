# -*- coding: utf-8 -*-
"""
FLUX :: flux_menu.py
Стартовое меню FLUX.exe: полноэкранная анимация фона (матрица / звёзды / молнии /
плазма), 5 цветовых тем, навигация стрелками, быстрый запуск всех режимов,
ввод API-ключа, настройки. Работает в Windows Terminal, conhost (Win10+) и POSIX.

Вызывается из flux.py:  --menu  (в собранном EXE без аргументов — автоматически).
Управление: ↑↓/WS — выбор · Enter — запустить · 1-9,0 — быстрый пункт ·
T — тема · A — анимация · F1/? — справка · Q/Esc — выход.
"""
from __future__ import annotations

import math
import os
import random
import subprocess
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from core import (CFG, ROOT, SECRETS_FILE, USER_AGENT, http_json, port_open,
                  sanitize_key)

VERSION = "2.0.5"
try:
    import flux as _fx
    VERSION = getattr(_fx, "VERSION", VERSION)
except Exception:
    pass

IS_WIN = os.name == "nt"

# ============================================================ ТЕМЫ
# tail — градиент хвоста (яркий -> тёмный), head — «голова» потока,
# accent — рамка, title — логотип, dim — подсказки, sel_* — выбранный пункт
THEMES = {
    "cyan":    {"tail": [51, 45, 39, 33, 27, 23], "head": 159, "accent": 51,
                "title": 87, "dim": 66, "sel_fg": 23, "sel_bg": 51, "warn": 214},
    "matrix":  {"tail": [46, 40, 34, 28, 22, 22], "head": 157, "accent": 46,
                "title": 120, "dim": 60, "sel_fg": 22, "sel_bg": 46, "warn": 220},
    "synth":   {"tail": [213, 207, 201, 171, 135, 93], "head": 225, "accent": 213,
                "title": 219, "dim": 97, "sel_fg": 53, "sel_bg": 213, "warn": 228},
    "amber":   {"tail": [214, 208, 178, 172, 136, 94], "head": 222, "accent": 214,
                "title": 220, "dim": 130, "sel_fg": 94, "sel_bg": 214, "warn": 203},
    "ice":     {"tail": [153, 147, 117, 111, 75, 33], "head": 195, "accent": 153,
                "title": 189, "dim": 67, "sel_fg": 24, "sel_bg": 153, "warn": 210},
}
THEME_NAMES = list(THEMES.keys())
THEME_RU = {"cyan": "циан", "matrix": "матрица", "synth": "синтвейв",
            "amber": "янтарь", "ice": "лёд"}

ANIMS = ["matrix", "stars", "bolts", "wave", "off"]
ANIM_RU = {"matrix": "матрица", "stars": "звёзды", "bolts": "молнии",
           "wave": "плазма", "off": "выкл"}

TITLE_ART = [
    r"  ______ __    __  __  __",
    r" / ____// /   / / / / / /",
    r"/ /_   / /   / / / /_/ / ",
    r"/ __/  / /___/ /_/ __  / ",
    r"/_/   /_____/\____/_/ /_/",
]

MENU_ITEMS = [
    ("run",        "Запустить ассистента",  "чат-режим в консоли"),
    ("background", "Фоновый режим",         "голос + сторож + веб-панель"),
    ("gui",        "GUI-окно",              "виджет поверх всех окон"),
    ("check",      "Диагностика",           "ключ, сеть, движки (--check)"),
    ("selftest",   "Самотестирование",      "все инструменты (--selftest)"),
    ("panel",      "Веб-панель",            "открыть панель в браузере"),
    ("key",        "API-ключ",              "ввести / проверить ключ xkiro"),
    ("theme",      "Тема и анимация",       "оформление этого меню"),
    ("settings",   "Настройки",             "голос, проактивность, звуки"),
    ("exit",       "Выход",                 ""),
]

SETTINGS_KEYS = [("Озвучка ответов", "voice_output"), ("Голосовой ввод", "voice_input"),
                 ("Проактивный сторож", "proactive"), ("Звуковые эффекты", "sound_fx"),
                 ("Провайдер моделей", "@provider"), ("Только free-модели", "@free"),
                 ("Qwen: рассуждения", "@think")]
PROV_IDS = ["xkiro", "qwen_web", "ollama", "bridge"]
THINK_IDS = ["auto", "thinking", "fast"]


def _set_row_value(i: int) -> str:
    k = SETTINGS_KEYS[i][1]
    if k == "@provider":
        return str(CFG.get("provider") or "xkiro")
    if k == "@free":
        return "вкл" if CFG.get("prefer_free_models", True) else "выкл"
    if k == "@think":
        return str(CFG.get("qwen_thinking") or "auto")
    return "ВКЛ" if CFG.get(k, True) else "ВЫКЛ"


SET_DESC = {
    "voice_output": "Флюкс озвучивает ответы и уведомления голосом (pyttsx3 / edge-tts / системный SAPI). Выкл — тихий режим, только текст.",
    "voice_input": "Микрофон: wake word «Флюкс, ...» и push-to-talk Ctrl+Alt+F. Выкл — Флюкс не слушает микрофон вообще.",
    "proactive": "Сторож: раз в 3 мин сам проверяет диск, память, CPU, батарею, Защитник Windows и сбои программ — и сам предупреждает о важном.",
    "sound_fx": "Короткие бипы: wake word пойман, таймер сработал, уведомление. Выкл — полная тишина.",
    "@provider": "Куда уходят запросы: xkiro = api.xkiro.com (ключ), qwen_web = чат qwen.ai БЕЗ лимитов, ollama = локальные модели, bridge = внешний мост :8000.",
    "@free": "Free-режим: в /model и панели бесплатные модели идут первыми, авто-фолбэк предпочитает их.",
    "@think": "Рассуждения qwen (только qwen_web): auto — сам решает, thinking — всегда думает (phase think), fast — отвечает быстрее, без рассуждений.",
}


def _set_row_cycle(i: int, d: int) -> str:
    """d=0 — переключить (toggle/следующий), d=±1 — листать список."""
    k = SETTINGS_KEYS[i][1]
    if k == "@provider":
        cur = str(CFG.get("provider") or "xkiro")
        idx = PROV_IDS.index(cur) if cur in PROV_IDS else 0
        nv = PROV_IDS[(idx + (d or 1)) % len(PROV_IDS)]
        CFG.set("provider", nv)
        return nv
    if k == "@free":
        v = not bool(CFG.get("prefer_free_models", True))
        CFG.set("prefer_free_models", v)
        return "вкл" if v else "выкл"
    if k == "@think":
        cur = str(CFG.get("qwen_thinking") or "auto")
        idx = THINK_IDS.index(cur) if cur in THINK_IDS else 0
        nv = THINK_IDS[(idx + (d or 1)) % len(THINK_IDS)]
        CFG.set("qwen_thinking", nv)
        try:
            from core import qwen_web as _q
            _q._CLIENT["v"] = None
        except Exception:
            pass
        return nv
    v = not bool(CFG.get(k, True))
    CFG.set(k, v)
    return "ВКЛ" if v else "ВЫКЛ"

_FORCE_REDRAW = {"v": True}
_TERM = None


# ============================================================ терминал
class Term:
    """Консоль: alt-screen, курсор, raw-ввод, VT-режим (Win10+)."""

    def __init__(self):
        self.w, self.h = 80, 24
        self.is_tty = bool(sys.stdout.isatty() and sys.stdin.isatty())
        self._old_termios = None
        self.resize()

    def resize(self):
        try:
            import shutil
            c = shutil.get_terminal_size((80, 24))
            self.w, self.h = max(40, c.columns), max(12, c.lines)
        except Exception:
            pass

    def _enable_vt(self):
        if IS_WIN:
            try:
                import ctypes
                k = ctypes.windll.kernel32
                h = k.GetStdHandle(-11)
                mode = ctypes.c_uint()
                if k.GetConsoleMode(h, ctypes.byref(mode)):
                    k.SetConsoleMode(h, mode.value | 0x0004)
            except Exception:
                pass

    def enter(self):
        self._enable_vt()
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
        self.out("\x1b[?1049h\x1b[?25l\x1b[2J")
        _FORCE_REDRAW["v"] = True
        if not IS_WIN:
            try:
                import termios
                import tty
                if self._old_termios is None:
                    self._old_termios = termios.tcgetattr(sys.stdin.fileno())
                tty.setraw(sys.stdin.fileno())
            except Exception:
                pass

    def leave(self):
        self.out("\x1b[?25h\x1b[0m\x1b[2J\x1b[H\x1b[?1049l")
        if self._old_termios is not None:
            try:
                import termios
                termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, self._old_termios)
            except Exception:
                pass
            self._old_termios = None

    def cooked(self):
        self.out("\x1b[?25h\x1b[0m")
        if self._old_termios is not None:
            try:
                import termios
                termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, self._old_termios)
            except Exception:
                pass

    def raw_again(self):
        self.out("\x1b[?25l")
        if not IS_WIN and self._old_termios is not None:
            try:
                import termios
                import tty
                tty.setraw(sys.stdin.fileno())
            except Exception:
                pass

    @staticmethod
    def out(s: str):
        try:
            sys.stdout.write(s)
            sys.stdout.flush()
        except Exception:
            pass

    _WIN_SPECIAL = {"\xe0H": "UP", "\xe0P": "DOWN", "\xe0K": "LEFT", "\xe0M": "RIGHT",
                    "\x00H": "UP", "\x00P": "DOWN", "\x00K": "LEFT", "\x00M": "RIGHT",
                    "\x00;": "F1", "\xe0;": "F1"}

    def read_keys(self) -> list:
        keys = []
        try:
            if IS_WIN:
                import msvcrt
                while msvcrt.kbhit():
                    ch = msvcrt.getwch()
                    if ch in ("\x00", "\xe0"):
                        ch2 = msvcrt.getwch()
                        keys.append(self._WIN_SPECIAL.get(ch + ch2, ""))
                    elif ch == "\r":
                        keys.append("ENTER")
                    elif ch == "\x1b":
                        keys.append("ESC")
                    elif ch >= " ":
                        keys.append(ch)
            else:
                import select
                while select.select([sys.stdin], [], [], 0)[0]:
                    ch = sys.stdin.read(1)
                    if ch == "\x1b":
                        seq = ""
                        if select.select([sys.stdin], [], [], 0.02)[0]:
                            seq = sys.stdin.read(1)
                            if seq == "[" and select.select([sys.stdin], [], [], 0.02)[0]:
                                seq += sys.stdin.read(1)
                        keys.append({"[A": "UP", "[B": "DOWN", "[C": "RIGHT",
                                     "[D": "LEFT", "[1": "F1"}.get(seq, "ESC"))
                    elif ch in ("\r", "\n"):
                        keys.append("ENTER")
                    elif ch == "\x7f":
                        keys.append("BACKSPACE")
                    elif ch >= " ":
                        keys.append(ch)
        except Exception:
            pass
        return [k for k in keys if k]


# ============================================================ экран-буфер
class Screen:
    """Символьный буфер W×H (256 цветов) с дифф-рендером — без мерцания."""

    def __init__(self, term: Term):
        self.term = term
        self.w = self.h = 0
        self.cells = []
        self.prev_lines = []
        self.set_size(term.w, term.h)

    def set_size(self, w, h):
        self.w, self.h = w, h
        self.cells = [[(" ", None, None) for _ in range(w)] for _ in range(h)]
        self.prev_lines = ["\x01"] * h

    def clear(self):
        blank = (" ", None, None)
        for y in range(self.h):
            row = self.cells[y]
            for x in range(self.w):
                row[x] = blank

    def put(self, x, y, s, fg=None, bg=None):
        if y < 0 or y >= self.h or not s:
            return
        row = self.cells[y]
        i = x
        for ch in s:
            if 0 <= i < self.w:
                row[i] = (ch, fg, bg)
            i += 1

    def invalidate(self):
        self.prev_lines = ["\x01"] * self.h

    def render(self):
        out = []
        for y in range(self.h):
            parts = []
            cur_fg = cur_bg = "\x00"
            for (ch, fg, bg) in self.cells[y]:
                if fg != cur_fg or bg != cur_bg:
                    parts.append("\x1b[0m")
                    if fg is not None:
                        parts.append(f"\x1b[38;5;{fg}m")
                    if bg is not None:
                        parts.append(f"\x1b[48;5;{bg}m")
                    cur_fg, cur_bg = fg, bg
                parts.append(ch)
            parts.append("\x1b[0m")
            line = "".join(parts)
            if line != self.prev_lines[y]:
                out.append(f"\x1b[{y + 1};1H{line}")
                self.prev_lines[y] = line
        if out:
            self.term.out("".join(out))


# ============================================================ анимации фона
class MatrixRain:
    CH = "アイウエオカキクケコサシスセソタチツテトナニヌネノ0123456789ABCDEFZ<>+-*#$%&@ФЛЮКС"

    def __init__(self):
        self.cols = {}

    def reset(self, w, h, rnd):
        self.cols = {x: [rnd.uniform(-h, h * 0.5), rnd.uniform(0.3, 1.2), rnd.randint(5, 16)]
                     for x in range(w) if rnd.random() < 0.6}

    def tick(self, scr: Screen, th: dict, rnd):
        for x, drop in self.cols.items():
            if x >= scr.w:
                continue
            drop[0] += drop[1]
            head, length = int(drop[0]), drop[2]
            for k in range(length):
                y = head - k
                if 0 <= y < scr.h:
                    if k == 0:
                        scr.put(x, y, rnd.choice(self.CH), th["head"])
                    else:
                        col = th["tail"][min(k, len(th["tail"]) - 1)]
                        ch = scr.cells[y][x][0]
                        if ch == " " or rnd.random() < 0.05:
                            ch = rnd.choice(self.CH)
                        scr.put(x, y, ch, col)
            if head - length > scr.h + 2:
                drop[0] = rnd.uniform(-14, -2)
                drop[1] = rnd.uniform(0.3, 1.2)
                drop[2] = rnd.randint(5, 16)


class Stars:
    def __init__(self):
        self.stars = []

    def reset(self, w, h, rnd):
        self.stars = [[rnd.uniform(0, w), rnd.uniform(0, h), rnd.uniform(0.04, 0.3),
                       rnd.uniform(0, 6.28), rnd.choice("·+*✦◇")]
                      for _ in range(max(30, w * h // 26))]

    def tick(self, scr: Screen, th: dict, rnd):
        t = time.time()
        for s in self.stars:
            s[0] -= s[2] * 0.4
            s[1] += s[2]
            if s[0] < 0:
                s[0] = scr.w - 1
            if s[1] >= scr.h:
                s[1] = 0.0
                s[0] = rnd.uniform(0, scr.w)
            tw = (math.sin(t * 2.4 + s[3]) + 1) / 2
            col = th["head"] if tw > 0.88 else th["tail"][0 if tw > 0.5 else 2]
            scr.put(int(s[0]), int(s[1]), s[4], col)


class Bolts:
    SYM = "⚡◆▮·+FLUX"

    def __init__(self):
        self.drops = []

    def reset(self, w, h, rnd):
        self.drops = [[rnd.uniform(0, w), rnd.uniform(-h, 0), rnd.uniform(0.4, 1.5),
                       rnd.randint(3, 9)] for _ in range(max(10, w // 5))]

    def tick(self, scr: Screen, th: dict, rnd):
        for d in self.drops:
            d[1] += d[2]
            x, y = int(d[0]), int(d[1])
            for k in range(d[3]):
                yy = y - k
                if 0 <= yy < scr.h and 0 <= x < scr.w:
                    ch = "⚡" if k == 0 and rnd.random() < 0.4 else rnd.choice(self.SYM)
                    col = th["head"] if k == 0 else th["tail"][min(k, len(th["tail"]) - 1)]
                    scr.put(x, yy, ch, col)
            if y - d[3] > scr.h:
                d[1] = rnd.uniform(-12, -2)
                d[0] = rnd.uniform(0, scr.w)


class Wave:
    SHADES = " .·:-=+*#%@"

    def tick(self, scr: Screen, th: dict, rnd):
        t = time.time() * 0.9
        for y in range(scr.h):
            for x in range(0, scr.w, 2):
                v = (math.sin(x * 0.11 + t) + math.sin(y * 0.21 - t * 1.3)
                     + math.sin((x + y) * 0.07 + t * 0.6)) / 3.0
                idx = int((v + 1) / 2 * (len(self.SHADES) - 1))
                col = th["tail"][max(0, min(len(th["tail"]) - 1, 5 - idx // 2))]
                scr.put(x, y, self.SHADES[idx], col)


ANIM_CLASSES = {"matrix": MatrixRain, "stars": Stars, "bolts": Bolts, "wave": Wave}


# ============================================================ состояние
class MenuState:
    def __init__(self):
        self.theme = str(CFG.get("menu_theme") or "cyan")
        if self.theme not in THEMES:
            self.theme = "cyan"
        self.anim = str(CFG.get("menu_anim") or "matrix")
        if self.anim not in ANIMS:
            self.anim = "matrix"
        self.sel = 0          # курсор главного меню
        self.sel_row = 0      # курсор подменю «тема» (0=тема, 1=анимация)
        self.sel_set = 0      # курсор подменю «настройки»
        self.page = "main"    # main | theme | settings | help
        self.msg = ""
        self.msg_until = 0.0
        self.key_state = "..."
        self.searxng = "..."
        self.qwen = {"state": "none", "detail": ""}
        self.dirty_net = True

    def save_look(self):
        CFG.set("menu_theme", self.theme, save=False)
        CFG.set("menu_anim", self.anim, save=False)
        CFG.save()

    def say_msg(self, text, sec=3.2):
        self.msg = text
        self.msg_until = time.time() + sec


def _net_checks(st: MenuState, stop: threading.Event):
    """Проверки ключа/SearXNG в фоне — чтобы не тормозить анимацию."""
    while not stop.is_set():
        if st.dirty_net:
            st.dirty_net = False
            try:
                from core import get_api_key, masked_key
                k = get_api_key()
                if not k:
                    st.key_state = "НЕТ"
                else:
                    stt, _b = http_json(str(CFG.get("base_url")).rstrip("/") + "/models",
                                        timeout=8,
                                        headers={"User-Agent": USER_AGENT,
                                                 "Authorization": "Bearer " + k})
                    st.key_state = (masked_key().split(" ")[0] if stt == 200
                                    else f"ошибка HTTP {stt}")
            except Exception:
                st.key_state = "?"
            try:
                import urllib.parse
                u = urllib.parse.urlparse(str(CFG.get("searxng_url") or "http://localhost:8888"))
                st.searxng = ("работает" if port_open(u.hostname or "localhost",
                                                      int(u.port or 80), 0.8) else "не запущен")
            except Exception:
                st.searxng = "?"
            try:
                from core.qwen_web import token_status
                st.qwen = token_status()
            except Exception:
                st.qwen = {"state": "none", "detail": ""}
        stop.wait(12)


# ============================================================ отрисовка
def draw(scr: Screen, st: MenuState, frame: int):
    th = THEMES[st.theme]
    w, h = scr.w, scr.h
    bw = min(66, w - 4)
    bh = min(27, h - 5)
    bx = (w - bw) // 2
    by = max(1, (h - bh) // 2)

    # рамка
    scr.put(bx, by, "╔" + "═" * (bw - 2) + "╗", th["accent"])
    for i in range(1, bh - 1):
        scr.put(bx, by + i, "║", th["accent"])
        scr.put(bx + bw - 1, by + i, "║", th["accent"])
    scr.put(bx, by + bh - 1, "╚" + "═" * (bw - 2) + "╝", th["accent"])

    x, iw = bx + 2, bw - 4
    # ---- логотип с «бликом»
    shimmer = (frame // 3) % 46
    for i, ln in enumerate(TITLE_ART):
        xx = x + max(0, (iw - len(ln)) // 2)
        run_start, run_col = xx, None
        for j, ch in enumerate(ln):
            d = abs(((shimmer + j + i * 5) % 46) - 23)
            col = th["head"] if d <= 5 else th["title"]
            if col != run_col:
                if run_col is not None:
                    scr.put(run_start, by + 1 + i, ln[run_start - xx:j], run_col)
                run_start, run_col = xx + j, col
        scr.put(run_start, by + 1 + i, ln[run_start - xx:], run_col)

    sub = f"AI-ассистент · v{VERSION} · qwen 3.8 max free · api.xkiro.com"
    scr.put(x + max(0, (iw - len(sub)) // 2), by + 7, sub, th["dim"])
    scr.put(x, by + 8, "─" * iw, th["tail"][-1])
    cy = by + 9

    if st.page == "main":
        for i, (_key, name, hint) in enumerate(MENU_ITEMS):
            if cy + i >= by + bh - 1:
                break
            num = f"{(i + 1) % 10}"
            if i == st.sel:
                base = f" ▸ {num}. {name}"
                if hint:
                    pad = max(1, iw - len(base) - len(hint) - 1)
                    line = (base + " " * pad + hint)[:iw]
                else:
                    line = (base + " " * iw)[:iw]
                scr.put(x, cy + i, line, th["sel_fg"], th["sel_bg"])
            else:
                scr.put(x, cy + i, f"   {num}. {name}", None)
                if hint:
                    scr.put(x + iw - len(hint) - 1, cy + i, hint, th["dim"])
    elif st.page == "theme":
        rows = [(f"Тема:  «{THEME_RU[st.theme]}»", st.sel_row == 0),
                (f"Фон:   «{ANIM_RU[st.anim]}»", st.sel_row == 1)]
        for i, (label, sel) in enumerate(rows):
            line = f" {'▸' if sel else ' '} {label}".ljust(iw)[:iw]
            if sel:
                scr.put(x, cy + i, line, th["sel_fg"], th["sel_bg"])
            else:
                scr.put(x, cy + i, line.strip(), None)
        hints = ["← → — листать варианты      T / N — то же самое с клавиатуры",
                 "Enter — сохранить и выйти   Esc — выйти (выбор уже применён)",
                 "",
                 "фон меню показывает выбор вживую — просто листай"]
        for i, hln in enumerate(hints):
            scr.put(x, cy + 3 + i, hln, th["dim"])
    elif st.page == "settings":
        for i, (label, _key) in enumerate(SETTINGS_KEYS):
            val = _set_row_value(i)
            line = f" {'▸' if i == st.sel_set else ' '} {label}:"
            on = val in ("ВКЛ", "вкл")
            if i == st.sel_set:
                scr.put(x, cy + i, line.ljust(iw - 14)[:iw - 14], th["sel_fg"], th["sel_bg"])
                scr.put(x + len(line) + 1, cy + i, f" {val} ", 46 if on else (th["head"] if not on else 203),
                        th["sel_bg"])
            else:
                scr.put(x, cy + i, line, None)
                scr.put(x + len(line) + 1, cy + i, f" {val} ", 46 if on else th["dim"])
        # v2.0.6.1: живая подсказка — что значит выбранный параметр
        import textwrap as _tw
        desc = SET_DESC.get(SETTINGS_KEYS[st.sel_set][1], "")
        for i, ln in enumerate(_tw.wrap(desc, iw) [:3]):
            scr.put(x, cy + 8 + i, ln, th["tail"][0])
        scr.put(x, cy + 12, "Enter/←→ — переключить (пишется в config.json сразу)", th["dim"])
        scr.put(x, cy + 13, "Esc — назад в меню", th["dim"])
    elif st.page == "help":
        help_lines = [
            "↑↓ / W S   навигация            Enter — выбрать",
            "1-9, 0     быстрый пункт         ←→ — переключить (в подменю)",
            "T          следующая тема        N/A — следующая анимация",
            "F1 / ?     эта справка           Esc/Q — назад / выход",
            "",
            "Внутри ассистента:  /help — команды,  /exit — выход,",
            "голос — «Флюкс, ...»,  push-to-talk — Ctrl+Alt+F,",
            f"веб-панель — http://127.0.0.1:{CFG.get('panel_port', 8787)} (токен в config.json)",
        ]
        for i, hln in enumerate(help_lines):
            scr.put(x, cy + i, hln, th["dim"] if i >= 4 else None)
        scr.put(x, cy + 9, "Любая клавиша — назад", th["tail"][0])

    # ---- статус-бар
    bar_y = min(h - 1, by + bh + 1)
    key_ok = st.key_state not in ("нет", "НЕТ", "?", "...") and not st.key_state.startswith("ошибка")
    bar = f" ключ: {st.key_state} "
    scr.put(2, bar_y, bar, 46 if key_ok else 203)
    sx = 2 + len(bar) + 1
    bar2 = f" SearXNG: {st.searxng} "
    scr.put(sx, bar_y, bar2, 46 if st.searxng == "работает" else th["dim"])
    sx2 = sx + len(bar2) + 1
    if st.qwen.get("state") != "none":
        bar3 = f" qwen: {st.qwen.get('detail')} "
        scr.put(sx2, bar_y, bar3, 46 if st.qwen.get("state") == "ok" else 203)
        sx2 += len(bar3) + 1
    bar4 = f" тема: {THEME_RU[st.theme]} · фон: {ANIM_RU[st.anim]} "
    scr.put(sx2, bar_y, bar4, th["dim"])
    clock = time.strftime("%H:%M:%S")
    scr.put(w - len(clock) - 2, bar_y, clock, th["accent"])
    hints = " F1 помощь · T тема · A анимация · Q выход "
    if bar_y - 1 > by + bh - 1:
        scr.put(2, bar_y - 1, hints, th["tail"][-1])

    # ---- всплывающее сообщение
    if st.msg:
        if time.time() < st.msg_until:
            mw = min(w - 8, max(24, len(st.msg) + 6))
            mx, my = max(1, (w - mw) // 2), max(0, by - 1)
            scr.put(mx, my, " " * mw, th["warn"], th["tail"][-1])
            scr.put(mx + (mw - len(st.msg)) // 2, my, st.msg, th["warn"], th["tail"][-1])
        else:
            st.msg = ""


# ============================================================ действия
def _run_mode(flags: list):
    """Дочерний режим (--check/--selftest) в той же консоли."""
    global _TERM
    term = _TERM
    if term:
        term.leave()
    try:
        if getattr(sys, "frozen", False):
            cmd = [sys.executable] + flags
        else:
            cmd = [sys.executable, str(ROOT / "flux.py")] + flags
        subprocess.run(cmd, cwd=str(ROOT))
    except Exception as e:
        print("ошибка запуска:", e)
    try:
        input("\nНажми Enter, чтобы вернуться в меню...")
    except (EOFError, KeyboardInterrupt):
        pass
    if term:
        term.enter()
    _FORCE_REDRAW["v"] = True


def _do_key_entry(term, st: MenuState):
    term.cooked()
    term.out("\x1b[?1049l")  # временно покидаем alt-screen для обычного ввода
    print("\n\x1b[0m" + "─" * 62)
    print(" Ввод API-ключа xkiro.com  (https://xkiro.com → API Keys → Create key)")
    print(" Ключ сохранится в файл:", SECRETS_FILE)
    try:
        k = input(" Вставь ключ (Enter — отмена): ").strip()
    except Exception:
        k = ""
    if k:
        k = sanitize_key(k)
        if len(k) < 8:
            print(" Похоже, это не ключ (слишком короткий).")
        else:
            try:
                SECRETS_FILE.write_text(k, encoding="utf-8")
                try:
                    os.chmod(SECRETS_FILE, 0o600)
                except Exception:
                    pass
                CFG.data["api_key"] = k
                print(" Проверяю ключ на api.xkiro.com ...")
                stt, body = http_json(str(CFG.get("base_url")).rstrip("/") + "/models",
                                      timeout=20,
                                      headers={"User-Agent": USER_AGENT,
                                               "Authorization": "Bearer " + k})
                if stt == 200:
                    n = len((body or {}).get("data") or []) if isinstance(body, dict) else 0
                    print(f" \x1b[38;5;46m[OK] ключ работает, доступно моделей: {n}\x1b[0m")
                    st.say_msg("API-ключ сохранён и проверен ✓")
                else:
                    print(f" \x1b[38;5;203m[!] сервер ответил HTTP {stt} — ключ сохранён,"
                          f" но проверь его в личном кабинете xkiro.com\x1b[0m")
                    st.say_msg("ключ сохранён, но сервер его не принял")
            except Exception as e:
                print(" Не удалось сохранить/проверить:", e)
    else:
        print(" Отменено.")
    # v2.0.8: заодно можно обновить токен qwen-моста
    try:
        from core.qwen_web import save_qwen_token, token_status, auto_refresh_token
        print("\n Qwen-мост (chat.qwen.ai):")
        if CFG.get("qwen_auto_token", True):
            ar = auto_refresh_token(force=True)
            if ar.get("updated"):
                print(f" \x1b[38;5;46m[OK] АВТО-ТОКЕН: извлечён из {ar['source']} — {ar['detail']}\x1b[0m")
            else:
                print(f" [i] авто-токен: {ar.get('reason')}")
        print(" вручную: F12 на chat.qwen.ai → Console → tools/token_snippet.js")
        cur = token_status()
        print(f" текущий статус: {cur['state']} — {cur['detail']}")
        q = input(" Вставь токен qwen (Enter — не менять): ").strip()
        if q:
            save_qwen_token(q)
            ns = token_status()
            print(f" \x1b[38;5;46m[OK] qwen-токен сохранён: {ns['detail']}\x1b[0m")
            print(" включить провайдер: Настройки → Провайдер моделей → qwen_web")
    except Exception:
        pass
    st.dirty_net = True
    try:
        input(" Нажми Enter, чтобы вернуться в меню...")
    except (EOFError, KeyboardInterrupt):
        pass
    term.out("\x1b[?1049h\x1b[2J")
    term.raw_again()
    _FORCE_REDRAW["v"] = True


def _panel_open(st: MenuState):
    from core import open_path, rand_id
    tok = str(CFG.get("panel_token") or "").strip()
    if not tok or tok == "flux-local-token":
        tok = "flux-" + rand_id(16)
        CFG.set("panel_token", tok)
    host = CFG.get("panel_host", "127.0.0.1")
    host = "127.0.0.1" if host in ("0.0.0.0", "", None) else host
    url = f"http://{host}:{CFG.get('panel_port', 8787)}/?token={tok}"
    open_path(url)
    st.say_msg("панель открыта (нужен запущенный Flux)")


def _activate(st: MenuState, term):
    """Enter/цифра на главной. Возвращает action ('run'/...) или None (остаться в меню)."""
    key = MENU_ITEMS[st.sel][0]
    if key in ("run", "background", "gui", "exit"):
        return key
    if key == "check":
        _run_mode(["--check", "--no-voice"])
        st.dirty_net = True
    elif key == "selftest":
        _run_mode(["--selftest"])
        st.dirty_net = True
    elif key == "panel":
        _panel_open(st)
    elif key == "key":
        _do_key_entry(term, st)
    elif key == "theme":
        st.page, st.sel_row = "theme", 0
    elif key == "settings":
        st.page, st.sel_set = "settings", 0
    return None


def _cycle(st, what, d):
    if what == "theme":
        st.theme = THEME_NAMES[(THEME_NAMES.index(st.theme) + d) % len(THEME_NAMES)]
        st.save_look()
        st.say_msg(f"тема: {THEME_RU[st.theme]}")
    else:
        st.anim = ANIMS[(ANIMS.index(st.anim) + d) % len(ANIMS)]
        st.save_look()
        st.say_msg(f"фон: {ANIM_RU[st.anim]}")


# ============================================================ главный цикл
def run_menu() -> str:
    """Показывает меню. Возвращает: run | background | gui | exit."""
    global _TERM
    term = Term()
    _TERM = term
    if not term.is_tty or term.w < 60 or term.h < 20:
        return _simple_menu()

    st = MenuState()
    rnd = random.Random()
    stop_net = threading.Event()
    threading.Thread(target=_net_checks, args=(st, stop_net), daemon=True).start()

    scr = Screen(term)
    anim_obj, anim_name = None, None
    term.enter()
    frame = 0
    t_last = time.time()
    action = "run"
    UP = ("UP", "w", "ц")
    DOWN = ("DOWN", "s", "ы")
    try:
        while True:
            term.resize()
            if (scr.w, scr.h) != (term.w, term.h):
                scr.set_size(term.w, term.h)
                anim_obj = None
            if _FORCE_REDRAW["v"]:
                _FORCE_REDRAW["v"] = False
                scr.invalidate()

            if anim_name != st.anim:
                anim_name = st.anim
                cls = ANIM_CLASSES.get(anim_name)
                anim_obj = cls() if cls else None
                if anim_obj and hasattr(anim_obj, "reset"):
                    anim_obj.reset(scr.w, scr.h, rnd)
                scr.invalidate()

            # ---------------- ввод
            for key in term.read_keys():
                if st.page == "main":
                    if key in UP:
                        st.sel = (st.sel - 1) % len(MENU_ITEMS)
                    elif key in DOWN:
                        st.sel = (st.sel + 1) % len(MENU_ITEMS)
                    elif len(key) == 1 and key in "123456789":
                        st.sel = int(key) - 1
                        action = _activate(st, term)
                        if action:
                            raise StopIteration
                    elif key == "0":
                        st.sel = len(MENU_ITEMS) - 1
                        action = _activate(st, term)
                        if action:
                            raise StopIteration
                    elif key == "ENTER":
                        action = _activate(st, term)
                        if action:
                            raise StopIteration
                    elif key in ("t", "е"):
                        _cycle(st, "theme", +1)
                    elif key in ("a", "n", "ф", "т"):
                        _cycle(st, "anim", +1)
                    elif key in ("F1", "?", "п"):
                        st.page = "help"
                    elif key in ("q", "й", "ESC"):
                        action = "exit"
                        raise StopIteration
                elif st.page == "theme":
                    if key in UP + DOWN:
                        st.sel_row = 1 - st.sel_row
                    elif key == "LEFT":
                        _cycle(st, "theme" if st.sel_row == 0 else "anim", -1)
                    elif key == "RIGHT":
                        _cycle(st, "theme" if st.sel_row == 0 else "anim", +1)
                    elif key in ("t", "е"):
                        _cycle(st, "theme", +1)
                    elif key in ("a", "n", "ф", "т"):
                        _cycle(st, "anim", +1)
                    elif key == "ENTER":
                        st.save_look()
                        st.say_msg("оформление сохранено ✓")
                        st.page = "main"
                    elif key in ("ESC", "q", "й"):
                        st.page = "main"
                elif st.page == "settings":
                    if key in UP:
                        st.sel_set = (st.sel_set - 1) % len(SETTINGS_KEYS)
                    elif key in DOWN:
                        st.sel_set = (st.sel_set + 1) % len(SETTINGS_KEYS)
                    elif key in ("ENTER", "LEFT", "RIGHT", " "):
                        d = -1 if key == "LEFT" else (1 if key == "RIGHT" else 0)
                        v = _set_row_cycle(st.sel_set, d)
                        st.say_msg(f"{SETTINGS_KEYS[st.sel_set][0]} → {v} ✓")
                    elif key in ("ESC", "q", "й"):
                        st.page = "main"
                elif st.page == "help":
                    st.page = "main"

            # ---------------- кадр (~22 fps)
            if time.time() - t_last < 0.045:
                time.sleep(0.004)
                continue
            t_last = time.time()
            frame += 1
            th = THEMES[st.theme]
            if frame % 600 == 0:
                scr.invalidate()
            scr.clear()
            if anim_obj:
                try:
                    anim_obj.tick(scr, th, rnd)
                except Exception:
                    anim_obj = None
            draw(scr, st, frame)
            scr.render()
    except StopIteration:
        pass
    except KeyboardInterrupt:
        action = "exit"
    except Exception as e:
        action = "run"
        try:
            term.leave()
            print("[menu] сбой отрисовки, запускаю обычный режим:", e)
        except Exception:
            pass
        return action
    finally:
        stop_net.set()
        try:
            term.leave()
        except Exception:
            pass
        _TERM = None
    return action or "run"


# ============================================================ простой фолбэк
def _simple_menu() -> str:
    """Маленькое окно / не-tty: обычное текстовое меню."""
    print("=" * 58)
    print(f"  FLUX v{VERSION} :: стартовое меню (текстовый режим)")
    print("=" * 58)
    for i, (_k, name, hint) in enumerate(MENU_ITEMS, 1):
        print(f"  {i % 10}. {name:<24} {hint}")
    st = MenuState()
    while True:
        try:
            ch = input("\n  Выбор: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return "exit"
        direct = {"1": "run", "2": "background", "3": "gui", "0": "exit", "10": "exit"}
        if ch in direct:
            return direct[ch]
        if ch == "4":
            _run_mode(["--check", "--no-voice"])
        elif ch == "5":
            _run_mode(["--selftest"])
        elif ch == "6":
            _panel_open(st)
        elif ch == "7":
            class _T:
                @staticmethod
                def cooked(): pass
                @staticmethod
                def raw_again(): pass
                @staticmethod
                def out(s): sys.stdout.write(s); sys.stdout.flush()
            _do_key_entry(_T(), st)
        elif ch == "8":
            print("  темы:", ", ".join(THEME_NAMES), "\n  фоны:", ", ".join(ANIMS))
            t = input("  тема (Enter — оставить): ").strip()
            a = input("  анимация (Enter — оставить): ").strip()
            if t in THEMES:
                CFG.set("menu_theme", t, save=False)
            if a in ANIMS:
                CFG.set("menu_anim", a, save=False)
            CFG.save()
        elif ch == "9":
            for _label, k in SETTINGS_KEYS:
                v = input(f"  {k} true/false [{CFG.get(k)}]: ").strip().lower()
                if v in ("true", "1", "on", "да"):
                    CFG.set(k, True)
                elif v in ("false", "0", "off", "нет"):
                    CFG.set(k, False)
        else:
            print("  введи номер 1-10")


if __name__ == "__main__":
    act = run_menu()
    print("действие:", act)
    if act in ("run", "background", "gui"):
        flags = {"run": [], "background": ["--background"], "gui": ["--gui"]}[act]
        if getattr(sys, "frozen", False):
            os.execv(sys.executable, [sys.executable] + flags)
        else:
            os.execv(sys.executable, [sys.executable, str(ROOT / "flux.py")] + flags)
    elif act == "exit":
        sys.exit(0)
