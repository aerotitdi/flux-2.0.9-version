@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title FLUX :: проверка микрофона и озвучки
if exist "%~dp0venv\Scripts\python.exe" (set "PY=%~dp0venv\Scripts\python.exe") else (set "PY=python")
set "PYTHONUTF8=1"
echo.
echo  ============================================================
echo    FLUX :: диагностика голоса
echo    1) список микрофонов   2) запись 4 сек   3) распознавание
echo    4) тест озвучки        5) тест wake word
echo  ============================================================
echo.
"%PY%" "%~dp0tools\mic_test.py"
echo.
pause
endlocal
