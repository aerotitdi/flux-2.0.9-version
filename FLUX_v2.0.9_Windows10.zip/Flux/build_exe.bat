@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title FLUX :: BUILD SYSTEM

rem ============================================================
rem  FLUX :: сборка EXE  (анимированное меню: tools\builder.py)
rem    build_exe.bat         ->  красивое меню сборки (темы/анимация)
rem    build_exe.bat auto    ->  собрать сразу, без меню
rem ============================================================

echo.
echo    ######  ##       ##  ##  ## ##     ######   ######  ##   ##
echo    ##      ##       ##  ##   ###      ##   ##  ##       ## ##
echo    ####    ##       ##  ##    ##      ####     ####      ###
echo    ##      ##       ##  ##   ###      ##   ##  ##       ## ##
echo    ##       ########    ##  ## ##     ######   ######  ##   ##
echo.
echo              B U I L D   S Y S T E M    v2.0.4
echo    ---------------------------------------------------------
echo      на выходе: %~dp0dist\FLUX.exe  ^(одним файлом^)
echo      у EXE будет анимированное меню: матрица-фон, 5 тем,
echo      быстрый запуск всех режимов, ввод API-ключа.
echo    ---------------------------------------------------------
echo.

rem ---------- ищем python ----------
set "PY="
if exist "%~dp0venv\Scripts\python.exe" set "PY=%~dp0venv\Scripts\python.exe"
if not defined PY (
  py -3 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
  python -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PY=python"
)
if not defined PY (
  echo   [X] Python не найден.
  echo       Установи Python 3.10+: https://www.python.org/downloads/windows/
  echo       ^(галочка "Add python.exe to PATH"^), либо сначала запусти install.bat
  echo.
  pause
  exit /b 1
)
echo   [OK] python: %PY%

rem ---------- зависимости проекта (без них EXE получится "глухим") ----------
echo   [i] проверяю пакеты проекта ^(psutil, mss, pillow, голос...^)
%PY% -c "import psutil" >nul 2>&1
if errorlevel 1 (
  echo       ставлю requirements-core.txt ...
  %PY% -m pip install -r "%~dp0requirements-core.txt" --disable-pip-version-check --no-input -q
)
%PY% -c "import speech_recognition" >nul 2>&1
if errorlevel 1 (
  echo       ставлю requirements-extra.txt ^(может частично не собраться — не страшно^) ...
  %PY% -m pip install -r "%~dp0requirements-extra.txt" --disable-pip-version-check --no-input -q
)

rem ---------- запуск ----------
if /i "%~1"=="auto" (
  echo.
  echo   [i] режим "auto": собираю без меню ...
  %PY% "%~dp0tools\builder.py" --auto
  goto :done
)

if not exist "%~dp0tools\builder.py" (
  echo   [X] Не найден tools\builder.py — сборочное меню недоступно.
  echo       Запусти build_exe.bat auto  ^(соберёт напрямую^).
  pause
  exit /b 1
)

%PY% "%~dp0tools\builder.py"

:done
echo.
echo    ---------------------------------------------------------
if exist "%~dp0dist\FLUX.exe" (
  echo      ФАЙЛ: %~dp0dist\FLUX.exe
  echo      копия: %~dp0FLUX.exe
  echo.
  echo      Запуск            :  FLUX.exe            ^(анимированное меню^)
  echo      сразу чат         :  FLUX.exe --no-menu
  echo      фон               :  FLUX.exe --background
  echo      проверка          :  FLUX.exe --check
  echo      EXE ищет config.json / secret.key / data РЯДОМ С СОБОЙ.
) else (
  echo      FLUX.exe не найден в dist\ — смотри ошибки выше.
  echo      Flux работает и без EXE:  run.bat
)
echo    ---------------------------------------------------------
echo.
pause
endlocal
