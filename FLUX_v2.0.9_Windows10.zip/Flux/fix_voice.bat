@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title FLUX :: починка голоса (микрофон + озвучка)

if exist "%~dp0venv\Scripts\python.exe" (set "PY=%~dp0venv\Scripts\python.exe") else (set "PY=python")
if exist "%~dp0venv\Scripts\pip.exe" (set "PIP=%~dp0venv\Scripts\pip.exe") else (set "PIP=%PY% -m pip")

echo.
echo  ============================================================
echo    FLUX :: установка голосовых компонентов
echo    python: %PY%
echo  ============================================================
echo.

echo  [1/6] Распознавание речи (SpeechRecognition) ...
%PIP% install --upgrade SpeechRecognition --disable-pip-version-check --no-input

echo.
echo  [2/6] ОСНОВНОЙ движок микрофона: sounddevice (не требует PyAudio) ...
%PIP% install --upgrade pip wheel setuptools --disable-pip-version-check
%PIP% install sounddevice soundfile numpy --disable-pip-version-check --no-input
if errorlevel 1 (
  echo      [!] sounddevice не встал - пробую PyAudio как основной ...
)

echo.
echo  [3/6] Запасной движок микрофона: PyAudio (может не собраться - это НЕ ошибка) ...
%PIP% install PyAudio --disable-pip-version-check --no-input
if errorlevel 1 (
  echo      PyAudio не собрался. НОРМАЛЬНО: Flux слушает микрофон через sounddevice.
  echo      Пробую pipwin ...
  %PIP% install pipwin --disable-pip-version-check --no-input
  "%PY%" -m pipwin install pyaudio --disable-pip-version-check
)

echo.
echo  [4/6] Озвучка офлайн (pyttsx3 - у тебя уже есть русский голос Irina) ...
%PIP% install pyttsx3 comtypes --disable-pip-version-check --no-input

echo.
echo  [5/6] Нейро-голос (edge-tts) + горячая клавиша Ctrl+Alt+F (keyboard) ...
%PIP% install edge-tts keyboard --disable-pip-version-check --no-input

echo.
echo  [6/6] Что встало ...
"%PY%" -c "import importlib.util as u;mods={'SpeechRecognition':'speech_recognition','sounddevice (осн. микрофон)':'sounddevice','soundfile':'soundfile','numpy':'numpy','PyAudio (запасной)':'pyaudio','pyttsx3 (озвучка)':'pyttsx3','edge_tts (нейро-голос)':'edge_tts','keyboard (hotkey)':'keyboard'};[print(('  [OK  ] ' if u.find_spec(v) else '  [НЕТ ] ')+k) for k,v in mods.items()]"

echo.
echo  ------------------------------------------------------------
echo   ГЛАВНОЕ: если [OK] стоит на sounddevice - голосовой ввод
echo   БУДЕТ работать, даже если PyAudio остался [НЕТ].
echo.
echo   Проверка микрофона:   flux_mic_test.bat
echo   Запуск ассистента:    run.bat   -^>  скажи "Флюкс, привет"
echo  ------------------------------------------------------------
echo.
echo   Если Windows спросит про микрофон: Параметры -^> Конфиденциальность -^>
echo   Микрофон -^> "Разрешить классическим приложениям" = Вкл
echo.
pause
endlocal
