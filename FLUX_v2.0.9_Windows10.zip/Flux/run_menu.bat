@echo off
chcp 65001 >nul
title FLUX :: меню
cd /d "%~dp0"
set "PYTHONUTF8=1"

rem  Стартовое анимированное меню FLUX (как в EXE, но из исходников).
rem  Если собран FLUX.exe — запускаем его, иначе python flux.py --menu

if exist "%~dp0FLUX.exe" (
  "%~dp0FLUX.exe" --menu %*
  goto :eof
)
if exist "%~dp0venv\Scripts\python.exe" (
  "%~dp0venv\Scripts\python.exe" "%~dp0flux.py" --menu %*
  goto :eof
)
py -3 -c "import sys" >nul 2>&1
if not errorlevel 1 (
  py -3 "%~dp0flux.py" --menu %*
  goto :eof
)
python "%~dp0flux.py" --menu %*
