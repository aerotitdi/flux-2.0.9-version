@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONUTF8=1"
if exist "%~dp0venv\Scripts\python.exe" (set "PY=%~dp0venv\Scripts\python.exe") else (set "PY=python")
echo.
echo  FLUX :: диагностика окружения
echo.
"%PY%" "%~dp0flux.py" --check
echo.
pause
