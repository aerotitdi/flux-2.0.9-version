@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist "%~dp0venv\Scripts\python.exe" (set "PY=%~dp0venv\Scripts\python.exe") else (set "PY=python")
echo.
echo  FLUX :: обновление пакетов
echo.
"%PY%" -m pip install --upgrade pip setuptools wheel --disable-pip-version-check
"%PY%" -m pip install --upgrade -r requirements-core.txt --disable-pip-version-check
"%PY%" -m pip install --upgrade -r requirements-extra.txt --disable-pip-version-check
echo.
echo  Готово. Проверь: flux_check.bat
pause
