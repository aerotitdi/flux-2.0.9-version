# -*- coding: utf-8 -*-
"""
FLUX :: tools/builder.py
Анимированная сборочная консоль FLUX: меню в стиле flux_menu (матрица/темы),
сборка FLUX.exe через PyInstaller, установка зависимостей, генерация иконки
и version-ресурса. Запуск:  build_exe.bat  или  python tools\\builder.py
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.chdir(str(ROOT))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

from core import CFG  # noqa: E402

# переиспользуем движок анимации стартового меню
sys.path.insert(0, str(ROOT))
import flux_menu as FM  # noqa: E402

VERSION = "2.0.5"
try:
    import re as _re
    _m = _re.search(r'VERSION\s*=\s*"([^"]+)"', (ROOT / "flux.py").read_text(encoding="utf-8"))
    if _m:
        VERSION = _m.group(1)
except Exception:
    pass

PY = sys.executable or "python"

MENU = [
    ("build",   "Собрать FLUX.exe",        "PyInstaller --onefile (3-8 минут)"),
    ("buildrun", "Собрать и запустить",    "сборка + запуск готового EXE"),
    ("deps",    "Установить зависимости",  "requirements-core + extra (голос, экран, веб)"),
    ("pyinst",  "Установить PyInstaller",  "обновить сборщик"),
    ("icon",    "Сгенерировать иконку",    "assets/icon.ico (нужен Pillow)"),
    ("clean",   "Очистить сборку",         "удалить build/ и dist/"),
    ("check",   "Диагностика проекта",     "flux.py --check"),
    ("exit",    "Выход",                   ""),
]


# ---------------------------------------------------------------- утилиты
def _stamp(t0: float) -> str:
    m, s = divmod(int(time.time() - t0), 60)
    return f"{m} мин {s:02d} сек" if m else f"{s} сек"


def _exe_python() -> str:
    """Интерпретатор для сборки: venv рядом -> текущий."""
    venv = ROOT / "venv" / "Scripts" / "python.exe"
    if venv.exists():
        return str(venv)
    return PY


def make_icon() -> Path | None:
    """Рисуем assets/icon.ico (круг Флюкса в стиле панели)."""
    try:
        from PIL import Image, ImageDraw
    except Exception:
        print("  [!] Pillow не установлен — иконка не создана (pip install pillow)")
        return None
    adir = ROOT / "assets"
    adir.mkdir(exist_ok=True)
    sizes = [16, 24, 32, 48, 64, 128, 256]
    imgs = []
    for sz in sizes:
        im = Image.new("RGBA", (sz, sz), (11, 17, 24, 255))
        d = ImageDraw.Draw(im)
        pad = max(1, sz // 8)
        d.ellipse((pad, pad, sz - pad, sz - pad), outline=(34, 211, 238, 255),
                  width=max(1, sz // 14))
        c = sz // 2
        r = max(1, sz // 6)
        d.ellipse((c - r, c - r, c + r, c + r), fill=(34, 211, 238, 255))
        imgs.append(im)
    out = adir / "icon.ico"
    imgs[-1].save(str(out), format="ICO", sizes=[(s, s) for s in sizes],
                  append_images=imgs[:-1])
    print(f"  [OK] иконка: {out}")
    return out


def make_version_file() -> Path:
    """version_info.txt для PyInstaller (свойства EXE в проводнике)."""
    parts = VERSION.split(".")
    while len(parts) < 4:
        parts.append("0")
    v = ",".join(parts[:4])
    txt = f"""# UTF-8
VSVersionInfo(
  ffi=FixedFileInfo(
    filevers=({v}), prodvers=({v}),
    mask=0x3f, flags=0x0, OS=0x40004, fileType=0x1, subtype=0x0, date=(0, 0)
  ),
  kids=[
    StringFileInfo([StringTable('041904b0', [
      StringStruct('CompanyName', 'Flux'),
      StringStruct('FileDescription', 'FLUX - AI-ассистент для Windows'),
      StringStruct('FileVersion', '{VERSION}'),
      StringStruct('InternalName', 'FLUX'),
      StringStruct('OriginalFilename', 'FLUX.exe'),
      StringStruct('ProductName', 'FLUX AI assistant'),
      StringStruct('ProductVersion', '{VERSION}')])]),
    VarFileInfo([VarStruct('Translation', [1049, 1200])])
  ]
)
"""
    p = ROOT / "version_info.txt"
    p.write_text(txt, encoding="utf-8")
    return p


def run_streamed(cmd: list, banner: str) -> int:
    """Запуск с живым выводом; возвращает код возврата."""
    print(f"\n  \x1b[38;5;51m▶ {banner}\x1b[0m")
    print("  " + "─" * 58)
    t0 = time.time()
    try:
        rc = subprocess.call(cmd, cwd=str(ROOT))
    except KeyboardInterrupt:
        print("\n  [!] прервано пользователем")
        return 130
    except Exception as e:
        print(f"  [X] {type(e).__name__}: {e}")
        return 1
    ok = (rc == 0)
    col = "46" if ok else "203"
    mark = "ГОТОВО" if ok else f"ОШИБКА (код {rc})"
    print("  " + "─" * 58)
    print(f"  \x1b[38;5;{col}m■ {mark}\x1b[0m  ·  время: {_stamp(t0)}")
    return rc


def pip_install(pkgs: list | None = None, reqs: list | None = None) -> int:
    py = _exe_python()
    base = [py, "-m", "pip", "install", "--disable-pip-version-check", "--no-input"]
    rc = 0
    if reqs:
        for r in reqs:
            if (ROOT / r).exists():
                rc |= run_streamed(base + ["-r", r], f"pip install -r {r}")
    if pkgs:
        rc |= run_streamed(base + pkgs, "pip install " + " ".join(pkgs))
    return rc


def do_build(run_after: bool = False) -> int:
    py = _exe_python()
    print("\n  \x1b[38;5;51mFLUX BUILD SYSTEM\x1b[0m  ·  версия " + VERSION)
    # 1) pyinstaller
    try:
        subprocess.run([py, "-m", "PyInstaller", "--version"], cwd=str(ROOT),
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    except Exception:
        print("  [i] PyInstaller не найден — устанавливаю...")
        if pip_install(pkgs=["--upgrade", "pyinstaller"]) != 0:
            print("  [X] не удалось установить PyInstaller (проверь интернет/pip)")
            return 1
    # 2) иконка + version-ресурс
    icon = (ROOT / "assets" / "icon.ico")
    if not icon.exists():
        make_icon()
    vfile = make_version_file()
    # 3) чистка
    for d in ("build", "dist"):
        p = ROOT / d
        if p.exists():
            shutil.rmtree(p, ignore_errors=True)
    # 4) сборка
    cmd = [py, "-m", "PyInstaller",
           "--noconfirm", "--clean", "--onefile", "--console",
           "--name", "FLUX",
           "--collect-submodules", "core",
           "--hidden-import", "core.tools_system",
           "--hidden-import", "core.tools_web",
           "--hidden-import", "core.tools_time",
           "--hidden-import", "core.tools_brain",
           "--hidden-import", "gui_window",
           "--hidden-import", "flux_menu",
           "--collect-data", "core",
           "--add-data", f"config.json{os.pathsep}.",
           "--add-data", f"searxng{os.pathsep}searxng",
           "--add-data", f"requirements-core.txt{os.pathsep}.",
           "--add-data", f"requirements-extra.txt{os.pathsep}.",
           "--add-data", f"docker-compose.yml{os.pathsep}.",
           "--add-data", f"flux_background.vbs{os.pathsep}.",
           "--version-file", str(vfile)]
    if icon.exists():
        cmd += ["--icon", str(icon)]
    cmd.append("flux.py")
    rc = run_streamed(cmd, "PyInstaller: сборка FLUX.exe (onefile)")
    if rc != 0:
        print("""
  \x1b[38;5;203mСборка не удалась. Частые причины:\x1b[0m
    · антивирус блокирует PyInstaller (добавь исключение для папки проекта)
    · мало места на диске / нет прав
    · битый venv — пересоздай: python -m venv venv
  Flux прекрасно работает и без EXE:  run.bat""")
        return rc
    exe = ROOT / "dist" / "FLUX.exe"
    if exe.exists():
        shutil.copy2(str(exe), str(ROOT / "FLUX.exe"))
        size_mb = exe.stat().st_size / 1_048_576
        print(f"""
  \x1b[38;5;46m██████████████████████████████████████████████████\x1b[0m
  \x1b[38;5;46m  СБОРКА УСПЕШНА\x1b[0m
    файл : {exe}
    копия: {ROOT / 'FLUX.exe'}
    размер: {size_mb:.1f} МБ   ·   время: см. выше
  \x1b[38;5;46m██████████████████████████████████████████████████\x1b[0m
    EXE ищет config.json, secret.key и папку data РЯДОМ С СОБОЙ.
    При запуске без аргументов откроется АНИМИРОВАННОЕ МЕНЮ.
    Режимы:  FLUX.exe --background | --check | --selftest | --gui | --no-menu""")
        if run_after:
            print("\n  Запускаю FLUX.exe ...")
            subprocess.call([str(ROOT / "FLUX.exe")], cwd=str(ROOT))
    return 0


def do_clean() -> int:
    removed = []
    for d in ("build", "dist", "__pycache__"):
        p = ROOT / d
        if p.exists():
            shutil.rmtree(p, ignore_errors=True)
            removed.append(d + "/")
    p = ROOT / "FLUX.spec"
    if p.exists():
        p.unlink()
        removed.append("FLUX.spec")
    print(f"  [OK] удалено: {', '.join(removed) or 'нечего чистить'}")
    return 0


# ---------------------------------------------------------------- анимированное меню
def menu_loop() -> int:
    term = FM.Term()
    if not term.is_tty or term.w < 60 or term.h < 18:
        return _plain_menu()
    import random
    st = FM.MenuState()
    rnd = random.Random()
    scr = FM.Screen(term)
    anim = FM.ANIM_CLASSES.get(st.anim)
    anim = anim() if anim else None
    if anim and hasattr(anim, "reset"):
        anim.reset(scr.w, scr.h, rnd)
    sel = 0
    term.enter()
    t_last = time.time()
    frame = 0
    rc = 0
    try:
        while True:
            term.resize()
            if (scr.w, scr.h) != (term.w, term.h):
                scr.set_size(term.w, term.h)
                if anim and hasattr(anim, "reset"):
                    anim.reset(scr.w, scr.h, rnd)
            for key in term.read_keys():
                if key in ("UP", "w", "ц"):
                    sel = (sel - 1) % len(MENU)
                elif key in ("DOWN", "s", "ы"):
                    sel = (sel + 1) % len(MENU)
                elif len(key) == 1 and key in "12345678":
                    sel = int(key) - 1
                    rc = _run_item(MENU[sel][0], term)
                    if rc is None:
                        raise StopIteration
                elif key == "ENTER":
                    rc = _run_item(MENU[sel][0], term)
                    if rc is None:
                        raise StopIteration
                elif key in ("t", "е"):
                    FM._cycle(st, "theme", +1)
                elif key in ("a", "n", "ф", "т"):
                    FM._cycle(st, "anim", +1)
                    cls = FM.ANIM_CLASSES.get(st.anim)
                    anim = cls() if cls else None
                    if anim and hasattr(anim, "reset"):
                        anim.reset(scr.w, scr.h, rnd)
                elif key in ("q", "й", "ESC"):
                    raise StopIteration
            if time.time() - t_last < 0.045:
                time.sleep(0.004)
                continue
            t_last = time.time()
            frame += 1
            th = FM.THEMES[st.theme]
            scr.clear()
            if anim:
                try:
                    anim.tick(scr, th, rnd)
                except Exception:
                    anim = None
            _draw_builder(scr, st, sel, frame)
            scr.render()
    except (StopIteration, KeyboardInterrupt):
        pass
    finally:
        term.leave()
    return rc or 0


def _run_item(key: str, term):
    """Выполняет пункт меню. None = выход из меню."""
    if key == "exit":
        return None
    term.leave()
    try:
        if key in ("build", "buildrun"):
            do_build(run_after=(key == "buildrun"))
        elif key == "deps":
            pip_install(reqs=["requirements-core.txt", "requirements-extra.txt"])
        elif key == "pyinst":
            pip_install(pkgs=["--upgrade", "pyinstaller"])
        elif key == "icon":
            make_icon()
        elif key == "clean":
            do_clean()
        elif key == "check":
            subprocess.call([_exe_python(), str(ROOT / "flux.py"), "--check"], cwd=str(ROOT))
        try:
            input("\n  Нажми Enter, чтобы вернуться в меню сборки...")
        except (EOFError, KeyboardInterrupt):
            pass
    finally:
        term.enter()
    return 0


def _draw_builder(scr, st, sel, frame):
    th = FM.THEMES[st.theme]
    w, h = scr.w, scr.h
    bw = min(66, w - 4)
    bh = min(22, h - 5)
    bx = (w - bw) // 2
    by = max(1, (h - bh) // 2)
    scr.put(bx, by, "╔" + "═" * (bw - 2) + "╗", th["accent"])
    for i in range(1, bh - 1):
        scr.put(bx, by + i, "║", th["accent"])
        scr.put(bx + bw - 1, by + i, "║", th["accent"])
    scr.put(bx, by + bh - 1, "╚" + "═" * (bw - 2) + "╝", th["accent"])
    x, iw = bx + 2, bw - 4
    title = "⚡ FLUX BUILD SYSTEM"
    shimmer = (frame // 3) % 40
    tx = x + max(0, (iw - len(title)) // 2)
    for j, ch in enumerate(title):
        d = abs(((shimmer + j * 2) % 40) - 20)
        scr.put(tx + j, by + 1, ch, th["head"] if d <= 5 else th["title"])
    sub = f"сборка FLUX.exe v{VERSION} · PyInstaller onefile · {PY.split(os.sep)[-1]}"
    scr.put(x + max(0, (iw - len(sub)) // 2), by + 2, sub[:iw], th["dim"])
    scr.put(x, by + 3, "─" * iw, th["tail"][-1])
    for i, (_k, name, hint) in enumerate(MENU):
        num = f"{i + 1}"
        if i == sel:
            base = f" ▸ {num}. {name}"
            if hint:
                pad = max(1, iw - len(base) - len(hint) - 1)
                line = (base + " " * pad + hint)[:iw]
            else:
                line = (base + " " * iw)[:iw]
            scr.put(x, by + 4 + i, line, th["sel_fg"], th["sel_bg"])
        else:
            scr.put(x, by + 4 + i, f"   {num}. {name}", None)
            if hint:
                scr.put(x + iw - len(hint) - 1, by + 4 + i, hint, th["dim"])
    bar = f" ↑↓ выбор · Enter запуск · T тема · A фон · Q выход "
    scr.put(2, min(h - 1, by + bh + 1), bar, th["dim"])


def _plain_menu() -> int:
    print("=" * 58)
    print(f"  FLUX BUILD SYSTEM v{VERSION} (текстовый режим)")
    print("=" * 58)
    for i, (_k, name, hint) in enumerate(MENU, 1):
        print(f"  {i}. {name:<26} {hint}")
    while True:
        try:
            ch = input("\n  Выбор: ").strip()
        except (EOFError, KeyboardInterrupt):
            return 0
        if ch == "1":
            do_build(False)
        elif ch == "2":
            do_build(True)
        elif ch == "3":
            pip_install(reqs=["requirements-core.txt", "requirements-extra.txt"])
        elif ch == "4":
            pip_install(pkgs=["--upgrade", "pyinstaller"])
        elif ch == "5":
            make_icon()
        elif ch == "6":
            do_clean()
        elif ch == "7":
            subprocess.call([_exe_python(), str(ROOT / "flux.py"), "--check"], cwd=str(ROOT))
        elif ch in ("8", "0"):
            return 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--auto":
        sys.exit(do_build(run_after=False))
    sys.exit(menu_loop())
