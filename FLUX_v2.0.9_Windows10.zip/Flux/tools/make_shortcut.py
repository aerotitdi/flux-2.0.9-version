# -*- coding: utf-8 -*-
"""FLUX :: создание ярлыков (рабочий стол + меню Пуск) и регистрация автозагрузки.
Запуск:  python tools\\make_shortcut.py "D:\\Flux"
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def ps(script: str) -> int:
    p = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return p.returncode


def _detect_version(root: Path) -> str:
    # FIX: версия была зашита как 2.0.0 — берём реальную из flux.py
    try:
        import re
        txt = (root / "flux.py").read_text(encoding="utf-8")
        m = re.search(r"VERSION\s*=\s*\"([^\"]+)\"", txt)
        if m:
            return m.group(1)
    except Exception:
        pass
    return "2.0.4"


def main() -> int:
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
    version = _detect_version(root)
    py = root / "venv" / "Scripts" / "python.exe"
    pyexe = str(py) if py.exists() else "python"
    run_bat = root / "run.bat"
    bg_vbs = root / "flux_background.vbs"
    icon = "shell32.dll,13"

    desktop = Path(os.path.join(os.environ.get("USERPROFILE", str(Path.home())), "Desktop"))
    startmenu = Path(os.environ.get("APPDATA", "")) / r"Microsoft\Windows\Start Menu\Programs"
    targets = [desktop / "FLUX Ассистент.lnk", startmenu / "FLUX AI.lnk", startmenu / "FLUX (фон).lnk"]

    made = 0
    for i, lnk in enumerate(targets):
        target = str(bg_vbs) if "фон" in lnk.name else str(run_bat)
        wscript = "wscript.exe" if target.endswith(".vbs") else "cmd.exe"
        args = f'"{target}"' if target.endswith(".vbs") else f'/k ""{target}""'
        script = f"""
$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut('{lnk}')
$lnk.TargetPath = '{wscript}'
$lnk.Arguments = '{args}'
$lnk.WorkingDirectory = '{root}'
$lnk.Description = 'FLUX AI assistant'
$lnk.IconLocation = '{icon}'
$lnk.WindowStyle = 1
$lnk.Save()
"""
        try:
            lnk.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        if ps(script) == 0:
            made += 1
            print("ярлык создан:", lnk)
        else:
            print("не удалось создать ярлык:", lnk)

    # запись в реестр для "Программы и компоненты"
    uninst = root / "uninstall_flux.bat"
    ps(f"""
$k = 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\FluxAI'
New-Item -Path $k -Force | Out-Null
Set-ItemProperty -Path $k -Name DisplayName -Value 'FLUX AI assistant'
Set-ItemProperty -Path $k -Name DisplayVersion -Value '{version}'
Set-ItemProperty -Path $k -Name Publisher -Value 'Flux'
Set-ItemProperty -Path $k -Name InstallLocation -Value '{root}'
Set-ItemProperty -Path $k -Name UninstallString -Value '"{uninst}"'
Set-ItemProperty -Path $k -Name DisplayIcon -Value 'shell32.dll,13'
""")
    print(f"готово, ярлыков: {made}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
