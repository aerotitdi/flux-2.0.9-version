# -*- coding: utf-8 -*-
"""
FLUX :: tools/mic_test.py
Пошаговая диагностика голоса: микрофоны -> запись -> распознавание -> озвучка -> wake word.
Запуск:  flux_mic_test.bat   или   python tools\\mic_test.py
"""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.chdir(str(ROOT))

GREEN = "\033[92m"
RED = "\033[91m"
YEL = "\033[93m"
CY = "\033[96m"
R = "\033[0m"

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
if os.name == "nt":
    try:
        import ctypes
        ctypes.windll.kernel32.SetConsoleOutputCP(65001)
    except Exception:
        pass


def head(n: str, title: str):
    prefix = f"{n}. " if n else ""
    print(f"\n{CY}── {prefix}{title} {'─' * max(3, 52 - len(prefix + title))}{R}")


def ok(msg: str):
    print(f"  {GREEN}[OK]{R}   {msg}")


def bad(msg: str):
    print(f"  {RED}[НЕТ]{R}  {msg}")


def warn(msg: str):
    print(f"  {YEL}[!]{R}    {msg}")


results = {}


# ---------------------------------------------------------------- 1. микрофоны
def step_mics():
    head(1, "Микрофоны")
    try:
        import speech_recognition as sr
    except Exception as e:
        bad(f"SpeechRecognition не установлен: {e}")
        warn("запусти fix_voice.bat")
        results["sr"] = False
        return
    results["sr"] = True
    try:
        mics = sr.Microphone.list_microphone_names()
    except Exception as e:
        warn(f"PyAudio недоступен: {e}")
        warn("пробую запасной движок sounddevice (не требует PyAudio)...")
        try:
            import flux as _fx
            sd = _fx.SdListener()
            names = sd.device_names()
            results["mics"] = names
            results["backend"] = "sounddevice"
            ok(f"sounddevice видит микрофонов: {len(names)}")
            for i, m in enumerate(names[:8]):
                print(f"        {i}: {m}")
            ok(f"Flux выберет устройство: {sd.chosen_name()}")
            warn("если это не твой микрофон - впиши подстроку имени в config.json -> mic_device")
            ok("запись пойдёт через sounddevice — переходи к шагу 2")
            return
        except Exception as e2:
            bad(f"и sounddevice не работает: {e2}")
            warn("запусти fix_voice.bat (поставит sounddevice), затем повтори тест")
            results["mics"] = []
            return
    results["mics"] = mics
    if not mics:
        bad("микрофонов не найдено вообще")
        warn("Параметры -> Система -> Звук -> Ввод: подключи микрофон")
        return
    ok(f"найдено устройств: {len(mics)}")
    for i, m in enumerate(mics):
        print(f"        {i}: {m}")
    # какое устройство по умолчанию
    try:
        with sr.Microphone() as src:
            ok(f"устройство по умолчанию открывается (device_index={src.device_index})")
            results["default_mic"] = src.device_index
    except Exception as e:
        bad(f"микрофон по умолчанию не открывается: {e}")
        warn("попробуй задать device_index вручную в config.json или выбери другое устройство в Windows")


# ---------------------------------------------------------------- 2. запись
def step_record(seconds: int = 4):
    head(2, f"Запись {seconds} сек с микрофона")
    try:
        import speech_recognition as sr
    except Exception:
        bad("SpeechRecognition отсутствует — пропускаю")
        return None
    out = ROOT / "data" / "media" / "audio" / "mic_test.wav"
    out.parent.mkdir(parents=True, exist_ok=True)
    audio = None
    try:
        r = sr.Recognizer()
        r.energy_threshold = 300
        print(f"  {YEL}Говори сейчас (например: «Флюкс, какая погода»)...{R}")
        try:
            with sr.Microphone() as src:
                r.adjust_for_ambient_noise(src, duration=0.5)
                audio = r.listen(src, timeout=seconds + 4, phrase_time_limit=seconds + 3)
        except Exception as pe:
            if "PyAudio" not in str(pe):
                raise
            warn("PyAudio нет — записываю через sounddevice")
            import flux as _fx
            sdl = _fx.SdListener()
            pcm = sdl.listen(timeout=seconds + 4, phrase_limit=seconds + 3, calibrate=0.4)
            audio = sr.AudioData(pcm, sdl.rate, 2)
            results["backend"] = "sounddevice"
        with open(out, "wb") as f:
            f.write(audio.get_wav_data())
        ok(f"записано: {out} ({out.stat().st_size} байт)")
        if out.stat().st_size < 2000:
            warn("файл очень маленький — похоже, микрофон молчит")
        results["record"] = True
    except Exception as e:
        bad(f"записать не удалось: {type(e).__name__}: {e}")
        msg = str(e)
        if "пик=" in msg:
            peak = msg.split("пик=")[1].split(",")[0]
            thr = msg.split("порог=")[1].rstrip(")")
            warn(f"микрофон слышал пик громкости {peak} при пороге срабатывания {thr}")
            try:
                if float(peak) < float(thr) * 0.5:
                    warn("микрофон почти ничего не слышит: проверь, что в Windows выбран")
                    warn("именно этот микрофон (Параметры -> Система -> Звук -> Ввод),")
                    warn("он не на mute, и громкость записи не на нуле")
                    warn("или впиши его имя в config.json -> mic_device")
                else:
                    warn("речь была тише порога: говори громче/ближе к микрофону")
            except Exception:
                pass
        results["record"] = False
        return None
    return audio


# ---------------------------------------------------------------- 3. распознавание
def step_recognize(audio):
    head(3, "Распознавание речи")
    if audio is None:
        warn("нет записи — пропускаю")
        return
    try:
        import speech_recognition as sr
    except Exception:
        return
    r = sr.Recognizer()
    try:
        text = r.recognize_google(audio, language="ru-RU")
        ok(f"услышал: «{text}»")
        results["recognize"] = text
        # 5. wake word
        head(5, "Проверка wake word")
        try:
            import flux
            v = flux.VoiceInput.__new__(flux.VoiceInput)
            wake, rest = flux.VoiceInput.match_wake(v, text)
            words = flux.CFG.get("wake_words")
            if wake:
                ok(f"wake word найден -> команда для Flux: «{rest or '(пусто — скажет «Слушаю»)'}»")
                ok(f"активные wake-слова: {words}")
            else:
                warn(f"wake word НЕ найден в «{text}» — фраза была бы проигнорирована")
                warn("фраза должна НАЧИНАТЬСЯ со слова «Флюкс» (или flux/флукс)")
                warn(f"свои варианты можно добавить в config.json -> wake_words (сейчас: {words})")
            results["wake"] = wake
        except Exception as e:
            warn(f"не смог проверить wake word: {e}")
    except Exception as e:
        name = type(e).__name__
        bad(f"распознавание не сработало: {name}: {e}")
        if "UnknownValue" in name:
            warn("речь не разобрана: говори громче/ближе к микрофону, или в комнате шумно")
        elif "RequestError" in name:
            warn("нет связи с сервисом распознавания (нужен интернет; возможно блокировка/прокси)")
        results["recognize"] = None


# ---------------------------------------------------------------- 4. озвучка
def step_tts():
    head(4, "Озвучка (TTS)")
    engines = []
    try:
        import pyttsx3
        e = pyttsx3.init()
        voices = e.getProperty("voices") or []
        ru = [v for v in voices if "ru" in f"{v.name} {' '.join(getattr(v, 'languages', []) or [])}".lower()]
        ok(f"pyttsx3 работает, голосов: {len(voices)}, русских: {len(ru)}")
        if ru:
            engines.append("pyttsx3")
            print(f"        русский голос: {ru[0].name}")
        else:
            warn("русского голоса нет -> Параметры -> Время и язык -> Язык -> Русский -> добавить голос")
    except Exception as e:
        bad(f"pyttsx3 недоступен: {e}")
    try:
        import edge_tts  # noqa: F401
        ok("edge-tts установлен (нейро-голос ru-RU-DmitryNeural, нужен интернет)")
        engines.append("edge-tts")
    except Exception:
        warn("edge-tts не установлен (pip install edge-tts) — не критично")
    if not engines:
        # системный SAPI через PowerShell
        warn("останется системный SAPI через PowerShell (работает, но медленнее)")
    print(f"\n  {YEL}Произнесу тестовую фразу...{R}")
    try:
        from core import CFG, Speaker
        CFG.data["voice_output"] = True
        sp = Speaker(CFG)
        print(f"        выбранный движок: {sp.engine_name}")
        sp.say("Флюкс на связи. Голос работает.")
        time.sleep(0.5)
        # синхронно дождаться окончания
        sp.q.put(None)
        sp.thread.join(timeout=25)
        ok(f"озвучка через «{sp.engine_name}» выполнена")
        results["tts"] = sp.engine_name
    except Exception as e:
        bad(f"ошибка озвучки: {e}")


# ---------------------------------------------------------------- 6. итог
def summary():
    head("", "ИТОГ: что работает")
    lines = [
        ("SpeechRecognition", results.get("sr")),
        ("Микрофоны найдены", bool(results.get("mics"))),
        ("Запись с микрофона", results.get("record")),
        ("Распознавание речи", bool(results.get("recognize"))),
        ("Wake word «Флюкс»", results.get("wake")),
        ("Озвучка", results.get("tts")),
    ]
    backend = results.get("backend")
    if backend:
        lines.append((f"Движок микрофона: {backend}", True))
    lines += [
    ]
    good = 0
    for name, val in lines:
        if val is True or (isinstance(val, str) and val):
            ok(name + (f" ({val})" if isinstance(val, str) else ""))
            good += 1
        elif val is False:
            bad(name)
        else:
            warn(name + " — не проверялось")
    print()
    if good >= 5:
        print(f"  {GREEN}Всё готово — запускай run.bat и говори «Флюкс, привет»{R}")
    elif good >= 3:
        print(f"  {YEL}Работает частично. Смотри пункты [НЕТ] выше и TROUBLESHOOTING.md -> раздел 3.{R}")
    else:
        print(f"  {RED}Голос пока не работает. Запусти fix_voice.bat, затем этот тест снова.{R}")
    print(f"\n  {CY}Текстовый режим работает всегда:{R} run.bat -> печатай «Флюкс, какая погода»")
    print(f"  {CY}Push-to-talk без wake word:{R} Ctrl+Alt+F (нужен пакет keyboard)")
    print(f"  {CY}Одноразовый микрофон:{R} команда /listen в консоли Flux")


def main():
    print(f"{CY}FLUX :: диагностика голоса{R}   ({time.strftime('%d.%m.%Y %H:%M:%S')})")
    step_mics()
    audio = step_record(4)
    step_recognize(audio)
    step_tts()
    summary()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nпрервано")
        sys.exit(1)
    except Exception as e:
        print(f"{RED}критическая ошибка: {type(e).__name__}: {e}{R}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
