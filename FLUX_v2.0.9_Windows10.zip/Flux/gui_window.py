# -*- coding: utf-8 -*-
"""
FLUX :: gui_window.py
Плавающее окно-виджет (tkinter): чат, статус, микрофон, быстрые действия.
Запуск:  python flux.py --gui     (или команда в консоли: gui)
Работает поверх консоли, всегда сверху, можно свернуть в трей (если есть pystray).
"""
from __future__ import annotations

import json
import queue
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    import tkinter as tk
    from tkinter import scrolledtext, ttk
except Exception as e:  # pragma: no cover
    print("tkinter недоступен:", e)
    raise

BG = "#0b1118"
FG = "#e6edf3"
AC = "#22d3ee"
DIM = "#7f96ab"
CARD = "#111a24"


class FluxGUI:
    def __init__(self, app):
        self.app = app
        self.q: "queue.Queue[tuple[str, str]]" = queue.Queue()
        self.root = tk.Tk()
        self.root.title("FLUX :: AI-ассистент")
        self.root.geometry("460x520+80+80")
        self.root.configure(bg=BG)
        self.root.attributes("-topmost", True)
        try:
            self.root.attributes("-alpha", 0.98)
        except Exception:
            pass
        self._build()
        self._poll_queue()
        self._poll_status()
        self._poll_prompts()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.bind("<Control-Return>", lambda e: self.send())
        self.root.bind("<Escape>", lambda e: self.hide())

    # ---------------------------------------------------------------- UI
    def _build(self):
        top = tk.Frame(self.root, bg=CARD, height=44)
        top.pack(fill="x", side="top")
        top.pack_propagate(False)
        tk.Label(top, text="F L U X", bg=CARD, fg=AC, font=("Segoe UI", 13, "bold")).pack(side="left", padx=10)
        self.status_lbl = tk.Label(top, text="...", bg=CARD, fg=DIM, font=("Segoe UI", 8))
        self.status_lbl.pack(side="left", padx=4)
        self.mic_lbl = tk.Label(top, text="🎙", bg=CARD, fg=DIM, font=("Segoe UI", 12))
        self.mic_lbl.pack(side="right", padx=8)
        tk.Button(top, text="—", bg=CARD, fg=DIM, relief="flat", command=self.hide,
                  font=("Segoe UI", 11)).pack(side="right")
        tk.Button(top, text="🔊", bg=CARD, fg=DIM, relief="flat", command=self.toggle_tts,
                  font=("Segoe UI", 10)).pack(side="right")
        tk.Button(top, text="🎤", bg=CARD, fg=DIM, relief="flat", command=self.ptt,
                  font=("Segoe UI", 10)).pack(side="right")

        self.chat = scrolledtext.ScrolledText(self.root, bg=BG, fg=FG, insertbackground=FG,
                                              relief="flat", font=("Consolas", 10), wrap="word",
                                              padx=8, pady=8, state="disabled")
        self.chat.pack(fill="both", expand=True, padx=8, pady=(8, 4))
        for tag, col in (("u", "#8be9fd"), ("a", "#c9f2c7"), ("s", DIM), ("w", "#fbbf24"), ("e", "#f87171")):
            self.chat.tag_config(tag, foreground=col)

        quick = tk.Frame(self.root, bg=BG)
        quick.pack(fill="x", padx=8)
        for label, cmd in (("⏰ Таймер 5 мин", "таймер 5 мин"), ("🩺 Проверка ПК", "проверка системы"),
                           ("📸 Скриншот", "скриншот"), ("🔎 Поиск", "найди в интернете "),
                           ("📋 Расписание", "напоминания")):
            tk.Button(quick, text=label, bg=CARD, fg=AC, relief="flat", font=("Segoe UI", 8),
                      padx=6, pady=2, command=lambda c=cmd: self.put_input(c)).pack(side="left", padx=2, pady=2)

        bottom = tk.Frame(self.root, bg=BG)
        bottom.pack(fill="x", padx=8, pady=(2, 8))
        self.entry = tk.Entry(bottom, bg=CARD, fg=FG, insertbackground=AC, relief="flat",
                              font=("Segoe UI", 10))
        self.entry.pack(side="left", fill="x", expand=True, ipady=6, padx=(0, 6))
        self.entry.bind("<Return>", lambda e: self.send())
        tk.Button(bottom, text="➤", bg="#123246", fg=AC, relief="flat", font=("Segoe UI", 11),
                  padx=12, command=self.send).pack(side="right")

    # ---------------------------------------------------------------- логика
    def put_input(self, text: str):
        self.entry.delete(0, "end")
        self.entry.insert(0, text)
        self.entry.focus()

    def send(self):
        txt = self.entry.get().strip()
        if not txt:
            return
        self.entry.delete(0, "end")
        self.add("u", "ты: " + txt)
        threading.Thread(target=self._worker, args=(txt,), daemon=True).start()

    def _worker(self, txt: str):
        self.add("s", "flux: думаю...")
        try:
            res = self.app.handle_text(txt, source="gui")
            self.q.put(("replace_last", ("a", "flux: " + (res or "(пусто)"))))
        except Exception as e:
            self.q.put(("replace_last", ("e", f"ошибка: {e}")))

    def ptt(self):
        if not (self.app.voice and self.app.voice.ready):
            self.add("w", "flux: микрофон недоступен — " + str(self.app.voice.reason if self.app.voice else "voice off"))
            return
        threading.Thread(target=self._ptt_worker, daemon=True).start()

    def _ptt_worker(self):
        self.add("s", "🎤 слушаю...")
        txt = self.app.voice.listen_once(10)
        if txt:
            self.q.put(("input", txt))
        else:
            self.q.put(("add", ("w", "🎤 ничего не услышал")))

    def toggle_tts(self):
        from core import CFG, get_speaker
        on = not bool(CFG.get("voice_output"))
        CFG.set("voice_output", on)
        get_speaker().set_enabled(on)
        self.add("s", f"озвучка {'включена' if on else 'выключена'}")

    def hide(self):
        self.root.withdraw()

    def show(self):
        self.root.deiconify()
        self.root.attributes("-topmost", True)

    def on_close(self):
        # FIX: раньше крестик виджета вызывал app.shutdown() — останавливались голос,
        # сторож, планировщик и панель, хотя консольный Flux продолжал работать «полумёртвым».
        # Теперь закрытие окна = свернуть; настоящий выход — /exit в консоли или «Выход» в трее.
        self.add("s", "flux: окно свёрнуто (ассистент продолжает работать). Полный выход: /exit или трей → Выход")
        self.hide()

    def add(self, tag: str, text: str):
        self.q.put(("add", (tag, text)))

    def _render(self, tag: str, text: str):
        self.chat.configure(state="normal")
        self.chat.insert("end", text + "\n", tag)
        self.chat.configure(state="disabled")
        self.chat.see("end")

    def _poll_queue(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "add":
                    self._render(*payload)
                elif kind == "replace_last":
                    self.chat.configure(state="normal")
                    self.chat.delete("end-2l", "end-1l")
                    self.chat.configure(state="disabled")
                    self._render(*payload)
                elif kind == "input":
                    self.entry.delete(0, "end")
                    self.entry.insert(0, payload)
                    self.send()
        except queue.Empty:
            pass
        self.root.after(120, self._poll_queue)

    # ---------------------------------------------------------------- вопросы брокера
    def _poll_prompts(self):
        """FIX: в режиме --gui (без REPL) вопросы инструментов (ask_user, подтверждение
        опасных действий) никто не разбирал — поток висел 600 сек и получал «н».
        Теперь GUI показывает диалог и отправляет ответ в PromptBroker."""
        try:
            import flux as _fx
            broker = getattr(_fx, "PROMPTS", None)
            if broker is not None:
                try:
                    prompt, aq = broker.pending.get_nowait()
                    self._ask_dialog(prompt, aq)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            self.root.after(700, self._poll_prompts)
        except Exception:
            pass

    def _ask_dialog(self, prompt: str, aq):
        import tkinter as tk2
        top = tk2.Toplevel(self.root)
        top.title("FLUX :: нужен ответ")
        top.configure(bg=CARD)
        top.attributes("-topmost", True)
        top.geometry("420x160")
        tk2.Label(top, text=prompt.strip(), bg=CARD, fg="#fbbf24", wraplength=390,
                  justify="left", font=("Segoe UI", 10)).pack(padx=10, pady=(12, 6), anchor="w")
        ent = tk2.Entry(top, bg=BG, fg=FG, insertbackground=AC, relief="flat", font=("Segoe UI", 10))
        ent.pack(fill="x", padx=10, pady=4)
        ent.focus_set()

        def done(val=None):
            aq.put(val if val is not None else (ent.get().strip() or "н"))
            try:
                top.destroy()
            except Exception:
                pass

        row = tk2.Frame(top, bg=CARD)
        row.pack(pady=8)
        tk2.Button(row, text="Да", bg="#123246", fg="#4ade80", relief="flat", width=8,
                   command=lambda: done("д")).pack(side="left", padx=4)
        tk2.Button(row, text="Нет", bg="#123246", fg="#f87171", relief="flat", width=8,
                   command=lambda: done("н")).pack(side="left", padx=4)
        tk2.Button(row, text="OK", bg="#123246", fg=AC, relief="flat", width=8,
                   command=lambda: done()).pack(side="left", padx=4)
        ent.bind("<Return>", lambda e: done())
        top.protocol("WM_DELETE_WINDOW", lambda: done("н"))

    def _poll_status(self):
        try:
            st = self.app.status_dict()
            self.status_lbl.config(text=f"{st.get('model','?')}  •  ходов: {st.get('turns')}  •  {st.get('uptime_min')} мин")
            v = self.app.voice
            self.mic_lbl.config(fg=("#4ade80" if v and v.ready and not v.stop_flag.is_set() else "#f87171"))
            if st.get("problems"):
                self.status_lbl.config(fg="#fbbf24", text=f"⚠ {len(st['problems'])} замечаний по системе")
            else:
                self.status_lbl.config(fg=DIM)
        except Exception:
            pass
        self.root.after(4000, self._poll_status)

    def run(self):
        self.root.mainloop()


def launch(app, blocking: bool = False):
    """Запуск GUI. blocking=True — занять текущий поток (для --gui)."""
    gui = FluxGUI(app)
    app.gui = gui
    # глобальная горячая клавиша показать/спрятать окно
    # FIX: вызывать методы Tk из потока библиотеки keyboard небезопасно (Tk не thread-safe) —
    # маршалим через root.after
    try:
        import keyboard  # type: ignore

        def _toggle():
            try:
                gui.root.after(0, lambda: (gui.show() if not gui.root.winfo_viewable() else gui.hide()))
            except Exception:
                pass
        keyboard.add_hotkey("ctrl+alt+space", _toggle)
    except Exception:
        pass
    if blocking:
        gui.run()
    else:
        t = threading.Thread(target=gui.run, daemon=True, name="flux-gui")
        t.start()
        return gui


# ---------------------------------------------------------------- трей
def start_tray(app):
    """Иконка в трее (нужен pystray + pillow). Необязательно."""
    try:
        import pystray  # type: ignore
        from PIL import Image, ImageDraw  # type: ignore
    except Exception:
        return None

    def make_icon():
        img = Image.new("RGB", (64, 64), "#0b1118")
        d = ImageDraw.Draw(img)
        d.ellipse((8, 8, 56, 56), outline="#22d3ee", width=4)
        d.ellipse((26, 26, 38, 38), fill="#22d3ee")
        return img

    def on_show(icon, item):
        try:
            app.gui.show()
        except Exception:
            pass

    def on_exit(icon, item):
        try:
            app.shutdown()
        except Exception:
            pass
        icon.stop()

    menu = pystray.Menu(
        pystray.MenuItem("Открыть FLUX", on_show, default=True),
        pystray.MenuItem("Статус", lambda i, it: app.out(json.dumps(app.status_dict(), ensure_ascii=False, indent=2))),
        pystray.MenuItem("Выход", on_exit),
    )
    icon = pystray.Icon("flux", make_icon(), "FLUX AI assistant", menu)
    t = threading.Thread(target=icon.run, daemon=True, name="flux-tray")
    t.start()
    return icon
