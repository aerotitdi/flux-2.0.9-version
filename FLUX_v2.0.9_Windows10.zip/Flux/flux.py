#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
================================================================================
 FLUX  ::  автономный ИИ-ассистент-агент для Windows 10/11
================================================================================
 Модель      : qwen/qwen3.8-max:free  (https://api.xkiro.com/v1)
 Веб-поиск   : SearXNG в Docker -> http://localhost:8888 (+ резервные движки)
 Голос       : wake word "ФЛЮКС ..." (распознавание) + озвучка ответов
 Агент       : 40+ инструментов (файлы, процессы, экран, звук, сеть, безопасность,
               таймеры, напоминания, веб, создание программ на лету)
 Проактивность: сам следит за ПК и сообщает о важном (вирусы, перегрев, диск...)
 Память      : долгая память + сессии на диске + автосжатие контекста (экономия токенов)
 Панель      : http://127.0.0.1:8787 (статус, чат, напоминания, логи)

 Запуск      : run.bat   (или  python flux.py)
 Установка   : install.bat   (ставит всё на D:\Flux)
================================================================================
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import json
import os
import queue
import random
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.parse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from core import (APPS_DIR, AUDIO_DIR, CFG, C, DATA, DOWNLOAD_DIR, IS_WIN, LOG_DIR, MEMORY_DIR,
                  ROOT, SANDBOX_DIR, SCREEN_DIR, SESSIONS_DIR, banner, beep, clear_screen, clip,
                  cmd_run, debug, dlog, exc_text, file_to_base64, get_api_key, get_speaker,
                  html_to_text, http_get_text, http_json, human_time, is_admin, jload, jsave,
                  key_source, local_ip, log, masked_key, now, now_iso, open_path, port_open,
                  powershell, pwsh_json, rand_id, run, safe_filename, say, sizeof_fmt, toast,
                  tools_log, truncate_middle)
import core.tools_system as TS
import core.tools_web as TW
import core.tools_time as TT
import core.tools_brain as TB
from core import qwen_web as QW

VERSION = "2.0.9"
BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
TOOLS = TS.REGISTRY
START_TIME = time.time()

# ============================================================================
#  СИСТЕМНЫЙ ПРОМПТ
# ============================================================================
def system_prompt(extra_memory: str = "", health_hint: str = "") -> str:
    name = CFG.get("assistant_name", "Флюкс")
    mem = extra_memory.strip()
    prof = (TB._mem().get("user") or {})
    uname = prof.get("name") or "пользователь"
    return f"""Ты — {name.upper()} (Flux), автономный ИИ-ассистент-агент, работающий НА КОМПЬЮТЕРЕ ПОЛЬЗОВАТЕЛЯ (Windows 10/11) с ПОЛНЫМ доступом к системе через набор инструментов.
Тебя зовут {name}. Обращайся к себе в мужском роде как «{name}». Пользователя зовут: {uname}.
Твоя база — модель qwen 3.8 max (free) через api.xkiro.com. Версия Flux {VERSION}. Сейчас {human_time()}.

# ГЛАВНЫЕ ПРАВИЛА
1. ТЫ — АГЕНТ. Не рассказывай, как что-то сделать, ЕСЛИ можешь сделать сам: сразу вызывай инструмент. Действие > слова.
2. Никогда не выдумывай факты, пути, версии, цены, погоду, время. Не знаешь — проверь инструментом (get_time, web_search, system_info, read_file).
3. Любые операции с файловой системой/системой — только через инструменты. Перед удалением/перезаписью проверяй существование (file_ops info / read_file).
4. Отвечай на русском, кратко и по делу (2-6 предложений), без воды и без пересказа своих действий по шагам. Форматирование markdown умеренно.
5. Ответ озвучивается голосом, поэтому не пиши длинные таблицы/списки в голосовых сценариях — давай суть, детали оставляй в тексте.
6. Если задача многошаговая — разбей на шаги и выполняй инструменты последовательно (до {CFG.get('max_tool_steps')} шагов). Не останавливайся на полпути.
7. Если инструмент вернул ошибку — проанализируй hint/error, попробуй другой подход (другой путь, другая кодировка, резервный движок). Не сдавайся с первой попытки.
8. Если нужно подтверждение пользователя — спроси прямо одним вопросом.
9. Опасные действия (удаление, форматирование, shutdown, taskkill) — всегда предупреждай. Система сама запросит подтверждение.
10. Если пользователь говорит «в фоне»/«не мешай» — используй background=true у run_command/run_python/start_program/create_app.
11. Если платформа НЕ даёт function calling (нет списка tools в запросе), вызывай инструменты ТЕКСТОМ:
    выведи отдельной строкой JSON вида {{"tool": "имя_инструмента", "args": {{"ключ": "значение"}}}} —
    система выполнит его и вернёт результат следующим сообщением. За один ответ — один такой вызов.

# ВОЗМОЖНОСТИ (инструменты)
• Файлы: list_dir, read_file, write_file, edit_file, search_files, file_ops (copy/move/delete/zip/info/trash)
• Система: system_info, run_command (cmd/PowerShell), run_python, start_program, find_app, process_list, process_kill, system_control (громкость/яркость/медиа/сон/блокировка/монитор), clipboard, notify, security_scan, system_events, network_diagnostics
• Создание программ на лету: create_app (python/pythonw/batch/vbs/html/shortcut/service_task) + запуск в фоне
• Экран и звук: screen_capture (с мгновенным vision-анализом), screen_read (OCR), audio_record, audio_play
• Интернет: web_search (SearXNG Docker http://localhost:8888 + фолбэк DDG/Bing), fetch_url, web_research (глубокий анализ темы), weather, translate, download_file, download_media, searxng_status
• Время и напоминания: get_time, timer (с оповещением), reminder (repeat daily/weekdays/cron/every_N), schedule_list, stopwatch
• Мозг и память: memory (запомнить/вспомнить), notes (заметки и to-do), events_log, system_health, proactive_watchdog
• Взаимодействие: ask_user (задать вопрос пользователю), flux_config (изменить свои настройки), send_to_panel (сообщение в веб-панель)

# ПРОАКТИВНОСТЬ (важно!)
Ты можешь и ДОЛЖЕН сам начинать разговор, но ТОЛЬКО если произошло нечто ВАЖНОЕ:
обнаружен вирус/угроза, отключён антивирус, критически мало места на диске, перегрев,
ПК вот-вот упадёт по памяти, программа постоянно падает, пропал интернет, садится батарея,
сработал таймер/напоминание, или ты нашёл проблему во время выполнения задачи.
В таком случае: 1) коротко и чётко предупреди («⚠ Важно: ...»), 2) скажи, чем это грозит,
3) предложи конкретное действие и предложи выполнить его сразу. Не болтай о мелочах и не повторяй одно и то же.
Если пришло сообщение, начинающееся с «ПРОАКТИВНОЕ ОПОВЕЩЕНИЕ СИСТЕМЫ» — это данные твоего сторожа: обработай их и обратись к пользователю сам.

# БЕЗОПАСНОСТЬ
• Не выполняй деструктивные команды без предупреждения. Не хранит пароли/ключи в памяти (memory), кроме случаев явной просьбы.
• Не отправляй личные данные пользователя в интернет. Не скачивай и не запускай исполняемые файлы из непроверенных источников без явного разрешения.
• При признаках заражения: security_scan threats + quick_scan, покажи отчёт, предложи full_scan и очистку автозагрузки.

# КОНТЕКСТ ПАМЯТИ ПОЛЬЗОВАТЕЛЯ
{mem if mem else '(пока пусто — запоминай важное через memory)'}
{('СВЕЖИЕ ДАННЫЕ О СИСТЕМЕ: ' + health_hint) if health_hint else ''}

# СТИЛЬ
Дружелюбный, уверенный, технически грамотный, с лёгким чувством юмора (как Джарвис, но зовут {name}). Без канцелярита и без «как языковая модель». Ты — часть системы пользователя.
"""


# ============================================================================
#  LLM КЛИЕНТ (OpenAI-compatible, streaming + retries + model fallback)
# ============================================================================
class LLMError(Exception):
    pass


class LLM:
    PROVIDER_NAMES = {
        "xkiro": "api.xkiro.com (ключ xkiro)",
        "qwen_web": "chat.qwen.ai (встроенный мост, без лимитов xkiro)",
        "ollama": "Ollama (локальные модели, без интернета)",
        "bridge": "внешний мост tools/qwen_bridge.py (:8000)",
    }

    def __init__(self, cfg):
        self.cfg = cfg
        self.model = cfg.get("model")
        self.api_key = get_api_key()
        self._key_refreshed = False
        # v2.0.6: провайдеры моделей + пул ключей + авто-фолбэк
        self.provider = str(cfg.get("provider") or "xkiro")
        if self.provider not in self.PROVIDER_NAMES:
            self.provider = "xkiro"
        self._key_idx = 0
        self.base = self._base_for(self.provider)
        self.no_tools_models: set[str] = set()
        self.used_models: list[str] = []
        self.total_calls = 0
        self.total_tokens = {"prompt": 0, "completion": 0}
        self.last_error = ""

    # ------------------------------------------------------------- провайдеры
    def _base_for(self, provider: str) -> str:
        if provider == "ollama":
            return str(self.cfg.get("ollama_url") or "http://127.0.0.1:11434").rstrip("/") + "/v1"
        if provider == "bridge":
            return str(self.cfg.get("bridge_url") or "http://127.0.0.1:8000/v1").rstrip("/")
        return str(self.cfg.get("base_url")).rstrip("/")

    def key_pool(self) -> list:
        from core import sanitize_key
        pool = [get_api_key()] + [sanitize_key(k) for k in (self.cfg.get("api_keys") or [])]
        out = []
        for k in pool:
            if k and k not in out:
                out.append(k)
        return out

    def _current_key(self) -> str:
        pool = self.key_pool()
        if not pool:
            return ""
        self._key_idx %= len(pool)
        self.api_key = pool[self._key_idx]
        return self.api_key

    def provider_ready(self, p: str) -> tuple:
        """(готов ли провайдер, пояснение)"""
        try:
            if p == "xkiro":
                n = len(self.key_pool())
                return (n > 0, f"ключей в пуле: {n}" if n else "нет ключа xkiro")
            if p == "qwen_web":
                ok = QW.get_client().ready()
                return (ok, "токен chat.qwen.ai есть" if ok else "нет токена qwen_web.key")
            if p == "ollama":
                u = urllib.parse.urlparse(str(self.cfg.get("ollama_url") or "http://127.0.0.1:11434"))
                ok = port_open(u.hostname or "127.0.0.1", int(u.port or 11434), 0.8)
                return (ok, "ollama доступна" if ok else "ollama не запущена")
            if p == "bridge":
                u = urllib.parse.urlparse(str(self.cfg.get("bridge_url") or "http://127.0.0.1:8000/v1"))
                ok = port_open(u.hostname or "127.0.0.1", int(u.port or 8000), 0.8)
                return (ok, "мост :8000 отвечает" if ok else "мост не запущен")
        except Exception as e:
            return (False, str(e)[:80])
        return (False, "неизвестный провайдер")

    def providers_status(self) -> list:
        out = []
        for pid, name in self.PROVIDER_NAMES.items():
            ok, detail = self.provider_ready(pid)
            out.append({"id": pid, "name": name, "ready": ok, "detail": detail,
                        "active": pid == self.provider})
        return out

    def set_provider(self, provider: str, model: str | None = None) -> dict:
        if provider not in self.PROVIDER_NAMES:
            return {"ok": False, "error": f"нет провайдера '{provider}'",
                    "providers": list(self.PROVIDER_NAMES)}
        old = self.provider
        CFG.set("provider", provider)
        self.provider = provider
        self.base = self._base_for(provider)
        self.used_models.clear()
        self.no_tools_models.clear()
        mbp = dict(CFG.get("models_by_provider") or {})
        if model:
            mbp[provider] = model
            CFG.set("models_by_provider", mbp)
            self.model = model
        else:
            self.model = mbp.get(provider) or self._default_model_for(provider)
        CFG.set("model", self.model)
        dlog(f"[llm] provider: {old} -> {provider} (model={self.model})")
        return {"ok": True, "provider": provider, "model": self.model, "base": self.base}

    def _rotate_or_fallback(self, err: str) -> bool:
        """Сначала следующий ключ из пула, потом другой провайдер."""
        pool = self.key_pool()
        if self.provider in ("xkiro",) and len(pool) > 1:
            self._key_idx = (self._key_idx + 1) % len(pool)
            self.api_key = pool[self._key_idx]
            dlog(f"[llm] ротация ключа xkiro -> #{self._key_idx} ({masked_key()})")
            return True
        for p in (self.cfg.get("auto_fallback_providers") or []):
            if p == self.provider:
                continue
            ok, detail = self.provider_ready(p)
            if ok:
                old = self.provider
                self.provider = p
                self.base = self._base_for(p)
                mbp = dict(CFG.get("models_by_provider") or {})
                self.model = mbp.get(p) or self._default_model_for(p)
                CFG.set("provider", p, save=False)
                CFG.set("model", self.model, save=False)
                CFG.save()
                msg = (f"⚡ лимит/отказ {old} -> переключаюсь на провайдер {p} "
                       f"(модель {self.model}; {detail})")
                dlog("[llm] " + msg)
                try:
                    if PANEL:
                        PANEL.push(msg, "warn")
                except Exception:
                    pass
                return True
        return False

    # ------------------------------------------------------------ low level
    def _url(self, path: str) -> str:
        return self.base + path

    def _headers(self) -> dict:
        """Полная браузерная подпись запроса.
        Без User-Agent urllib шлёт 'Python-urllib/3.x', который Cloudflare
        банит ошибкой 1010 ('blocked based on your browser's signature')."""
        h = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
            "User-Agent": BROWSER_UA,
            "Origin": "https://xkiro.com",
            "Referer": "https://xkiro.com/",
            "sec-ch-ua": '"Chromium";v="126", "Not-A.Brand";v="24", "Google Chrome";v="126"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "cross-site",
        }
        if self.provider == "ollama":
            h.pop("Origin", None)
            h.pop("Referer", None)
            h["Authorization"] = "Bearer ollama"   # ollama игнорирует, но некоторые прокси ждут
            return h
        if self.provider == "bridge":
            bk = str(self.cfg.get("bridge_api_key") or "") or "sk-flux-bridge"
            h["Authorization"] = "Bearer " + bk
            return h
        key = self._current_key()
        if not key:
            # ключ могли дописать в secret.key уже после запуска — перечитываем
            key = get_api_key()
            self.api_key = key
        if key:
            h["Authorization"] = "Bearer " + key
            h["x-api-key"] = key
        return h

    def list_models(self) -> list[dict]:
        if self.provider == "qwen_web":
            try:
                ms = QW.get_client().models()
            except Exception as e:
                dlog(f"[llm] qwen models: {e}")
                return []
            out = []
            for m in ms:
                out.append({"id": m["id"], "tier": "free", "tools": False, "vision": False,
                            "context": None, "search": bool(m.get("search")),
                            "local": False})
                if m.get("search"):
                    out.append({"id": m["id"] + ":search", "tier": "free", "tools": False,
                                "vision": False, "context": None, "search": True,
                                "note": "модель сама ищет в интернете", "local": False})
            return out
        if self.provider == "ollama":
            tags_url = self._base_for("ollama").rstrip("/").rsplit("/v1", 1)[0] + "/api/tags"
            st, body = http_json(tags_url, timeout=15)
            out = []
            if st == 200 and isinstance(body, dict):
                for m in body.get("models") or []:
                    out.append({"id": m.get("name"), "tier": "local", "tools": True,
                                "vision": False, "context": None, "search": False, "local": True})
            return out
        st, body = http_json(self._url("/models"), timeout=30, headers=self._headers())
        if st != 200 or not isinstance(body, dict):
            return []
        out = []
        for m in body.get("data") or []:
            out.append({"id": m.get("id"), "tier": m.get("access_tier"),
                        "tools": (m.get("capabilities") or {}).get("tools"),
                        "vision": (m.get("capabilities") or {}).get("vision"),
                        "context": m.get("context_length"), "search": False, "local": False})
        if CFG.get("prefer_free_models", True):
            out.sort(key=lambda x: 0 if x.get("tier") == "free" else 1)
        return out

    def chat(self, messages: list[dict], tools: list[dict] | None = None,
             model: str | None = None, stream: bool = True, on_delta=None,
             temperature: float | None = None, max_tokens: int | None = None) -> dict:
        """Возвращает {content, tool_calls, model, usage, finish_reason}."""
        model = model or self.model
        payload = {
            "model": model,
            "messages": messages,
            "temperature": float(temperature if temperature is not None else self.cfg.get("temperature", 0.6)),
            "max_tokens": int(max_tokens or self.cfg.get("max_tokens", 4096)),
            "stream": bool(stream),
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
            payload["parallel_tool_calls"] = True
        if stream:
            payload["stream_options"] = {"include_usage": True}

        retries = int(self.cfg.get("max_retries", 4))
        timeout = int(self.cfg.get("request_timeout", 240))
        last_err = ""
        for attempt in range(retries):
            try:
                if self.provider == "qwen_web":
                    res = self._qwen_call(messages, model, bool(payload.get("stream")),
                                          on_delta, timeout)
                elif payload.get("stream"):
                    res = self._stream(payload, timeout, on_delta)
                else:
                    res = self._plain(payload, timeout)
                self.total_calls += 1
                u = res.get("usage") or {}
                self.total_tokens["prompt"] += int(u.get("prompt_tokens") or 0)
                self.total_tokens["completion"] += int(u.get("completion_tokens") or 0)
                res.setdefault("model", model)
                if model not in self.used_models:
                    self.used_models.append(model)
                return res
            except LLMError as e:
                last_err = str(e)
                self.last_error = last_err
                code = getattr(e, "status", 0)
                # v2.0.6: исчерпан лимит/ключ отвергнут -> следующий ключ пула или другой провайдер
                if code in (429, 401, 403) and self._rotate_or_fallback(last_err):
                    payload["model"] = model = self.model
                    dlog(f"[llm] продолжаю на {self.provider}/{model}")
                    continue
                # FIX: некоторые OpenAI-совместимые серверы не знают parallel_tool_calls —
                # раньше из-за этого флага отключались ВСЕ инструменты модели
                if code == 400 and "parallel" in last_err.lower() and payload.get("parallel_tool_calls"):
                    payload.pop("parallel_tool_calls", None)
                    dlog("[llm] сервер не знает parallel_tool_calls, повторяю без него")
                    continue
                # модель не поддерживает tools -> пробуем без них
                if code in (400, 404, 422) and tools and ("tool" in last_err.lower() or "function" in last_err.lower()):
                    self.no_tools_models.add(model)
                    payload.pop("tools", None)
                    payload.pop("tool_choice", None)
                    payload.pop("parallel_tool_calls", None)
                    dlog(f"[llm] модель {model} без tools, повторяю")
                    continue
                # недоступная/несуществующая модель -> фолбэк
                if code in (400, 404, 403) and ("model" in last_err.lower() or "not found" in last_err.lower()):
                    nxt = self._next_model(model)
                    if nxt:
                        dlog(f"[llm] {model} недоступна -> {nxt}")
                        model = nxt
                        payload["model"] = model
                        continue
                if code in (401, 403) and "key" in last_err.lower() and self.provider != "qwen_web":
                    # один раз перечитываем ключ с диска и повторяем запрос
                    fresh = get_api_key()
                    if fresh and fresh != self.api_key and not self._key_refreshed:
                        self._key_refreshed = True
                        self.api_key = fresh
                        dlog("[llm] ключ перечитан с диска, повторяю запрос")
                        continue
                    low = last_err.lower()
                    if "missing" in low:
                        hint = ("сервер НЕ ПОЛУЧИЛ ключ вообще. Проверь, что ключ лежит в "
                                "D:\\Flux\\secret.key одной строкой, и перезапусти Flux.")
                    else:
                        hint = ("сервер ОТВЕРГ ключ ('Invalid or disabled ClientApiKey'). "
                                "Убедись, что в secret.key нет кавычек/пробелов, и что ключ активен "
                                "на https://xkiro.com -> API Keys.")
                    raise LLMError(f"Проблема с API-ключом (HTTP {code}). Ключ: {masked_key()}, "
                                   f"источник: {key_source()}. {hint} "
                                   f"Ответ сервера: {last_err[:220]}") from e
                if code == 403 and ("cloudflare" in last_err.lower() or "1010" in last_err):
                    raise LLMError("Cloudflare заблокировал запрос к api.xkiro.com (ошибка 1010). "
                                   "Обнови Flux до v2.0.2+ (заголовки исправлены) или проверь, "
                                   "не блокирует ли прокси/антивирус HTTPS. Ключ здесь ни при чём.") from e
                if code == 429 or code >= 500 or code in (-1, 0):
                    wait = min(30, 2 ** attempt + random.random())
                    dlog(f"[llm] {code} retry in {wait:.1f}s: {last_err[:160]}")
                    time.sleep(wait)
                    continue
                raise
            except Exception as e:
                last_err = f"{type(e).__name__}: {e}"
                self.last_error = last_err
                if attempt < retries - 1:
                    time.sleep(min(20, 2 ** attempt))
                    continue
                raise LLMError(last_err) from e
        raise LLMError(f"все попытки исчерпаны: {last_err[:400]}")

    def _default_model_for(self, p: str) -> str:
        mbp = self.cfg.get("models_by_provider") or {}
        cur = mbp.get(p)
        if cur:
            return str(cur)
        if p == "qwen_web":
            return str(self.cfg.get("qwen_default_model") or "qwen3.8-max:search")
        if p == "bridge":
            return str(self.cfg.get("qwen_default_model") or "qwen3.8-max")
        if p == "ollama":
            return str(self.cfg.get("ollama_model") or "") or str(self.model)
        return str(self.cfg.get("model"))

    def _qwen_call(self, messages, model, stream, on_delta, timeout, _auto_tried=False) -> dict:
        """Запрос через встроенный мост chat.qwen.ai (без лимитов xkiro)."""
        try:
            res = QW.get_client().chat(messages, model=model, stream=stream,
                                       on_delta=on_delta, timeout=timeout)
        except QW.QwenWebError as e:
            # v2.0.9: токен протух -> пробуем АВТО-обновление из браузера и один ретрай
            if getattr(e, "status", 0) == 401 and not _auto_tried and CFG.get("qwen_auto_token", True):
                ar = QW.auto_refresh_token(force=True)
                if ar.get("updated"):
                    msg = f"🔑 qwen-токен авто-обновлён из {ar.get('source')} ({ar.get('detail')})"
                    dlog("[llm] " + msg)
                    try:
                        if PANEL:
                            PANEL.push(msg, "info")
                    except Exception:
                        pass
                    return self._qwen_call(messages, model, stream, on_delta, timeout,
                                           _auto_tried=True)
            err = LLMError(str(e))
            err.status = getattr(e, "status", 502)
            raise err from e
        self.total_calls += 1
        u = res.get("usage") or {}
        self.total_tokens["prompt"] += int(u.get("prompt_tokens") or 0)
        self.total_tokens["completion"] += int(u.get("completion_tokens") or 0)
        res.setdefault("tool_calls", [])
        if model not in self.used_models:
            self.used_models.append(model)
        return res

    def _next_model(self, current: str) -> str | None:
        cands = [current] + list(self.cfg.get("model_fallbacks") or [])
        for c in cands:
            if c != current and c not in self.used_models[-3:]:
                return c
        for c in (self.cfg.get("model_fallbacks") or []):
            if c != current:
                return c
        return None

    def _plain(self, payload: dict, timeout: int) -> dict:
        st, body = http_json(self._url("/chat/completions"), "POST", payload=payload,
                             headers=self._headers(), timeout=timeout)
        if st != 200 or not isinstance(body, dict):
            e = LLMError(self._err_text(st, body))
            e.status = st
            raise e
        ch = (body.get("choices") or [{}])[0]
        msg = ch.get("message") or {}
        return {"content": msg.get("content") or "", "tool_calls": msg.get("tool_calls") or [],
                "finish_reason": ch.get("finish_reason"), "usage": body.get("usage") or {},
                "reasoning": msg.get("reasoning_content") or ""}

    def _stream(self, payload: dict, timeout: int, on_delta) -> dict:
        import urllib.request
        req = urllib.request.Request(self._url("/chat/completions"),
                                     data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                                     headers=self._headers(), method="POST")
        content_parts, reasoning_parts = [], []
        tool_acc: dict[int, dict] = {}
        usage, finish = {}, None
        model_used = payload["model"]
        try:
            resp = urllib.request.urlopen(req, timeout=timeout)
        except urllib.error.HTTPError as e:
            raw = ""
            try:
                raw = e.read(4000).decode("utf-8", "replace")
            except Exception:
                pass
            err = LLMError(self._err_text(e.code, raw))
            err.status = e.code
            raise err
        except Exception as e:
            err = LLMError(f"{type(e).__name__}: {e}")
            err.status = -1
            raise err
        try:
            # FIX: читаем БАЙТЫ и декодируем инкрементально.
            # Было: resp.read(1) + decode("utf-8","replace") — каждая кириллическая
            # буква превращалась в "" (многобайтовый UTF-8 резался по одному байту).
            import codecs
            decoder = codecs.getincrementaldecoder("utf-8")("replace")
            buf = ""
            while True:
                chunk = resp.read(8192)
                if not chunk:
                    buf += decoder.decode(b"", True)
                    break
                buf += decoder.decode(chunk)
                while "\n" in buf:
                    line, buf = buf.split("\n", 1)
                    line = line.strip()
                    if not line or line.startswith(":"):
                        continue
                    if line.startswith("data:"):
                        line = line[5:].strip()
                    if line == "[DONE]":
                        continue
                    try:
                        j = json.loads(line)
                    except Exception:
                        continue
                    if j.get("model"):
                        model_used = j["model"]
                    if j.get("usage"):
                        usage = j["usage"]
                    for ch in (j.get("choices") or []):
                        if ch.get("finish_reason"):
                            finish = ch["finish_reason"]
                        d = ch.get("delta") or {}
                        rc = d.get("reasoning_content") or d.get("reasoning") or ""
                        if rc:
                            reasoning_parts.append(rc)
                        c = d.get("content")
                        if c:
                            content_parts.append(c)
                            if on_delta:
                                try:
                                    on_delta(c)
                                except Exception:
                                    pass
                        for tc in (d.get("tool_calls") or []):
                            idx = int(tc.get("index") or 0)
                            slot = tool_acc.setdefault(idx, {"id": "", "type": "function",
                                                             "function": {"name": "", "arguments": ""}})
                            if tc.get("id"):
                                slot["id"] = tc["id"]
                            fn = tc.get("function") or {}
                            if fn.get("name"):
                                slot["function"]["name"] += fn["name"]
                            if fn.get("arguments"):
                                slot["function"]["arguments"] += fn["arguments"]
        finally:
            try:
                resp.close()
            except Exception:
                pass
        calls = [tool_acc[i] for i in sorted(tool_acc)]
        calls = [c for c in calls if c["function"]["name"]]
        return {"content": "".join(content_parts), "tool_calls": calls, "finish_reason": finish,
                "usage": usage, "model": model_used, "reasoning": "".join(reasoning_parts)}

    @staticmethod
    def _err_text(st, body) -> str:
        if isinstance(body, dict):
            e = body.get("error") or {}
            if isinstance(e, dict):
                return f"HTTP {st}: {e.get('message') or json.dumps(e, ensure_ascii=False)[:300]}"
            return f"HTTP {st}: {str(e)[:300]}"
        return f"HTTP {st}: {str(body)[:300]}"


# ============================================================================
#  СЕССИИ / КОНТЕКСТ
# ============================================================================
class Session:
    """История диалога с автосохранением на диск и сжатием (экономия токенов)."""

    def __init__(self, path: Path | None = None, title: str = ""):
        self.id = "s_" + dt.datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + rand_id(4)
        self.path = path or (SESSIONS_DIR / (self.id + ".jsonl"))
        self.title = title or self.id
        self.messages: list[dict] = []
        self.summary: str = ""
        self.created = now_iso()
        self.turns = 0
        self._dirty = False
        self._absorbed_upto = 0   # FIX: сколько самых старых сообщений уже ушло в summary

    # ---------------- persistence
    def save(self):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(json.dumps({"type": "meta", "id": self.id, "title": self.title,
                                    "created": self.created, "summary": self.summary,
                                    "turns": self.turns, "saved": now_iso()}, ensure_ascii=False) + "\n")
                for m in self.messages:
                    f.write(json.dumps({"type": "msg", **m}, ensure_ascii=False, default=str) + "\n")
            os.replace(str(tmp), str(self.path))
            self._dirty = False
        except Exception as e:
            log.warning("session save: %s", e)

    @classmethod
    def load(cls, path: Path):
        s = cls(path=path)
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        j = json.loads(line)
                    except Exception:
                        continue
                    if j.get("type") == "meta":
                        s.id = j.get("id") or s.id
                        s.title = j.get("title") or s.title
                        s.created = j.get("created") or s.created
                        s.summary = j.get("summary") or ""
                        s.turns = int(j.get("turns") or 0)
                    elif j.get("type") == "msg":
                        j.pop("type", None)
                        s.messages.append(j)
        except Exception as e:
            log.warning("session load %s: %s", path, e)
        return s

    @staticmethod
    def list_sessions(limit: int = 25) -> list[dict]:
        out = []
        try:
            for p in sorted(SESSIONS_DIR.glob("*.jsonl"), key=lambda x: x.stat().st_mtime, reverse=True)[:limit]:
                meta = {"file": str(p), "size": sizeof_fmt(p.stat().st_size),
                        "modified": human_time(p.stat().st_mtime)}
                try:
                    with open(p, "r", encoding="utf-8") as f:
                        first = f.readline().strip()
                        if first:
                            j = json.loads(first)
                            meta["title"] = j.get("title")
                            meta["turns"] = j.get("turns")
                            meta["created"] = j.get("created")
                except Exception:
                    pass
                out.append(meta)
        except Exception:
            pass
        return out

    # ---------------- messages
    def add(self, role: str, content, **kw):
        m = {"role": role, "content": content}
        m.update(kw)
        self.messages.append(m)
        self._dirty = True
        return m

    def auto_title(self):
        if self.title == self.id:
            for m in self.messages:
                if m.get("role") == "user" and isinstance(m.get("content"), str) and m["content"].strip():
                    self.title = m["content"].strip().replace("\n", " ")[:60]
                    break

    def context(self, llm_messages_head: list[dict]) -> list[dict]:
        """Собирает итоговый контекст: head(system) + summary + свежие сообщения, в пределах бюджета."""
        cc = CFG.get("context") or {}
        max_chars = int(cc.get("max_chars", 90000))
        max_msgs = int(cc.get("max_messages", 46))
        msgs = list(self.messages)
        summary_msg = []
        if self.summary:
            summary_msg = [{"role": "system",
                            "content": "КРАТКАЯ ИСТОРИЯ ЭТОЙ СЕССИИ (сжато, чтобы экономить токены):\n" + self.summary}]
        # обрезаем по количеству
        # FIX: раньше одни и те же выброшенные сообщения поглощались в summary на КАЖДОМ
        # ходе (self.messages не укорачивался) — резюме росло дублями и вытесняло живую историю.
        if len(self.messages) > max_msgs:
            cut = len(self.messages) - max_msgs
            if cut > self._absorbed_upto:
                self._absorb(self.messages[self._absorbed_upto:cut], llm=None)
                self._absorbed_upto = cut
            msgs = list(self.messages)[cut:]
            summary_msg = [{"role": "system",
                            "content": "КРАТКАЯ ИСТОРИЯ ЭТОЙ СЕССИИ:\n" + self.summary}] if self.summary else summary_msg
        out = list(llm_messages_head) + summary_msg + msgs
        # обрезаем по символам (режем самые старые user/assistant, НЕ трогаем tool-пары в конце)
        total = sum(len(_content_text(m)) for m in out)
        head_n = len(llm_messages_head)
        while total > max_chars and len(out) > head_n + 4:
            i = head_n
            m = out[i]
            txt = _content_text(m)
            if len(txt) > 1200:
                out[i] = dict(m)
                out[i]["content"] = truncate_middle(txt, 700) if isinstance(m.get("content"), str) else out[i]["content"]
                total = sum(len(_content_text(x)) for x in out)
                if total <= max_chars:
                    break
            # FIX: удаляем ЦЕЛУЮ группу — assistant с tool_calls и все его tool-ответы.
            # Раньше мог остаться «сиротский» tool без своего assistant -> API отдавало
            # 400 "tool message must follow assistant with tool_calls".
            out.pop(i)
            if m.get("role") == "assistant" and m.get("tool_calls"):
                while i < len(out) and out[i].get("role") == "tool":
                    out.pop(i)
            total = sum(len(_content_text(x)) for x in out)
        return out

    def _absorb(self, dropped: list[dict], llm=None):
        """Сжимает удалённые сообщения в summary (без вызова LLM — дёшево и быстро)."""
        keep = []
        for m in dropped:
            role = m.get("role")
            txt = _content_text(m)
            if not txt:
                continue
            if role == "user":
                keep.append("Ю: " + txt[:260])
            elif role == "assistant":
                keep.append("Ф: " + txt[:260])
            elif role == "tool":
                keep.append(f"[tool {m.get('name','?')}]: " + txt[:160])
        chunk = "\n".join(keep[-60:])
        self.summary = ((self.summary + "\n" if self.summary else "") + chunk)[-6000:]

    def compress_with_llm(self, llm: "LLM"):
        """Умное сжатие истории моделью (по команде /compact)."""
        if len(self.messages) < 8:
            return {"ok": False, "reason": "история короткая, сжимать нечего"}
        keep_last = int((CFG.get("context") or {}).get("summary_keep_last", 12))
        old, new = self.messages[:-keep_last], self.messages[-keep_last:]
        text = "\n".join(f"{m.get('role')}: {_content_text(m)[:500]}" for m in old)
        try:
            r = llm.chat([{"role": "system", "content": "Ты сжимаешь историю диалога ассистента Flux в короткое резюме на русском. Сохрани: задачи пользователя, важные факты, пути к файлам, принятые решения, незавершённые дела. Максимум 900 символов, списком."},
                          {"role": "user", "content": text[:24000]}], stream=False, max_tokens=900)
            summ = (r.get("content") or "").strip()
            if summ:
                self.summary = (self.summary + "\n" if self.summary else "") + summ
                self.messages = new
                self._absorbed_upto = 0
                self.save()
                return {"ok": True, "dropped": len(old), "summary_chars": len(summ)}
        except Exception as e:
            return {"ok": False, "error": str(e)}
        return {"ok": False, "error": "пустой ответ"}


def _content_text(m: dict) -> str:
    c = m.get("content")
    if isinstance(c, str):
        return c
    if isinstance(c, list):
        parts = []
        for it in c:
            if isinstance(it, dict):
                if it.get("type") == "text":
                    parts.append(str(it.get("text") or ""))
                elif it.get("type") == "image_url":
                    parts.append("[изображение]")
            else:
                parts.append(str(it))
        return "\n".join(parts)
    return str(c or "")


# ============================================================================
#  ДОПОЛНИТЕЛЬНЫЕ ИНСТРУМЕНТЫ (ask_user, flux_config, send_to_panel)
# ============================================================================
@TS.tool("ask_user", "Задать вопрос пользователю и дождаться ответа (когда не хватает данных для продолжения: какой путь, подтверждение выбора, уточнение задачи). Вопрос показывается на экране и озвучивается.",
         TS.OBJ({"question": TS.STR("Вопрос пользователю (коротко, по-русски)"),
                 "options": TS.ARR(TS.STR("Вариант ответа"), "Варианты выбора (необязательно)"),
                 "speak": TS.BOOL("Озвучить вопрос (по умолчанию true)")}, ["question"]))
def t_ask_user(args):
    q = str(args.get("question") or "")
    opts = args.get("options") or []
    prompt = f"\n{C.YELLOW}❓ {CFG.get('assistant_name','Флюкс')} спрашивает:{C.RESET} {q}\n"
    if opts:
        for i, o in enumerate(opts, 1):
            prompt += f"   {i}) {o}\n"
        prompt += "   (номер или свой ответ) > "
    else:
        prompt += "   > "
    if args.get("speak", True):
        say(q, priority=True)
    ans = PROMPTS.ask(prompt, timeout=600, default="(пользователь не ответил)")
    if opts and ans.strip().isdigit():
        i = int(ans.strip()) - 1
        if 0 <= i < len(opts):
            ans = opts[i]
    return {"ok": True, "question": q, "answer": ans or "(пусто)"}


@TS.tool("flux_config", "Изменить/посмотреть настройки самого Флюкса: голос, озвучка, модель, проактивность, пороги, SearXNG, имя. Пример: flux_config set voice_output false.",
         TS.OBJ({"action": {"type": "string", "enum": ["get", "set", "list", "model", "reset"], "description": "Действие"},
                 "key": TS.STR("Ключ настройки (voice_output, model, proactive, wake_words, searxng_url, temperature...)"),
                 "value": TS.STR("Новое значение (json-совместимое: true/false/число/строка/список через запятую)")}, []))
def t_flux_config(args):
    act = args.get("action") or "list"
    if act == "list":
        d = dict(CFG.data)
        d["api_key"] = ("*" * 8 + str(d.get("api_key"))[-4:]) if d.get("api_key") else "(не задан)"
        return {"ok": True, "config": d, "config_file": str(CFG.path)}
    if act == "get":
        k = str(args.get("key") or "")
        return {"ok": True, "key": k, "value": CFG.get(k)}
    if act == "set":
        k, v = str(args.get("key") or ""), args.get("value")
        if not k:
            return {"ok": False, "error": "нужен key"}
        if isinstance(v, str):
            lv = v.strip().lower()
            if lv in ("true", "false"):
                v = (lv == "true")
            elif re.fullmatch(r"-?\d+", lv):
                v = int(lv)
            elif re.fullmatch(r"-?\d+\.\d+", lv):
                v = float(lv)
            elif "," in v:
                v = [x.strip() for x in v.split(",") if x.strip()]
        CFG.set(k, v)
        apply_live_config(k, v)
        return {"ok": True, "key": k, "new_value": v, "saved": str(CFG.path)}
    if act == "providers":
        llm = APP.llm if APP else None
        if not llm:
            return {"ok": False, "error": "Flux ещё не запущен"}
        return {"ok": True, "active": llm.provider, "model": llm.model,
                "free_mode": bool(CFG.get("prefer_free_models")),
                "providers": llm.providers_status(),
                "hint": "смена: flux_config set provider qwen_web (или /provider qwen_web)"}
    if act == "keys":
        sub = str(args.get("key") or "list")
        pool = APP.llm.key_pool() if APP else []
        if sub == "list":
            return {"ok": True, "active_index": (APP.llm._key_idx if APP else 0),
                    "keys": [f"{k[:7]}...{k[-4:]}" for k in pool],
                    "source": key_source(),
                    "qwen_token_set": bool(QW.get_qwen_token()),
                    "hint": "add/remove/active: flux_config keys key=add value=sk-..."}
        if not APP:
            return {"ok": False, "error": "Flux ещё не запущен"}
        ks = [str(x) for x in (CFG.get("api_keys") or [])]
        if sub == "add":
            from core import sanitize_key
            k = sanitize_key(str(args.get("value") or ""))
            if len(k) < 8:
                return {"ok": False, "error": "похоже, это не ключ"}
            if k not in ks:
                ks.append(k)
            CFG.set("api_keys", ks)
            return {"ok": True, "keys_total": len(APP.llm.key_pool())}
        if sub == "remove":
            i = int(args.get("value") or -1)
            if 0 <= i < len(ks):
                ks.pop(i)
                CFG.set("api_keys", ks)
            return {"ok": True, "keys": [f"{k[:7]}...{k[-4:]}" for k in APP.llm.key_pool()]}
        if sub == "active":
            i = int(args.get("value") or 0)
            pool2 = APP.llm.key_pool()
            if 0 <= i < len(pool2):
                APP.llm._key_idx = i
                APP.llm.api_key = pool2[i]
            return {"ok": True, "active": APP.llm._key_idx}
        return {"ok": False, "error": "keys: list/add/remove/active"}
    if act == "qwen_token":
        v = str(args.get("value") or "").strip()
        if not v:
            return {"ok": True, "qwen_token_set": bool(QW.get_qwen_token()),
                    "file": str(QW.TOKEN_FILE),
                    "howto": "F12 на https://chat.qwen.ai -> Console -> вставить tools/token_snippet.js "
                             "-> токен в буфере -> вставь сюда или в файл qwen_web.key"}
        from core.qwen_web import save_qwen_token
        p = save_qwen_token(v)
        QW._CLIENT["v"] = None
        return {"ok": True, "saved": str(p), "provider_hint": "/provider qwen_web"}
    if act == "model":
        models = APP.llm.list_models()
        free = [m for m in models if m.get("tier") == "free"]
        return {"ok": True, "current": APP.llm.model, "total_models": len(models),
                "free_models": [m["id"] for m in free][:60],
                "hint": "переключение: flux_config set model <id>"}
    if act == "reset":
        shutil.copy(str(CFG.path), str(CFG.path) + ".bak")
        from core import DEFAULT_CONFIG
        key_mem = get_api_key()          # FIX: ключ остаётся в памяти/secret.key,
        CFG.data = dict(DEFAULT_CONFIG)  # а не дублируется открытым текстом в config.json
        CFG.save()
        CFG.data["api_key"] = key_mem
        return {"ok": True, "message": "настройки сброшены (старые в config.json.bak), ключ не пострадал"}
    return {"ok": False, "error": f"неизвестное действие {act}"}


def apply_live_config(key: str, value):
    try:
        if key in ("voice_output", "tts_engine", "tts_rate", "tts_voice"):
            sp = get_speaker()
            if key == "voice_output":
                sp.set_enabled(bool(value))
            else:
                sp._init_engine()
        if key == "model":
            APP.llm.model = str(value)
            APP.llm.used_models.clear()
        if key == "proactive_interval_sec" and TB.WATCHDOG:
            TB.WATCHDOG.interval = int(value)
        if key == "assistant_name":
            APP.name = str(value)
    except Exception as e:
        log.warning("apply_live_config %s: %s", key, e)


@TS.tool("send_to_panel", "Отправить сообщение/статус в веб-панель Flux (http://127.0.0.1:8787) — видно в браузере, полезно для длинных отчётов и фоновых задач.",
         TS.OBJ({"text": TS.STR("Текст сообщения (поддерживается markdown)"),
                 "kind": {"type": "string", "enum": ["info", "warn", "report", "progress"], "description": "Тип"}}, ["text"]))
def t_send_to_panel(args):
    n = PANEL.push(str(args.get("text") or ""), str(args.get("kind") or "info"))
    return {"ok": True, "panel_messages": n, "url": PANEL.url()}


@TS.tool("flux_self", "Служебные действия самого Флюкса: версия, статистика (токены/вызовы/время работы), перезапуск в фоне, автозагрузка с Windows, создание ярлыка, отчёт о себе, обновление.",
         TS.OBJ({"action": {"type": "string", "enum": ["status", "restart_background", "autostart_on",
                                                       "autostart_off", "create_shortcut", "self_report",
                                                       "open_data_folder", "logs"], "description": "Действие"}}, []))
def t_flux_self(args):
    act = args.get("action") or "status"
    if act == "status":
        app = get_app()
        llm = app.llm if app else None
        sess = app.session if app else None
        return {"ok": True, "version": VERSION, "python": sys.version.split()[0],
                "uptime_min": round((time.time() - START_TIME) / 60, 1),
                "model": (llm.model if llm else CFG.get("model")),
                "llm_calls": (llm.total_calls if llm else 0),
                "tokens": (llm.total_tokens if llm else {"prompt": 0, "completion": 0}),
                "tools_count": len(TOOLS), "session_turns": (sess.turns if sess else 0),
                "session_file": (str(sess.path) if sess else ""),
                "searxng": {"url": TW.searxng_base(), "alive": TW.searxng_alive(1.0)},
                "panel": ((_a.panel.url() if (_a := get_app()) and _a.panel else "off")),
                "voice_input": (app.voice.ready if app and app.voice else False),
                "voice_output": get_speaker().engine_name,
                "watchdog": bool(TB.WATCHDOG and TB.WATCHDOG.is_alive()),
                "install_dir": str(ROOT), "admin": is_admin()}
    if act == "logs":
        try:
            txt = (LOG_DIR / "flux.log").read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True, "log_tail": clip(txt[-6000:], 6000)}
    if act == "restart_background":
        APP.spawn_background()
        return {"ok": True, "message": "запущен фоновый экземпляр Flux (flux_background.vbs)"}
    if act in ("autostart_on", "autostart_off"):
        return _autostart(act == "autostart_on")
    if act == "create_shortcut":
        return _create_shortcut()
    if act == "open_data_folder":
        open_path(str(DATA))
        return {"ok": True, "opened": str(DATA)}
    if act == "self_report":
        app = get_app()
        model = app.llm.model if app else CFG.get("model")
        base = app.llm.base if app else CFG.get("base_url")
        turns = app.session.turns if app else 0
        calls = app.llm.total_calls if app else 0
        toks = app.llm.total_tokens if app else {"prompt": 0, "completion": 0}
        tools_list = ", ".join(sorted(TOOLS))
        return {"ok": True, "report": f"""FLUX v{VERSION} — автономный ИИ-агент для Windows.
Модель: {model} через {base}
Инструментов: {len(TOOLS)} — {tools_list}
Веб-поиск: SearXNG (Docker) {TW.searxng_base()} [alive={TW.searxng_alive(1.0)}] + резерв DDG/Bing/Wikipedia
Голос: ввод={(app.voice.ready if app and app.voice else False)}, вывод={get_speaker().engine_name}
Память: {MEMORY_DIR}, сессии: {SESSIONS_DIR}
Планировщик напоминаний: {'работает' if TT.SCHEDULER and TT.SCHEDULER.is_alive() else 'выкл'}
Проактивный сторож: {'работает' if TB.WATCHDOG and TB.WATCHDOG.is_alive() else 'выкл'}
Панель управления: {PANEL.url() if PANEL else 'выкл'}
Ходов в сессии: {turns}
Статистика: {calls} запросов к LLM, токены {toks}"""}
    return {"ok": False, "error": f"неизвестное действие {act}"}


def _autostart(on: bool) -> dict:
    if not IS_WIN:
        return {"ok": False, "error": "только Windows"}
    vbs = ROOT / "flux_background.vbs"
    key = r"HKCU\Software\Microsoft\Windows\CurrentVersion\Run"
    if on:
        cmd = f'reg add "{key}" /v FluxAI /t REG_SZ /d "wscript.exe \\"{vbs}\\"" /f'
        r = cmd_run(cmd, timeout=30)
        return {"ok": r.get("code") == 0, "action": "autostart enabled",
                "detail": clip((r.get("stdout") or r.get("stderr")), 300)}
    r = cmd_run(f'reg delete "{key}" /v FluxAI /f', timeout=30)
    return {"ok": r.get("code") in (0, 1), "action": "autostart disabled"}


def _create_shortcut() -> dict:
    if not IS_WIN:
        return {"ok": False, "error": "только Windows"}
    desktop = Path(os.path.join(os.environ.get("USERPROFILE", ""), "Desktop"))
    lnk = desktop / "FLUX Ассистент.lnk"
    ps = f"""
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut('{lnk}')
$sc.TargetPath = 'cmd.exe'
$sc.Arguments = '/k \"\"{ROOT}\\run.bat\"\"'
$sc.WorkingDirectory = '{ROOT}'
$sc.Description = 'FLUX AI assistant'
$sc.IconLocation = 'shell32.dll,13'
$sc.Save(); 'ok'
"""
    r = powershell(ps, timeout=30)
    return {"ok": r.get("code") == 0, "shortcut": str(lnk)}


def get_app() -> "FluxApp | None":
    return APP


class PromptBroker:
    """Все вопросы пользователю (подтверждения опасных действий, ask_user) идут через
    ГЛАВНЫЙ поток, который владеет stdin. Иначе несколько input() из разных потоков
    ломают консоль. В фоновых режимах (нет REPL) возвращается безопасный ответ по умолчанию."""

    def __init__(self):
        self.pending: "queue.Queue[tuple[str, queue.Queue]]" = queue.Queue()
        self.interactive = False
        self.default = "н"
        self._local = threading.local()   # v2.0.6.1: источник запроса в текущем потоке

    def set_source(self, source: str):
        self._local.source = source

    def ask(self, prompt: str, timeout: float = 600.0, default: str = "н") -> str:
        src = getattr(self._local, "source", None)
        # v2.0.6.1: даже в фоновом режиме вопросы из панели/GUI работают —
        # там есть свои диалоги ответов (панель: /api/prompt, GUI: _poll_prompts)
        if not self.interactive and src not in ("panel", "gui"):
            return default
        # FIX: если спрашивает ГЛАВНЫЙ поток (он же владеет stdin и REPL ещё не
        # запущен либо заблокирован внутри handle_text) — читаем stdin напрямую.
        # Было: главный поток вставал в очередь и ждал сам себя -> гарантированный
        # дедлок на весь timeout (10 мин на каждое подтверждение опасного действия,
        # 15 мин при первом вводе API-ключа).
        if threading.current_thread() is threading.main_thread() and self.interactive:
            try:
                sys.stdout.write(f"\n{C.YELLOW}{prompt.rstrip()} {C.RESET}")
                sys.stdout.flush()
                line = sys.stdin.readline()
                ans = line.rstrip("\n") if line else ""
                return ans if ans != "" else default
            except Exception:
                return default
        aq: "queue.Queue[str]" = queue.Queue()
        self.pending.put((prompt, aq))
        try:
            return aq.get(timeout=timeout)
        except queue.Empty:
            return default

    def poll(self) -> bool:
        """Вызывается из REPL. Возвращает True, если был обработан запрос."""
        try:
            prompt, aq = self.pending.get_nowait()
        except queue.Empty:
            return False
        try:
            sys.stdout.write(f"\n{C.YELLOW}{prompt.rstrip()} {C.RESET}")
            sys.stdout.flush()
            line = sys.stdin.readline()
            ans = line.rstrip("\n") if line else ""
        except Exception:
            ans = ""
        aq.put(ans if ans != "" else self.default)
        return True


PROMPTS = PromptBroker()


# ============================================================================
#  ГОЛОСОВОЙ ВВОД (wake word)
# ============================================================================
class SdListener:
    """Микрофон через sounddevice — РАБОТАЕТ БЕЗ PyAudio.
    Пишет PCM 16 кГц моно, сам детектирует начало речи по энергии
    и конец фразы по паузе (VAD). Возвращает сырые байты для sr.AudioData."""

    SKIP_DEV = ("voicemod", "sound mapper", "первичный", "primary sound", "virtual",
                "cable", "loopback", "стерео микшер", "stereo mix", "what u hear",
                "монитор", "monitor")
    PREFER_DEV = ("mchose", "mic", "микро", "realtek", "usb", "hyper", "logitech",
                  "razer", "steel", "focusrite", "audio", "аудио")

    def __init__(self, rate: int = 16000):
        import sounddevice as sd  # type: ignore
        import numpy as np  # type: ignore
        self.sd = sd
        self.np = np
        self.rate = rate
        devs = sd.query_devices()
        ins = [(i, d) for i, d in enumerate(devs) if d.get("max_input_channels", 0) > 0]
        if not ins:
            raise RuntimeError("нет устройств записи (микрофонов)")
        self.devices = [d for _i, d in ins]
        self.device_index = self._pick(ins)
        self.last_peak = 0.0
        self.last_thr = 0.0

    def _pick(self, ins: list) -> int | None:
        """Реальный микрофон вместо виртуальных (Voicemod и т.п.).
        Приоритет: config['mic_device'] (подстрока имени) -> не-виртуальный с 'mic'
        -> любой не-виртуальный -> системный по умолчанию."""
        want = str(CFG.get("mic_device") or "").strip().lower()
        if want:
            for i, d in ins:
                if want in str(d.get("name", "")).lower():
                    return i
        for i, d in ins:
            n = str(d.get("name", "")).lower()
            if any(k in n for k in self.SKIP_DEV):
                continue
            if any(k in n for k in self.PREFER_DEV):
                return i
        for i, d in ins:
            n = str(d.get("name", "")).lower()
            if not any(k in n for k in self.SKIP_DEV):
                return i
        return None

    def device_names(self) -> list:
        return [d.get("name", "?") for d in self.devices]

    def chosen_name(self) -> str:
        if self.device_index is None:
            try:
                return str(self.sd.query_devices(kind="input").get("name", "по умолчанию"))
            except Exception:
                return "по умолчанию"
        try:
            return str(self.sd.query_devices(self.device_index).get("name", "?"))
        except Exception:
            return "?"

    @staticmethod
    def _rms(np, data: bytes) -> float:
        x = np.frombuffer(data, dtype=np.int16).astype(np.float32)
        if x.size == 0:
            return 0.0
        return float(np.sqrt(np.mean(x * x)))

    def listen(self, timeout: float | None = None, phrase_limit: float = 12.0,
               pause_sec: float = 0.8, min_len: float = 0.35,
               calibrate: float = 0.45) -> bytes:
        """Ждёт речь (timeout сек), пишет до паузы pause_sec или phrase_limit.
        Бросает TimeoutError, если тишина."""
        sd, np = self.sd, self.np
        block = int(self.rate * 0.05)          # 50 мс
        stream = sd.RawInputStream(samplerate=self.rate, channels=1, dtype="int16",
                                   blocksize=block, device=self.device_index)
        frames: list[bytes] = []
        try:
            stream.start()
            amb: list[float] = []
            t0 = time.time()
            while time.time() - t0 < calibrate:
                data, _of = stream.read(block)
                amb.append(self._rms(np, bytes(data)))
            amb.sort()
            median = amb[len(amb) // 2] if amb else 100.0
            thr = max(median * 1.6, 150.0)
            self.last_thr = thr
            self.last_peak = 0.0
            deadline = None if timeout is None else time.time() + timeout
            state = "wait"
            silent = 0.0
            t_start = 0.0
            while True:
                if state == "wait" and deadline is not None and time.time() > deadline:
                    raise TimeoutError(f"silence (пик={self.last_peak:.0f}, порог={self.last_thr:.0f})")
                data, _of = stream.read(block)
                b = bytes(data)
                e = self._rms(np, b)
                if e > self.last_peak:
                    self.last_peak = e
                if state == "wait":
                    if e > thr:
                        state = "rec"
                        frames = [b]
                        t_start = time.time()
                        silent = 0.0
                else:
                    frames.append(b)
                    if e < thr * 0.55:
                        silent += 0.05
                    else:
                        silent = 0.0
                    if time.time() - t_start > phrase_limit:
                        break
                    if silent >= pause_sec and (time.time() - t_start) > min_len:
                        break
        finally:
            try:
                stream.stop()
                stream.close()
            except Exception:
                pass
        if not frames:
            raise TimeoutError("silence")
        return b"".join(frames)


class VoiceInput:
    """Слушает микрофон, реагирует только если фраза начинается с wake word."""

    def __init__(self, app):
        self.app = app
        self.ready = False
        self.reason = ""
        self.thread: threading.Thread | None = None
        self.q: "queue.Queue[str]" = queue.Queue()
        self.stop_flag = threading.Event()
        self.sr = None
        self.rec = None
        self.mic = None
        self.enabled = bool(CFG.get("voice_input", True))
        self.stats = {"heard": 0, "wake_hits": 0, "errors": 0}
        self.followup = False
        self.last_answer_ts = 0.0
        if self.enabled:
            self._init()

    # ---------------- init
    def _init(self):
        self.backend = None
        self.sd_listener = None
        try:
            import speech_recognition as sr  # type: ignore
            self.sr = sr
            self.rec = sr.Recognizer()
            self.rec.energy_threshold = 320
            self.rec.dynamic_energy_threshold = True
            self.rec.pause_threshold = 0.75
            try:
                self.rec.non_speaking_duration = 0.45
            except Exception:
                pass
        except Exception as e:
            self.ready = False
            self.reason = f"SpeechRecognition не установлен: {e} -> запусти fix_voice.bat"
            log.info("voice input off: %s", self.reason)
            return
        # бэкенд 1: PyAudio (классический Microphone)
        try:
            self.mic = sr.Microphone()
            with self.mic as src:
                self.rec.adjust_for_ambient_noise(src, duration=0.6)
            self.backend = "pyaudio"
            self.ready = True
            self.reason = "ok (PyAudio)"
            return
        except Exception as e:
            log.info("PyAudio-микрофон недоступен: %s", e)
        # бэкенд 2: sounddevice (не требует PyAudio)
        try:
            self.sd_listener = SdListener()
            self.backend = "sounddevice"
            self.ready = True
            self.reason = f"ok (sounddevice: {self.sd_listener.chosen_name()})"
            log.info("voice input via sounddevice: %s", self.sd_listener.device_names()[:3])
            return
        except Exception as e2:
            self.sd_listener = None
        self.ready = False
        msg = str(e2)
        if "No module named 'sounddevice'" in msg:
            self.reason = ("нет ни PyAudio, ни sounddevice -> запусти fix_voice.bat "
                           "(он поставит sounddevice — микрофон заработает без PyAudio)")
        elif "устройств записи" in msg or "микрофон" in msg.lower():
            self.reason = "микрофон не найден (Параметры -> Система -> Звук -> Ввод)"
        else:
            self.reason = f"микрофон недоступен: {msg[:160]}"
        log.info("voice input off: %s", self.reason)

    def start(self):
        if not self.ready:
            return False
        if self.thread and self.thread.is_alive():
            return True
        self.stop_flag.clear()
        self.thread = threading.Thread(target=self._loop, daemon=True, name="flux-voice")
        self.thread.start()
        return True

    def stop(self):
        self.stop_flag.set()

    # ---------------- wake word
    def wake_words(self) -> list[str]:
        ws = [str(w).lower().strip() for w in (CFG.get("wake_words") or []) if str(w).strip()]
        return ws or ["флюкс", "flux"]

    @staticmethod
    def _normalize(text: str) -> str:
        t = str(text).lower().replace("ё", "е")
        t = re.sub(r"[^a-zа-я0-9\s-]", " ", t)
        return re.sub(r"\s+", " ", t).strip()

    def match_wake(self, text: str) -> tuple[bool, str]:
        n = self._normalize(text)
        if not n:
            return False, ""
        words = n.split()
        # wake word должен стоять В НАЧАЛЕ фразы (допускаем 1 слово-паразит перед ним: "Эй, Флюкс ...")
        for i, w in enumerate(words[:2]):
            w2 = w.strip("-")
            for ww in self.wake_words():
                if w2 == ww or (len(ww) >= 4 and self._fuzzy(w2, ww)):
                    rest = " ".join(words[i + 1:]).strip(" ,.:!?-")
                    return True, rest
        return False, n

    @staticmethod
    def _fuzzy(a: str, b: str) -> bool:
        """Нечёткое сравнение (1-2 опечатки/ошибки распознавания)."""
        if a == b:
            return True
        if abs(len(a) - len(b)) > 2:
            return False
        if len(a) < 4:
            return False
        # расстояние Дамерау-Левенштейна (упрощённое)
        prev2 = None
        prev = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            cur = [i]
            for j, cb in enumerate(b, 1):
                cost = 0 if ca == cb else 1
                v = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                if i > 1 and j > 1 and ca == b[j - 2] and a[i - 2] == cb:
                    v = min(v, prev2[j - 2] + 1)
                cur.append(v)
            prev2, prev = prev, cur
        return prev[-1] <= 2

    # ---------------- основной цикл
    def _listen_audio(self):
        """Возвращает sr.AudioData или None (таймаут тишины)."""
        if self.backend == "sounddevice":
            if self.followup and (time.time() - self.last_answer_ts) < float(CFG.get("followup_timeout", 7)):
                to = 2.5
            else:
                self.followup = False
                to = None
            try:
                pcm = self.sd_listener.listen(timeout=to,
                                              phrase_limit=int(CFG.get("listen_timeout", 9)) + 4)
            except TimeoutError:
                return None
            return self.sr.AudioData(pcm, self.sd_listener.rate, 2)
        with self.mic as src:
            if self.followup and (time.time() - self.last_answer_ts) < float(CFG.get("followup_timeout", 7)):
                return self.rec.listen(src, timeout=2.5,
                                       phrase_time_limit=int(CFG.get("listen_timeout", 9)))
            self.followup = False
            return self.rec.listen(src, timeout=None,
                                   phrase_time_limit=int(CFG.get("listen_timeout", 9)) + 4)

    def _loop(self):
        assert self.sr and self.rec
        assert self.mic is not None or self.sd_listener is not None
        while not self.stop_flag.is_set():
            try:
                audio = self._listen_audio()
                if audio is None:
                    continue
            except Exception:
                time.sleep(0.25)
                continue
            try:
                text = self.rec.recognize_google(audio, language="ru-RU")
            except self.sr.UnknownValueError:
                continue
            except self.sr.RequestError as e:
                self.stats["errors"] += 1
                log.warning("recognizer network: %s", e)
                time.sleep(3)
                continue
            except Exception as e:
                self.stats["errors"] += 1
                log.warning("recognize: %s", e)
                continue
            if not text or not text.strip():
                continue
            self.stats["heard"] += 1
            wake, rest = self.match_wake(text)
            dlog(f"[voice] услышано: {text!r} -> wake={wake} rest={rest!r}")
            if wake and rest:
                self.stats["wake_hits"] += 1
                self.followup = False
                beep(1320, 90)
                self.q.put(rest)
                print(f"{C.MAG}🎙  (голос) {rest}{C.RESET}")
            elif wake and not rest:
                beep(1046, 110)
                say("Слушаю", priority=True)
                self.followup = True
                self.last_answer_ts = time.time()
            elif self.followup:
                # режим продолжения диалога после ответа Флюкса
                self.q.put(text)
                print(f"{C.MAG}🎙  (голос, продолжение) {text}{C.RESET}")
                self.followup = False
            else:
                # без wake word — игнорируем, но логируем
                dlog(f"[voice] проигнорировано (нет wake word): {text[:80]}")

    def arm_followup(self):
        if CFG.get("auto_listen_after_answer", True):
            self.followup = True
            self.last_answer_ts = time.time()

    def listen_once(self, timeout: float = 10.0) -> str:
        """Push-to-talk: одна фраза без wake word."""
        if not self.ready:
            return ""
        try:
            print(f"{C.MAG}  🎙 говори...{C.RESET}", end=" ", flush=True)
            if self.backend == "sounddevice":
                pcm = self.sd_listener.listen(timeout=timeout, phrase_limit=timeout,
                                              pause_sec=0.7, calibrate=0.3)
                audio = self.sr.AudioData(pcm, self.sd_listener.rate, 2)
            else:
                with self.mic as src:
                    audio = self.rec.listen(src, timeout=timeout, phrase_time_limit=timeout)
            txt = self.rec.recognize_google(audio, language="ru-RU")
            print(f"\r{C.MAG}  🎙 {txt}{C.RESET}")
            return txt
        except Exception as e:
            print(f"\r{C.RED}  микрофон: {e}{C.RESET}")
            return ""


# ============================================================================
#  ГОРЯЧАЯ КЛАВИША (push-to-talk)
# ============================================================================
class Hotkey:
    def __init__(self, app):
        self.app = app
        self.ready = False
        self.stop_flag = threading.Event()
        self.thread = None
        self.combo = "+".join([str(x).lower() for x in (CFG.get("hotkey_modifiers") or ["ctrl", "alt"])] +
                              [str(CFG.get("hotkey_key", "F")).lower()])
        if CFG.get("push_to_talk_hotkey", True):
            self._init()

    def _init(self):
        try:
            import keyboard  # type: ignore
            self.kb = keyboard
            keyboard.add_hotkey(self.combo, self._on_hotkey, suppress=False)
            self.ready = True
        except Exception as e:
            self.ready = False
            dlog(f"[hotkey] недоступен: {e}")

    def _on_hotkey(self):
        try:
            beep(1500, 70)
            txt = self.app.voice.listen_once(10) if self.app.voice and self.app.voice.ready else ""
            if txt:
                wake, rest = (self.app.voice.match_wake(txt) if self.app.voice else (False, txt))
                # FIX: input_q не читался ни в одном цикле — push-to-talk молча терял фразы.
                # Шлём в ту же очередь, что и wake word (её разбирают REPL и фоновый режим).
                self.app.voice.q.put(rest or txt)
        except Exception as e:
            log.warning("hotkey: %s", e)

    def start(self):
        return self.ready

    def stop(self):
        try:
            if self.ready:
                self.kb.unhook_all_hotkeys()
        except Exception:
            pass


# ============================================================================
#  ПАНЕЛЬ УПРАВЛЕНИЯ (http://127.0.0.1:8787)
# ============================================================================
PANEL_HTML = """<!doctype html><html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>FLUX :: панель</title>
<style>
:root{--bg:#0b1118;--p:#111a24;--fg:#e6edf3;--ac:#22d3ee;--wa:#fbbf24;--er:#f87171;--ok:#4ade80;--dim:#7f96ab;--bd:#1d2b38}
:root[data-theme="cyan"]{--bg:#07131a;--p:#0d1e28;--ac:#22d3ee;--bd:#14384a;--dim:#6f93a8}
:root[data-theme="matrix"]{--bg:#050d05;--p:#0a170a;--ac:#4ade80;--bd:#14401c;--dim:#5f8f66;--ok:#86efac}
:root[data-theme="synth"]{--bg:#140a1e;--p:#1d0f2c;--ac:#e879f9;--bd:#4a1d6e;--dim:#9a7fb0;--ok:#67e8f9}
:root[data-theme="amber"]{--bg:#140e05;--p:#201607;--ac:#fbbf24;--bd:#4a3413;--dim:#a8905f;--ok:#fde047}
:root[data-theme="ice"]{--bg:#0a1020;--p:#101a33;--ac:#93c5fd;--bd:#24406e;--dim:#7f96c0;--ok:#a5f3fc}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.5 "Segoe UI",system-ui,sans-serif;overflow-x:hidden}
canvas#bg{position:fixed;inset:0;z-index:0;opacity:.5}
header{position:relative;z-index:2;padding:14px 20px;background:linear-gradient(90deg,color-mix(in srgb,var(--p) 88%,transparent),color-mix(in srgb,var(--bg) 80%,transparent));border-bottom:1px solid var(--bd);display:flex;gap:14px;align-items:center;flex-wrap:wrap;backdrop-filter:blur(4px)}
h1{font-size:18px;margin:0;color:var(--ac);letter-spacing:2px}
.pill{background:color-mix(in srgb,var(--p) 80%,transparent);border:1px solid var(--bd);padding:3px 10px;border-radius:999px;font-size:12px;color:var(--dim)}
main{position:relative;z-index:2;display:grid;grid-template-columns:1.15fr .85fr;gap:16px;padding:16px;max-width:1500px;margin:0 auto}
@media(max-width:980px){main{grid-template-columns:1fr}}
.card{background:color-mix(in srgb,var(--p) 92%,transparent);border:1px solid var(--bd);border-radius:12px;padding:14px;backdrop-filter:blur(3px)}
.card h2{font-size:13px;text-transform:uppercase;letter-spacing:1px;color:var(--dim);margin:0 0 10px}
#log{height:40vh;overflow:auto;background:color-mix(in srgb,var(--bg) 70%,black);border:1px solid var(--bd);border-radius:8px;padding:10px;font-family:Consolas,monospace;font-size:12.5px;white-space:pre-wrap}
.u{color:#8be9fd}.a{color:#c9f2c7}.s{color:var(--dim)}.w{color:var(--wa)}.e{color:var(--er)}
textarea,input,select{width:100%;background:color-mix(in srgb,var(--bg) 70%,black);color:var(--fg);border:1px solid var(--bd);border-radius:8px;padding:8px;font:13px Consolas,monospace}
textarea{min-height:60px;resize:vertical}
button{background:color-mix(in srgb,var(--ac) 18%,var(--p));color:var(--ac);border:1px solid color-mix(in srgb,var(--ac) 45%,var(--bd));border-radius:8px;padding:7px 14px;cursor:pointer;font-weight:600}
button:hover{background:color-mix(in srgb,var(--ac) 32%,var(--p))}
button.sel{background:var(--ac);color:var(--bg)}
table{width:100%;border-collapse:collapse;font-size:12.5px}td,th{padding:5px 6px;border-bottom:1px solid var(--bd);text-align:left}
.kv td:first-child{color:var(--dim);width:45%}
.row{display:flex;gap:8px;margin-top:8px;flex-wrap:wrap;align-items:center}
.lbl{color:var(--dim);font-size:12px;min-width:90px}
.krow{display:flex;gap:6px;align-items:center;font-size:12px;font-family:Consolas,monospace;border-bottom:1px dashed var(--bd);padding:4px 0}
.krow .act{color:var(--ok)}
.themesw{width:26px;height:26px;border-radius:6px;border:2px solid transparent;cursor:pointer;display:inline-block;margin-right:6px}
.themesw.on{border-color:var(--fg)}
#pmodal{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:60;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(2px)}
.mbox{background:var(--p);border:1px solid var(--ac);border-radius:12px;padding:18px;max-width:520px;width:92%;box-shadow:0 8px 40px rgba(0,0,0,.6)}
.mbox h3{margin:0 0 8px;color:var(--wa);font-size:14px;letter-spacing:.5px}
.mbox p{white-space:pre-wrap;font-size:13px;margin:0 0 12px}
</style></head><body>
<canvas id="bg"></canvas>
<header><h1>FLUX</h1><span class="pill">панель управления</span><span class="pill" id="st">подключение...</span>
<span class="pill" id="prov"></span><span class="pill" id="model"></span><span class="pill" id="up"></span></header>
<main>
 <div class="card"><h2>Чат / команды</h2>
  <div id="log"></div>
  <textarea id="msg" placeholder="Напиши задачу Флюксу (Enter — отправить, Shift+Enter — новая строка)"></textarea>
  <div class="row">
   <button onclick="send()">Отправить</button>
   <button onclick="quick('Сделай проверку системы: system_health full=true')">Проверка ПК</button>
   <button onclick="quick('Расписание')">Расписание</button>
   <button onclick="quick('Сделай скриншот и расскажи что на экране')">Скриншот</button>
   <button onclick="quick('/status')">Статус</button>
   <button onclick="quick('Выключи комп через 60 мин')">⏻ таймер выкл</button>
  </div>
 </div>
 <div>
  <div class="card"><h2>Модель и провайдер</h2>
   <div class="row"><span class="lbl">Провайдер</span><select id="provider" onchange="setProvider()"></select></div>
   <div class="row"><span class="lbl">Модель</span><select id="modelSel" onchange="setModel()"></select></div>
   <div class="row"><span class="lbl">Free-режим</span><input type="checkbox" id="freeMode" style="width:auto" onchange="setFree()" title="показывать и предпочитать бесплатные модели">
    <span class="lbl">Режим qwen</span><select id="think" style="width:auto" onchange="setThink()">
      <option value="auto">Auto</option><option value="thinking">Thinking</option><option value="fast">Fast</option></select></div>
   <div class="row" style="color:var(--dim);font-size:12px" id="provHint"></div>
  </div>
  <div class="card" style="margin-top:16px"><h2>API-ключи</h2>
   <div id="keys"></div>
   <div class="row"><input id="newkey" placeholder="sk-... (ключ xkiro)">
    <button onclick="addKey()">Добавить</button></div>
   <div class="row"><span class="lbl">Qwen-мост</span><span id="qwenst" style="font-size:12px"></span></div>
   <div class="row"><input id="qwentok" placeholder="eyJ... токен chat.qwen.ai (F12 → Console → token_snippet.js)">
    <button onclick="setQwen()">Сохранить</button>
    <button onclick="autoQwen()" title="достать свежий токен из localStorage браузера (Chrome/Edge/Firefox...)">🔄 авто-токен</button></div>
  </div>
  <div class="card" style="margin-top:16px"><h2>Оформление</h2>
   <div class="row"><span class="lbl">Тема</span><span id="themesw"></span></div>
   <div class="row"><span class="lbl">Фон</span><select id="bgSel" style="width:auto" onchange="setBg(this.value)">
     <option value="off">выкл</option><option value="matrix">матрица</option>
     <option value="stars">звёзды</option><option value="wave">плазма</option></select></div>
  </div>
  <div class="card" style="margin-top:16px"><h2>Система</h2><table class="kv" id="sys"></table></div>
  <div class="card" style="margin-top:16px"><h2>Напоминания и таймеры</h2><div id="rem"></div></div>
  <div class="card" style="margin-top:16px"><h2>Журнал Flux</h2><div id="ev" style="max-height:200px;overflow:auto;font-size:12px"></div></div>
 </div>
</main>
<script>
const T = new URLSearchParams(location.search).get('token') || '';
const H = {'Content-Type':'application/json','X-Flux-Token':T};
const L = document.getElementById('log');
const THEMES = {dark:{ac:'#22d3ee'},cyan:{ac:'#22d3ee'},matrix:{ac:'#4ade80'},synth:{ac:'#e879f9'},amber:{ac:'#fbbf24'},ice:{ac:'#93c5fd'}};
let CUR = {theme:'dark',bg:'off',provider:'xkiro'};
function add(cls,who,txt){const d=document.createElement('div');d.className=cls;d.textContent=who+': '+txt;L.appendChild(d);L.scrollTop=L.scrollHeight;}
async function api(p,opt){const r=await fetch(p,Object.assign({headers:H},opt||{}));return r.json();}
function quick(t){document.getElementById('msg').value=t;send();}
async function send(){const m=document.getElementById('msg');const t=m.value.trim();if(!t)return;m.value='';
 add('u','ты',t);add('s','flux','думаю...');const r=await api('/api/send',{method:'POST',body:JSON.stringify({text:t})});
 L.removeChild(L.lastChild);add(r.ok?'a':'e','flux',r.reply||r.error||'(пусто)');}
document.getElementById('msg').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send();}});
/* ---------- оформление ---------- */
function applyTheme(t){document.documentElement.setAttribute('data-theme',t);CUR.theme=t;renderSwatches();startBg(CUR.bg);}
function renderSwatches(){const box=document.getElementById('themesw');box.innerHTML='';
 for(const k of Object.keys(THEMES)){const s=document.createElement('span');s.className='themesw'+(k===CUR.theme?' on':'');
  s.style.background=(k==='dark'?'#111a24':getComputedStyle(document.documentElement).getPropertyValue('--ac'));
  s.style.background={'dark':'#16232f','cyan':'#0d394a','matrix':'#0a3a14','synth':'#4a1d6e','amber':'#4a3413','ice':'#24406e'}[k];
  s.title=k;s.onclick=()=>{api('/api/appearance',{method:'POST',body:JSON.stringify({theme:k,bg:CUR.bg})});applyTheme(k);};
  box.appendChild(s);}}
/* ---------- анимация фона ---------- */
let BGRAF=0;const cv=document.getElementById('bg'),cx=cv.getContext('2d');let drops=[],stars=[];
function sizeCv(){cv.width=innerWidth;cv.height=innerHeight;
 drops=Array.from({length:Math.floor(cv.width/14)},()=>({y:Math.random()*cv.height,s:1+Math.random()*2}));
 stars=Array.from({length:Math.floor(cv.width*cv.height/9000)},()=>({x:Math.random()*cv.width,y:Math.random()*cv.height,s:.2+Math.random()*.8,p:Math.random()*6.28}));}
addEventListener('resize',sizeCv);sizeCv();
function startBg(mode){CUR.bg=mode;document.getElementById('bgSel').value=mode;cancelAnimationFrame(BGRAF);
 cx.clearRect(0,0,cv.width,cv.height);if(mode!=='off')tickBg();}
function tickBg(){const ac=THEMES[CUR.theme]?THEMES[CUR.theme].ac:'#22d3ee';
 if(CUR.bg==='matrix'){cx.fillStyle='rgba(0,0,0,.12)';cx.fillRect(0,0,cv.width,cv.height);cx.fillStyle=ac;cx.font='13px monospace';
  drops.forEach((d,i)=>{const ch='ｱｲｳｦｶｷｸｹｺФЛЮКС01'[Math.floor(Math.random()*16)];cx.fillText(ch,i*14,d.y);d.y+=d.s*7;if(d.y>cv.height+50)d.y=0;});}
 else if(CUR.bg==='stars'){cx.clearRect(0,0,cv.width,cv.height);cx.fillStyle=ac;
  stars.forEach(s=>{s.y+=s.s*.4;s.x-=s.s*.2;if(s.y>cv.height)s.y=0;if(s.x<0)s.x=cv.width;
   const tw=.4+.6*Math.abs(Math.sin(performance.now()/700+s.p));cx.globalAlpha=tw;cx.fillRect(s.x,s.y,2,2);});cx.globalAlpha=1;}
 else if(CUR.bg==='wave'){cx.clearRect(0,0,cv.width,cv.height);cx.strokeStyle=ac;cx.globalAlpha=.5;
  for(let k=0;k<3;k++){cx.beginPath();for(let x=0;x<=cv.width;x+=8){const y=cv.height/2+Math.sin(x/90+performance.now()/900+k*2)*60*(k+1)/3;x?cx.lineTo(x,y):cx.moveTo(x,y);}cx.stroke();}cx.globalAlpha=1;}
 BGRAF=requestAnimationFrame(tickBg);}
/* ---------- провайдер/модели/ключи ---------- */
async function loadProvider(){const p=await api('/api/provider');CUR.provider=p.provider;
 const sel=document.getElementById('provider');sel.innerHTML='';
 (p.providers||[]).forEach(x=>{const o=document.createElement('option');o.value=x.id;
  o.textContent=x.id+(x.ready?'':' (не готов)')+((x.active)?' ▶':'');sel.appendChild(o);});
 sel.value=p.provider;
 document.getElementById('provHint').textContent=(p.providers||[]).filter(x=>x.active).map(x=>x.name+' — '+x.detail).join('');
 document.getElementById('think').value=p.thinking||'auto';
 document.getElementById('freeMode').checked=!!p.free_mode;
 loadModels();}
async function loadModels(){const m=await api('/api/models');const sel=document.getElementById('modelSel');sel.innerHTML='';
 (m.models||[]).forEach(x=>{const o=document.createElement('option');o.value=x.id;
  o.textContent=x.id+(x.search?' 🌐':'')+((x.tier==='free')?' 🆓':'')+(x.local?' 🏠':'');sel.appendChild(o);});
 sel.value=m.current||((m.models||[])[0]||{}).id||'';}
function setProvider(){api('/api/provider',{method:'POST',body:JSON.stringify({provider:document.getElementById('provider').value})}).then(loadProvider);}
function setModel(){api('/api/provider',{method:'POST',body:JSON.stringify({model:document.getElementById('modelSel').value})}).then(()=>refresh());}
function setFree(){api('/api/provider',{method:'POST',body:JSON.stringify({free_mode:document.getElementById('freeMode').checked})});}
function setThink(){api('/api/provider',{method:'POST',body:JSON.stringify({thinking:document.getElementById('think').value})});}
function setBg(v){api('/api/appearance',{method:'POST',body:JSON.stringify({theme:CUR.theme,bg:v})});startBg(v);}
async function loadKeys(){const k=await api('/api/keys');const box=document.getElementById('keys');box.innerHTML='';
 (k.keys||[]).forEach((key,i)=>{const d=document.createElement('div');d.className='krow';
  d.innerHTML='<span class="'+(i===k.active?'act':'')+'">'+(i===k.active?'▶ ':'  ')+'</span><span>'+key+'</span>';
  const b1=document.createElement('button');b1.textContent='актив';b1.style.padding='2px 8px';
  b1.onclick=()=>api('/api/keys',{method:'POST',body:JSON.stringify({active:i})}).then(loadKeys);
  const b2=document.createElement('button');b2.textContent='✕';b2.style.padding='2px 8px';
  b2.onclick=()=>api('/api/keys',{method:'POST',body:JSON.stringify({remove:i})}).then(loadKeys);
  d.appendChild(b1);d.appendChild(b2);box.appendChild(d);});
 if(!(k.keys||[]).length)box.innerHTML='<span style="color:var(--dim);font-size:12px">ключей xkiro нет</span>';
 document.getElementById('qwenst').textContent=k.qwen_token_set?'✅ токен chat.qwen.ai сохранён':'❌ токен не задан (мост не сможет работать)';}
function addKey(){const v=document.getElementById('newkey').value.trim();if(!v)return;
 api('/api/keys',{method:'POST',body:JSON.stringify({add:v})}).then(()=>{document.getElementById('newkey').value='';loadKeys();});}
function setQwen(){const v=document.getElementById('qwentok').value.trim();if(!v)return;
 api('/api/qwen_token',{method:'POST',body:JSON.stringify({token:v})}).then(()=>{document.getElementById('qwentok').value='';loadKeys();loadProvider();});}
async function autoQwen(){const b=event.target;b.disabled=true;b.textContent='🔄 ищу...';
 try{const r=await api('/api/qwen_auto',{method:'POST',body:JSON.stringify({})});
  add(r.updated?'a':'w','qwen-авто',r.updated?('токен обновлён: '+r.source+' → '+r.detail):('не вышло: '+r.reason));
 }catch(e){add('e','qwen-авто',String(e));}
 b.disabled=false;b.textContent='🔄 авто-токен';loadKeys();loadProvider();}
/* ---------- статус ---------- */
async function refresh(){try{const s=await api('/api/status');
 document.getElementById('st').textContent=s.alive?'онлайн':'офлайн';
 document.getElementById('model').textContent='модель: '+(s.model||'?');
 document.getElementById('prov').textContent='провайдер: '+(s.provider||'?');
 document.getElementById('up').textContent='аптайм: '+(s.uptime_min||0)+' мин';
 let h='';const kv=[['Версия',s.version],['Инструментов',s.tools],['Ходов в сессии',s.turns],['Токенов (в/и)',(s.tokens&&s.tokens.prompt||0)+' / '+(s.tokens&&s.tokens.completion||0)],
  ['LLM-запросов',s.llm_calls],['SearXNG',(s.searxng&&s.searxng.alive)?'работает':'не запущен'],['Голосовой ввод',s.voice_input?'да':'нет'],
  ['Озвучка',s.voice_output],['Сторож',s.watchdog?'активен':'выкл'],['Проблемы системы',(s.problems&&s.problems.length)?s.problems.join(' | '):'нет']];
 for(const[a,b]of kv){h+='<tr><td>'+a+'</td><td>'+(b===undefined||b===null?'-':b)+'</td></tr>';}
 document.getElementById('sys').innerHTML=h;
 const rr=await api('/api/reminders');let g='';
 for(const it of (rr.items||[])){g+='<div style="border-bottom:1px solid var(--bd);padding:5px 0">'+it+'</div>';}
 document.getElementById('rem').innerHTML=g||'<span style="color:var(--dim)">пусто</span>';
 const ev=await api('/api/events');let e2='';
 for(const it of (ev.events||[])){e2+='<div>'+it+'</div>';}
 document.getElementById('ev').innerHTML=e2||'<span style="color:var(--dim)">пусто</span>';
}catch(e){document.getElementById('st').textContent='нет связи';}}
async function loadAppearance(){const a=await api('/api/appearance');CUR.theme=a.theme||'dark';applyTheme(CUR.theme);startBg(a.bg||'off');}
/* ---------- диалог подтверждений / ask_user (v2.0.6.1) ---------- */
let PROMPT_BUSY=false;
function showPromptModal(p){
  PROMPT_BUSY=true;
  const wrap=document.createElement('div');wrap.id='pmodal';
  wrap.innerHTML='<div class="mbox"><h3>⚠ FLUX спрашивает</h3><p></p>'+
   '<textarea id="pans" placeholder="ответ (или д / н)"></textarea>'+
   '<div class="row"><button id="pyes">Да</button><button id="pno">Нет</button>'+
   '<button id="pok">Отправить текст</button></div></div>';
  document.body.appendChild(wrap);
  wrap.querySelector('p').textContent=p;
  const ans=()=>wrap.querySelector('#pans').value.trim();
  const done=(v)=>{api('/api/prompt_answer',{method:'POST',body:JSON.stringify({text:v})});
    wrap.remove();PROMPT_BUSY=false;};
  wrap.querySelector('#pyes').onclick=()=>done(ans()||'д');
  wrap.querySelector('#pno').onclick=()=>done('н');
  wrap.querySelector('#pok').onclick=()=>done(ans()||'н');
  wrap.querySelector('#pans').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();done(ans()||'н');}});
  wrap.querySelector('#pans').focus();
}
async function pollPrompt(){
  try{
    if(!PROMPT_BUSY){
      const r=await api('/api/prompt');
      if(r&&r.prompt)showPromptModal(r.prompt);
    }
  }catch(e){}
  setTimeout(pollPrompt,1200);
}
pollPrompt();
add('s','flux','панель подключена. пиши задачу — она уйдёт в живой Flux.');
loadAppearance();loadProvider();loadKeys();refresh();setInterval(refresh,5000);
</script></body></html>"""


class Panel(threading.Thread):
    def __init__(self, app):
        super().__init__(daemon=True, name="flux-panel")
        self.app = app
        self.messages: list[dict] = []
        self.httpd = None
        self.enabled = bool(CFG.get("control_panel", True))
        # FIX (безопасность): пустой/дефолтный токен заменяем случайным и сохраняем.
        # Раньше токен "flux-local-token" был опубликован в README, а CORS "*" разрешал
        # любому открытому в браузере сайту дёргать /api/send и /api/tool -> полный
        # контроль над ПК через агента.
        tok = str(CFG.get("panel_token") or "").strip()
        if (not tok or tok == "flux-local-token") and self.enabled:
            tok = "flux-" + rand_id(16)
            CFG.set("panel_token", tok)

    def url(self) -> str:
        if not self.enabled:
            return "выключена"
        return f"http://{CFG.get('panel_host','127.0.0.1')}:{CFG.get('panel_port',8787)}/?token={CFG.get('panel_token','')}"

    def push(self, text: str, kind: str = "info") -> int:
        self.messages.append({"t": human_time(), "kind": kind, "text": text[:4000]})
        self.messages = self.messages[-200:]
        return len(self.messages)

    def run(self):
        if not self.enabled:
            return
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        panel = self

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *a):
                pass

            def _auth(self) -> bool:
                tok = self.headers.get("X-Flux-Token") or ""
                if not tok:
                    q = urllib.parse.urlparse(self.path).query
                    tok = urllib.parse.parse_qs(q).get("token", [""])[0]
                return tok == str(CFG.get("panel_token", ""))

            def _send(self, code: int, body: bytes, ctype: str = "application/json; charset=utf-8"):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                # FIX: никакого Access-Control-Allow-Origin: * — панель используется
                # только со своего же origin (http://127.0.0.1:8787), а сторонние сайты
                # теперь не могут делать кросс-доменные запросы к API Флюкса.
                self.end_headers()
                try:
                    self.wfile.write(body)
                except Exception:
                    pass

            def _json(self, obj, code=200):
                self._send(code, json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8"))

            def do_OPTIONS(self):
                self.send_response(204)
                self.send_header("Access-Control-Allow-Headers", "Content-Type,X-Flux-Token")
                self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
                self.send_header("Content-Length", "0")
                self.end_headers()

            def do_GET(self):
                p = urllib.parse.urlparse(self.path)
                if p.path in ("/", "/index.html"):
                    self._send(200, PANEL_HTML.encode("utf-8"), "text/html; charset=utf-8")
                    return
                if not self._auth():
                    self._json({"ok": False, "error": "нужен X-Flux-Token"}, 401)
                    return
                if p.path == "/api/status":
                    self._json(panel.app.status_dict())
                elif p.path == "/api/reminders":
                    r = TT.t_reminder({"action": "list"})
                    items = list(r.get("reminders") or [])
                    r2 = TT.t_timer({"action": "list"})
                    items += list(r2.get("timers") or [])
                    self._json({"ok": True, "items": items})
                elif p.path == "/api/events":
                    ev = TB.recent_events("", 40)
                    self._json({"ok": True, "events": [f"{e['t']} [{e.get('level')}] {e.get('kind')}: {e.get('text')}" for e in ev]})
                elif p.path == "/api/messages":
                    self._json({"ok": True, "messages": panel.messages[-60:]})
                elif p.path == "/api/logs":
                    try:
                        txt = (LOG_DIR / "flux.log").read_text(encoding="utf-8", errors="replace")[-8000:]
                    except Exception as e:
                        txt = str(e)
                    self._send(200, txt.encode("utf-8"), "text/plain; charset=utf-8")
                elif p.path == "/api/models":
                    try:
                        ms = panel.app.llm.list_models()
                    except Exception as e:
                        ms = []
                    self._json({"ok": True, "provider": panel.app.llm.provider,
                                "current": panel.app.llm.model,
                                "free_mode": bool(CFG.get("prefer_free_models", True)),
                                "models": ms[:300]})
                elif p.path == "/api/provider":
                    llm = panel.app.llm
                    self._json({"ok": True, "provider": llm.provider, "model": llm.model,
                                "thinking": CFG.get("qwen_thinking", "auto"),
                                "free_mode": bool(CFG.get("prefer_free_models", True)),
                                "providers": llm.providers_status()})
                elif p.path == "/api/keys":
                    llm = panel.app.llm
                    pool = llm.key_pool()
                    self._json({"ok": True, "active": llm._key_idx,
                                "keys": [f"{k[:7]}...{k[-4:]}" for k in pool],
                                "source": key_source(),
                                "qwen_token_set": bool(QW.get_qwen_token())})
                elif p.path == "/api/prompt":
                    # v2.0.6.1: вопрос инструмента/подтверждение, ожидающий ответа (для диалога в браузере)
                    if getattr(panel, "_cur_prompt", None):
                        self._json({"ok": True, "prompt": panel._cur_prompt[0]})
                        return
                    try:
                        prompt, aq = PROMPTS.pending.get_nowait()
                        panel._cur_prompt = (prompt, aq)
                        self._json({"ok": True, "prompt": prompt})
                    except Exception:
                        self._json({"ok": True, "prompt": None})
                elif p.path == "/api/appearance":
                    self._json({"ok": True, "theme": CFG.get("panel_theme", "dark"),
                                "bg": CFG.get("panel_bg", "off")})
                elif p.path == "/api/health":
                    self._json(TB.t_system_health({"full": False, "notify": False}))
                else:
                    self._json({"ok": False, "error": "unknown path"}, 404)

            def do_POST(self):
                if not self._auth():
                    self._json({"ok": False, "error": "нужен X-Flux-Token"}, 401)
                    return
                n = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(n).decode("utf-8", "replace") if n else "{}"
                try:
                    body = json.loads(raw)
                except Exception:
                    body = {}
                p = urllib.parse.urlparse(self.path).path
                if p == "/api/send":
                    txt = str(body.get("text") or "").strip()
                    if not txt:
                        self._json({"ok": False, "error": "пусто"})
                        return
                    panel.push("из панели: " + txt, "info")
                    reply = panel.app.handle_text(txt, source="panel", timeout=600)
                    self._json({"ok": True, "reply": reply})
                elif p == "/api/provider":
                    llm = panel.app.llm
                    r = {"ok": True}
                    if body.get("provider"):
                        rr = llm.set_provider(str(body["provider"]).lower())
                        r.update(rr)
                    if body.get("model"):
                        mid = str(body["model"])
                        CFG.set("model", mid)
                        mbp = dict(CFG.get("models_by_provider") or {})
                        mbp[llm.provider] = mid
                        CFG.set("models_by_provider", mbp)
                        llm.model = mid
                        llm.used_models.clear()
                        r["model"] = mid
                    if "free_mode" in body:
                        CFG.set("prefer_free_models", bool(body["free_mode"]))
                        r["free_mode"] = bool(body["free_mode"])
                    if body.get("thinking"):
                        CFG.set("qwen_thinking", str(body["thinking"]).lower())
                        QW._CLIENT["v"] = None
                        r["thinking"] = CFG.get("qwen_thinking")
                    panel.push(f"панель: провайдер/модель -> {llm.provider}/{llm.model}", "info")
                    self._json(r)
                elif p == "/api/keys":
                    llm = panel.app.llm
                    ks = [str(x) for x in (CFG.get("api_keys") or [])]
                    if body.get("add"):
                        from core import sanitize_key
                        k = sanitize_key(str(body["add"]))
                        if len(k) < 8:
                            self._json({"ok": False, "error": "не похоже на ключ"})
                            return
                        primary = get_api_key()
                        if k == primary:
                            self._json({"ok": True, "note": "это уже активный ключ из secret.key"})
                            return
                        if k not in ks:
                            ks.append(k)
                        CFG.set("api_keys", ks)
                        self._json({"ok": True, "total": len(llm.key_pool())})
                        return
                    if "remove" in body:
                        i = int(body["remove"])
                        pool = llm.key_pool()
                        if 0 <= i < len(pool):
                            victim = pool[i]
                            if victim in ks:
                                ks.remove(victim)
                                CFG.set("api_keys", ks)
                        self._json({"ok": True})
                        return
                    if "active" in body:
                        i = int(body["active"])
                        pool = llm.key_pool()
                        if 0 <= i < len(pool):
                            llm._key_idx = i
                            llm.api_key = pool[i]
                        self._json({"ok": True, "active": llm._key_idx})
                        return
                    self._json({"ok": False, "error": "add/remove/active"})
                elif p == "/api/qwen_auto":
                    r = QW.auto_refresh_token(force=True)
                    if r.get("updated"):
                        panel.push(f"🔑 qwen-токен обновлён из {r.get('source')} ({r.get('detail')})", "info")
                    self._json({"ok": True, **r, "status": QW.token_status()})
                elif p == "/api/qwen_token":
                    tok = str(body.get("token") or "").strip()
                    if len(tok) < 20:
                        self._json({"ok": False, "error": "токен похож на огрызок (JWT начинается с eyJ)"})
                        return
                    from core.qwen_web import save_qwen_token
                    save_qwen_token(tok)
                    QW._CLIENT["v"] = None
                    self._json({"ok": True, "hint": "теперь: /provider qwen_web или выбор в панели"})
                elif p == "/api/prompt_answer":
                    cur = getattr(panel, "_cur_prompt", None)
                    if not cur:
                        self._json({"ok": False, "error": "нет активного вопроса"})
                        return
                    cur[1].put(str(body.get("text") or ""))
                    panel._cur_prompt = None
                    self._json({"ok": True})
                elif p == "/api/appearance":
                    if body.get("theme"):
                        CFG.set("panel_theme", str(body["theme"]))
                    if body.get("bg"):
                        CFG.set("panel_bg", str(body["bg"]))
                    self._json({"ok": True})
                elif p == "/api/tts":
                    say(str(body.get("text") or ""), priority=True)
                    self._json({"ok": True})
                elif p == "/api/tool":
                    name = str(body.get("name") or "")
                    r = panel.app.exec_tool(name, body.get("args") or {})
                    self._json({"ok": True, "result": r})
                else:
                    self._json({"ok": False, "error": "unknown path"}, 404)

        host = str(CFG.get("panel_host", "127.0.0.1"))
        port = int(CFG.get("panel_port", 8787))
        for attempt in range(6):
            try:
                self.httpd = ThreadingHTTPServer((host, port), H)
                break
            except OSError:
                port += 1
        else:
            log.warning("панель не запустилась (порты заняты)")
            return
        log.info("control panel: http://%s:%s", host, port)
        try:
            self.httpd.serve_forever(poll_interval=0.5)
        except Exception:
            pass


# ============================================================================
#  ГЛАВНОЕ ПРИЛОЖЕНИЕ
# ============================================================================
class FluxApp:
    def __init__(self, args):
        self.args = args
        self.name = CFG.get("assistant_name", "Флюкс")
        self.llm = LLM(CFG)
        self.session = Session()
        self.input_q: "queue.Queue[str]" = queue.Queue()
        self.proactive_q: "queue.Queue[str]" = queue.Queue()
        self.voice = VoiceInput(self)
        self.hotkey = Hotkey(self)
        self.panel = Panel(self)
        self.busy = threading.Event()
        self.chat_lock = threading.RLock()   # FIX: панель/GUI/проактив не должны ломать сессию параллельно с консолью
        self.last_reply = ""
        self._displayed = False              # FIX: True = ответ уже показан (стрим/локальная команда), REPL не печатает его повторно
        self.print_lock = threading.RLock()
        self.ask_lock = threading.Lock()
        self.gui = None
        self.tray = None
        TS.ASK_USER["fn"] = self._ask_impl   # voprosy idut v PROMPTS
        self.health_hint = ""
        self.image_q: list[dict] = []

    # ---------------------------------------------------------------- вывод
    def out(self, text: str = ""):
        with self.print_lock:
            print(text, flush=True)

    def say_flux(self, text: str, priority: bool = False):
        if CFG.get("voice_output", True):
            say(text, priority=priority)

    def _ask_impl(self, prompt: str) -> str:
        """Вопрос из потока инструмента -> главный поток (единый владелец stdin)."""
        return PROMPTS.ask(prompt, timeout=600, default="н")

    # ---------------------------------------------------------------- статус
    def status_dict(self) -> dict:
        h = jload(TB.HEALTH_FILE, default={}) or {}
        return {"alive": True, "version": VERSION, "model": self.llm.model,
                "provider": self.llm.provider,
                "uptime_min": round((time.time() - START_TIME) / 60, 1),
                "tools": len(TOOLS), "turns": self.session.turns,
                "tokens": self.llm.total_tokens, "llm_calls": self.llm.total_calls,
                "searxng": {"url": TW.searxng_base(), "alive": TW.searxng_alive(1.0)},
                "voice_input": bool(self.voice and self.voice.ready),
                "voice_output": get_speaker().engine_name,
                "watchdog": bool(TB.WATCHDOG and TB.WATCHDOG.is_alive()),
                "scheduler": bool(TT.SCHEDULER and TT.SCHEDULER.is_alive()),
                "gui": bool(getattr(self, "gui", None)),
                "problems": h.get("problems") or [],
                "session": (str(self.session.path) if getattr(self, "session", None) else ""),
                "install_dir": str(ROOT), "last_error": self.llm.last_error}

    # ---------------------------------------------------------------- LLM
    def build_head(self) -> list[dict]:
        mem = TB.memory_context_block()
        return [{"role": "system", "content": system_prompt(mem, self.health_hint)}]

    def exec_tool(self, name: str, args: dict) -> dict:
        t = TOOLS.get(name)
        if not t:
            close = [k for k in TOOLS if k.startswith(name[:4])][:5]
            return {"ok": False, "error": f"нет инструмента '{name}'", "available_similar": close}
        t0 = time.time()
        try:
            res = t["handler"](args or {})
            if not isinstance(res, dict):
                res = {"ok": True, "result": res}
        except Exception as e:
            res = {"ok": False, "error": f"{type(e).__name__}: {e}", "trace": exc_text()[-900:]}
        res.setdefault("ok", True)
        dt_s = round(time.time() - t0, 2)
        tools_log.info("%s(%s) -> %.2fs ok=%s", name, json.dumps(args, ensure_ascii=False)[:300], dt_s, res.get("ok"))
        TB.add_event("tool", f"{name} {json.dumps(args, ensure_ascii=False)[:160]} -> ok={res.get('ok')}",
                     level="info" if res.get("ok") else "warn")
        res["_seconds"] = dt_s
        return res

    def chat_once(self, user_text: str, source: str = "console") -> str:
        """Полный агентский цикл на одно пользовательское сообщение."""
        # FIX: раньше панель, GUI, голос и проактив могли крутить chat_once ОДНОВРЕМЕННО
        # и рвать общую историю сессии. Теперь — строго по очереди.
        got = self.chat_lock.acquire(timeout=0.5)
        if not got and source in ("panel", "gui", "proactive"):
            return "Флюкс сейчас выполняет другую задачу — попробуй через пару секунд."
        self.busy.set()
        t0 = time.time()
        try:
            # проактивные вставки имеют приоритет
            pro = []
            while not self.proactive_q.empty():
                try:
                    pro.append(self.proactive_q.get_nowait())
                except Exception:
                    break
            self.session.add("user", user_text)
            for p in pro:
                self.session.add("user", p)
            steps = 0
            max_steps = int(CFG.get("max_tool_steps", 24))
            final_text = ""
            pending_images = list(self.image_q)
            self.image_q.clear()
            while steps <= max_steps:
                steps += 1
                msgs = self.build_head()
                ctx = self.session.context(msgs)
                if pending_images:
                    content = [{"type": "text", "text": "Скриншот/изображение для анализа (приложено к последнему сообщению):"}]
                    for im in pending_images:
                        content.append({"type": "image_url",
                                        "image_url": {"url": f"data:{im['mime']};base64,{im['b64']}"}})
                    ctx = ctx + [{"role": "user", "content": content}]
                    pending_images = []
                # v2.0.6: у web-API chat.qwen.ai нет function calling — там агентность
                # даёт текстовый фолбэк + нативный поиск у моделей :search
                tools = None if (self.llm.model in self.llm.no_tools_models
                                 or self.llm.provider == "qwen_web") else TS.tool_schemas()
                printed = {"first": True}

                def on_delta(c, printed=printed):
                    if not c:
                        return
                    if printed["first"]:
                        sys.stdout.write(f"\n{C.CYAN}{self.name}:{C.RESET} ")
                        printed["first"] = False
                    sys.stdout.write(c)
                    sys.stdout.flush()

                try:
                    r = self.llm.chat(ctx, tools=tools, stream=True, on_delta=on_delta if source == "console" else None)
                except LLMError as e:
                    self.out(f"\n{C.RED}[LLM ошибка] {e}{C.RESET}")
                    final_text = f"Ошибка модели: {e}"
                    self.session.add("assistant", final_text)
                    break
                content = (r.get("content") or "").strip()
                tcs = r.get("tool_calls") or []
                if source == "console" and content and not printed["first"]:
                    self.out("")  # перевод строки после стриминга
                # текстовый фолбэк вызова инструментов
                if not tcs and content:
                    tcs = self._parse_text_tool_calls(content)
                if not tcs and not content and steps > 1:
                    content = "Готово — все действия выполнены (детали в выводе инструментов выше)."
                if not tcs:
                    final_text = content
                    if content:
                        self.session.add("assistant", content)
                    else:
                        self.session.add("assistant", "(пустой ответ модели)")
                    break
                # сохраняем сообщение ассистента с tool_calls
                self.session.add("assistant", content or "", tool_calls=tcs)
                if content and source != "console":
                    final_text = content
                for tc in tcs:
                    fn = (tc.get("function") or {})
                    name = fn.get("name") or ""
                    raw_args = fn.get("arguments") or "{}"
                    args = _parse_args(raw_args)
                    self.out(f"{C.BLUE}  ⚙ {name}{C.RESET} {C.DIM}{json.dumps(args, ensure_ascii=False)[:180]}{C.RESET}")
                    if source != "console":
                        self.panel.push(f"⚙ {name} {json.dumps(args, ensure_ascii=False)[:300]}", "info")
                    res = self.exec_tool(name, args)
                    img = res.pop("_image_b64", None)
                    mime = res.pop("_image_mime", "image/png")
                    if img:
                        self.image_q.append({"b64": img, "mime": mime})
                    res_text = json.dumps(res, ensure_ascii=False, default=str)
                    # v2.0.5: 24K -> 12K символов на результат инструмента в истории:
                    # каждый такой кусок пересылается модели на каждом шаге агента
                    res_text = truncate_middle(res_text, 12000)
                    self.session.add("tool", res_text, tool_call_id=tc.get("id") or rand_id(10), name=name)
                    if name in ("notify", "ask_user") or not res.get("ok", True):
                        dlog(f"  -> {clip(res_text, 300)}")
                # FIX: картинки, которые вернули инструменты В ЭТОМ ходе (screen_capture),
                # раньше оседали в image_q и показывались модели только на следующем ходу.
                if self.image_q:
                    pending_images.extend(self.image_q)
                    self.image_q.clear()
                if steps >= max_steps:
                    self.out(f"{C.YELLOW}  [достигнут лимит шагов агента: {max_steps}]{C.RESET}")
                    final_text = (content or "") + f"\n\n(достигнут лимит в {max_steps} шагов — продолжу по команде «продолжай»)"
                    self.session.add("assistant", final_text)
                    break
            self.session.turns += 1
            self.session.auto_title()
            self.session.save()
            self.last_reply = final_text
            # FIX: раньше ответ озвучивался ТОЛЬКО для консоли, а для голоса/проактива
            # не печатался и не озвучивался вообще — фразы «Флюкс, ...» отвечали в никуда.
            if final_text and source in ("voice", "proactive"):
                self.out(f"{C.CYAN}{self.name}:{C.RESET} {final_text}")
                self._displayed = True
            if source == "console":
                self._displayed = True   # контент уже показан стримингом (on_delta)
            if final_text and (source in ("console", "voice")
                               or (source == "proactive" and CFG.get("proactive_speak", True))):
                self.say_flux(final_text)
            if self.voice.ready:
                self.voice.arm_followup()
            dlog(f"[turn] {steps} шагов, {round(time.time()-t0,1)}s")
            return final_text
        except Exception as e:
            log.error("chat_once: %s", exc_text()[-1500:])
            msg = f"Внутренняя ошибка: {type(e).__name__}: {e}"
            self.out(f"{C.RED}{msg}{C.RESET}")
            return msg
        finally:
            self.busy.clear()
            try:
                self.chat_lock.release()
            except RuntimeError:
                pass

    @staticmethod
    def _parse_text_tool_calls(content: str) -> list[dict]:
        """Если модель не умеет tools — вытаскиваем JSON-блоки вида {"tool": "...", "args": {...}}."""
        out = []
        pats = [r'\{\s*"tool"\s*:\s*"([a-z_]+)"\s*,\s*"args"\s*:\s*(\{.*?\})\s*\}',
                r'\{\s*"name"\s*:\s*"([a-z_]+)"\s*,\s*"arguments"\s*:\s*(\{.*?\})\s*\}']
        for p in pats:
            for m in re.finditer(p, content, re.S):
                name, argsraw = m.group(1), m.group(2)
                if name in TOOLS:
                    out.append({"id": rand_id(10), "type": "function",
                                "function": {"name": name, "arguments": argsraw}})
        return out

    def handle_text(self, text: str, source: str = "console", timeout: int = 600) -> str:
        """Обработка ввода: сначала локальные быстрые команды, потом агент."""
        text = str(text or "").strip()
        self._displayed = False
        PROMPTS.set_source(source)   # v2.0.6.1: подтверждения/ask_user знают, куда показать диалог
        if not text:
            return ""
        local = self.local_command(text)
        if local is not None:
            txt = local.get("text", "")
            # FIX: раньше локальные команды («таймер 5 мин», «время»...) при голосовом
            # вводе не печатались и не озвучивались ВООБЩЕ — пользователь не получал ответа.
            if source in ("console", "voice"):
                if txt:
                    self.out(f"{C.CYAN}{self.name}:{C.RESET} {txt}")
                self._displayed = True
                self.say_flux(local.get("speak", ""))
            return txt
        if source != "console":
            self.out(f"{C.MAG}[{source}] {text}{C.RESET}")
        return self.chat_once(text, source=source)

    # ---------------------------------------------------------------- локальные быстрые команды
    def local_command(self, text: str) -> dict | None:
        """Мгновенные действия без LLM: время, таймер, громкость, стоп и т.п."""
        t = text.strip()
        low = t.lower().replace("ё", "е")
        name_low = str(self.name).lower()
        # срезаем wake word в начале
        for ww in [name_low] + [str(w).lower() for w in (CFG.get("wake_words") or [])]:
            if ww and low.startswith(ww):
                stripped = t[len(ww):].strip(" ,.!:-")
                if stripped:
                    t, low = stripped, stripped.lower().replace("ё", "е")
                break
        # --- служебные
        if low in ("стоп", "stop", "хватит", "замолчи", "тихо"):
            get_speaker().stop()
            return {"text": "Остановился.", "speak": ""}
        if low in ("/exit", "/quit", "выход", "пока", "до свидания", "выйти"):
            self.out(f"{C.CYAN}{self.name}:{C.RESET} Сессия сохранена: {self.session.path.name}. До связи!")
            self.say_flux("До связи", priority=True)
            self.shutdown()
            time.sleep(0.6)
            os._exit(0)
        if low in ("/help", "помощь", "команды", "что ты умеешь"):
            return {"text": HELP_TEXT, "speak": "Список команд вывел на экран."}
        if low in ("/status", "статус"):
            d = self.status_dict()
            lines = [f"FLUX v{VERSION}  |  модель {d['model']}  |  аптайм {d['uptime_min']} мин",
                     f"инструментов: {d['tools']}  |  ходов: {d['turns']}  |  LLM-запросов: {d['llm_calls']}",
                     f"токены: {d['tokens']['prompt']} вх / {d['tokens']['completion']} исх",
                     f"SearXNG: {d['searxng']['url']} -> {'работает' if d['searxng']['alive'] else 'НЕ запущен'}",
                     f"голос: ввод={'да' if d['voice_input'] else 'нет'}  вывод={d['voice_output']}",
                     f"сторож: {'активен' if d['watchdog'] else 'выкл'}  планировщик: {'активен' if d['scheduler'] else 'выкл'}",
                     f"панель: {self.panel.url()}",
                     f"проблемы системы: {_join(d['problems']) if d['problems'] else 'нет'}",
                     f"папка: {ROOT}"]
            return {"text": "\n".join(lines), "speak": "Статус вывел на экран."}
        if low.startswith("/provider"):
            parts = t.split()
            if len(parts) > 1:
                r = self.llm.set_provider(parts[1].lower())
                return {"text": (f"Провайдер: {r.get('provider')} | модель: {r.get('model')} | "
                                 f"{r.get('base', r.get('error', ''))}"),
                        "speak": f"Провайдер {parts[1]}" if r.get("ok") else ""}
            lines = [f"Активный: {self.llm.provider} | модель: {self.llm.model}"]
            for ps in self.llm.providers_status():
                mark = "▶" if ps["active"] else " "
                st = "готов" if ps["ready"] else f"НЕ готов ({ps['detail']})"
                lines.append(f" {mark} {ps['id']:<9} {st:<38} {ps['name']}")
            lines.append("Переключение: /provider qwen_web | ollama | xkiro | bridge")
            lines.append("Бесплатный безлимитный чат: qwen_web (модель qwen3.8-max:search — с интернетом)")
            return {"text": "\n".join(lines), "speak": ""}
        if low.startswith("/model"):
            parts = t.split()
            if len(parts) > 1:
                mid = parts[1]
                CFG.set("model", mid)
                mbp = dict(CFG.get("models_by_provider") or {})
                mbp[self.llm.provider] = mid
                CFG.set("models_by_provider", mbp)
                self.llm.model = mid
                self.llm.used_models.clear()
                return {"text": f"Модель переключена на {mid} (провайдер {self.llm.provider})",
                        "speak": f"Модель {mid}"}
            ms = self.llm.list_models()
            free = [m for m in ms if m.get("tier") == "free"]
            rows = []
            for m in ms[:60]:
                tags = ""
                if m.get("search"):
                    tags += " 🌐поиск"
                if m.get("tier") == "local":
                    tags += " 🏠локальная"
                if m.get("tier") == "free":
                    tags += " 🆓"
                rows.append(f"  {m['id']}{tags}")
            head = (f"Провайдер: {self.llm.provider} | текущая: {self.llm.model} | "
                    f"free-режим: {'вкл' if CFG.get('prefer_free_models') else 'выкл'}")
            return {"text": head + "\n" + ("\n".join(rows) or "(список пуст — проверь /provider)"),
                    "speak": ""}
        if low in ("/sessions",):
            ss = Session.list_sessions(15)
            return {"text": "\n".join(f"{s.get('modified')}  {Path(s['file']).name}  ходов={s.get('turns')}  «{s.get('title')}»" for s in ss) or "пусто", "speak": ""}
        if low.startswith("/load"):
            parts = t.split(maxsplit=1)
            if len(parts) < 2:
                return {"text": "использование: /load <имя файла сессии>", "speak": ""}
            target = SESSIONS_DIR / safe_filename(parts[1].strip())
            if not target.exists():
                cands = list(SESSIONS_DIR.glob("*" + parts[1].strip() + "*.jsonl"))
                if cands:
                    target = cands[0]
                else:
                    return {"text": f"сессия не найдена: {parts[1]}", "speak": ""}
            self.session = Session.load(target)
            return {"text": f"Загружена сессия {target.name}: {len(self.session.messages)} сообщений, «{self.session.title}»",
                    "speak": "Сессия загружена"}
        if low in ("/compact", "сжать историю"):
            r = self.session.compress_with_llm(self.llm)
            return {"text": f"Сжатие: {r}", "speak": ""}
        if low in ("/clear", "очистить"):
            self.session = Session()
            return {"text": "История очищена, новая сессия начата.", "speak": "Память сессии очищена"}
        if low.startswith("/say"):
            self.say_flux(t[4:].strip(), priority=True)
            return {"text": "(озвучено)", "speak": ""}
        if low.startswith("/voice"):
            on = "on" in low or "вкл" in low
            CFG.set("voice_output", on)
            get_speaker().set_enabled(on)
            return {"text": f"Озвучка {'включена' if on else 'выключена'}", "speak": "Озвучка включена" if on else ""}
        if low.startswith("/listen"):
            if not self.voice.ready:
                return {"text": f"Голосовой ввод недоступен: {self.voice.reason}", "speak": ""}
            txt = self.voice.listen_once(12)
            if txt:
                self.input_q.put(txt)
                return {"text": f"(услышал: {txt}) — обрабатываю", "speak": ""}
            return {"text": "(ничего не услышал)", "speak": ""}
        if low.startswith("/tools"):
            names = sorted(TOOLS)
            return {"text": f"Инструментов: {len(names)}\n" + "\n".join(
                f"• {n} — {TOOLS[n]['description'][:110]}" for n in names), "speak": ""}
        if low.startswith("/panel"):
            return {"text": "Панель: " + self.panel.url(), "speak": ""}
        if low.startswith("/bg"):
            self.spawn_background()
            return {"text": "Фоновый экземпляр запущен (flux_background.vbs)", "speak": ""}
        if low in ("/gui", "открой окно", "покажи окно", "окно флюкса", "gui"):
            try:
                import tkinter  # noqa: F401
                import gui_window
                if self.gui is None:
                    gui_window.launch(self, blocking=False)
                    self.out(f"{C.GREEN}Окно Flux открыто (Ctrl+Alt+Space — показать/спрятать){C.RESET}")
                    return {"text": "Окно открыто.", "speak": "Открыл окно"}
                self.gui.show()
                return {"text": "Окно показано.", "speak": ""}
            except Exception as e:
                return {"text": f"GUI недоступен: {e}", "speak": ""}
        if low in ("открой панель", "панель управления", "/panel open"):
            url = self.panel.url()
            open_path(url.split("/?token=")[0] + "/?token=" + str(CFG.get("panel_token", "")))
            return {"text": f"Панель открыта: {url}", "speak": "Открыл панель управления"}
        if low.startswith("/rem"):
            r = TT.t_reminder({"action": "list"})
            r2 = TT.t_timer({"action": "list"})
            rem = r.get("reminders") or []
            tim = r2.get("timers") or []
            rem_txt = rem if isinstance(rem, str) else "\n".join(rem)
            tim_txt = tim if isinstance(tim, str) else "\n".join(tim)
            return {"text": f"НАПОМИНАНИЯ:\n{rem_txt or '(нет)'}\n\nТАЙМЕРЫ:\n{tim_txt or '(нет)'}", "speak": ""}

        # --- быстрые системные действия без LLM
        if re.fullmatch(r"(время|который час|сколько времени|time|дата|какое сегодня число)\??", low):
            r = TT.t_get_time({"format": "full"})
            txt = f"{r.get('local_datetime')} ({r.get('weekday')})"
            return {"text": txt, "speak": "Сейчас " + dt.datetime.now().strftime("%H часов %M минут").replace(" 0", " ")}
        m = re.fullmatch(r"(?:поставь\s+)?таймер\s+(?:на\s+)?(\d+(?:[.,]\d+)?)\s*(сек\w*|мин\w*|м\b|ч\w*|час\w*|h)\.?", low)
        if m:
            val = float(m.group(1).replace(",", "."))
            u = m.group(2)
            sec = val if u.startswith("сек") else val * 60 if u.startswith(("мин", "м")) else val * 3600
            r = TT.t_timer({"action": "start", "seconds": sec, "label": "быстрый таймер"})
            return {"text": f"⏱ {r.get('message')}", "speak": f"Таймер на {int(sec // 60)} минут {int(sec % 60)} секунд запущен"}
        m = re.fullmatch(r"(?:громкость|звук)\s+(\d{1,3})\s*%?", low)
        if m:
            r = TS.t_system_control({"action": "volume_set", "value": int(m.group(1))})
            vol = r.get("now_percent") or m.group(1)
            return {"text": f"🔊 Громкость: {str(vol).strip() or m.group(1)}%",
                    "speak": f"Громкость {m.group(1)} процентов"}
        if low in ("тише", "громче", "mute", "звук тише", "звук громче"):
            act = {"тише": "volume_down", "звук тише": "volume_down", "mute": "mute",
                   "громче": "volume_up", "звук громче": "volume_up"}[low]
            TS.t_system_control({"action": act, "value": 10})
            return {"text": f"🔊 {act}", "speak": ""}
        if low in ("скриншот", "скрин", "снимок экрана", "screenshot"):
            r = TS.t_screen_capture({"analyze": False})
            if r.get("ok"):
                open_path(r["path"])
                return {"text": f"📸 {r['path']}", "speak": "Скриншот сделан"}
            return {"text": f"не удалось: {r.get('error')}", "speak": ""}
        if low in ("стоп все", "закрыть всё", "показать рабочий стол"):
            TS.t_system_control({"action": "show_desktop"})
            return {"text": "Рабочий стол показан", "speak": ""}
        # --- выключение ПК по расписанию (v2.0.6) ---
        if low in ("отмени выключение", "отменить выключение", "не выключайся", "отбой выключения"):
            r = TS.t_system_control({"action": "cancel_shutdown"})
            return {"text": f"💡 {r.get('action', 'выключение отменено')}", "speak": "Выключение отменено"}
        m = re.fullmatch(r"(?:выключи|отключи)(?:сь)?\s+(?:комп(?:ьютер)?|пк)\s+через\s+"
                         r"(\d+(?:[.,]\d+)?)\s*(сек\w*|мин\w*|час\w*|ч)\.?", low)
        if m:
            val = float(m.group(1).replace(",", "."))
            u = m.group(2)
            sec = int(val if u.startswith("сек") else val * 60 if u.startswith(("мин",)) else val * 3600)
            r = TS.t_system_control({"action": "shutdown_in", "value": sec})
            if r.get("ok"):
                return {"text": f"🔌 ПК выключится через {sec // 60} мин ({sec} сек). Отмена: «отмени выключение»",
                        "speak": f"Компьютер выключится через {sec // 60} минут"}
            if r.get("cancelled"):
                return {"text": "🔌 выключение ОТМЕНЕНО: действие не подтверждено. "
                                "В консоли ответь «д» на вопрос; из панели придёт всплывающий диалог.",
                        "speak": "Выключение не подтверждено, отменяю"}
            return {"text": f"не удалось: {r.get('error') or r.get('reason') or r}", "speak": ""}
        m = re.fullmatch(r"(?:выключи|отключи)(?:сь)?\s+(?:комп(?:ьютер)?|пк)\s+в\s+(\d{1,2})[:.](\d{2})", low)
        if m:
            r = TS.t_system_control({"action": "shutdown_at", "value": f"{int(m.group(1)):02d}:{m.group(2)}"})
            if r.get("ok"):
                return {"text": f"🔌 ПК выключится в {m.group(1)}:{m.group(2)}. Отмена: «отмени выключение»",
                        "speak": f"Компьютер выключится в {m.group(1)} {m.group(2)}"}
            if r.get("cancelled"):
                return {"text": "🔌 выключение ОТМЕНЕНО: действие не подтверждено.",
                        "speak": "Выключение не подтверждено, отменяю"}
            return {"text": f"не удалось: {r.get('error') or r.get('reason') or r}", "speak": ""}
        m = re.match(r"^(?:напомни(?:те)?|напоминание|remind)\s+(?:мне\s+)?(.+)$", low)
        if m:
            tail = m.group(1).strip()
            what = when = ""
            pats = [
                r"^(?P<what>.+?)\s+(?:в|на|через)\s+(?P<when>(?:сегодня|завтра|послезавтра)?\s*\d{1,2}[:.]\d{2}.*)$",
                r"^(?P<what>.+?)\s+через\s+(?P<when>\d+(?:[.,]\d+)?\s*(?:сек\w*|мин\w*|час\w*|ч\b|дн\w*|недел\w*).*)$",
                r"^(?P<what>.+?)\s+(?:в|на)\s+(?P<when>(?:завтра|послезавтра|сегодня).*)$",
                r"^(?P<what>.+?)\s+(?:в|на)\s+(?P<when>\d{1,2}(?::\d{2})?\s*(?:утра|вечера|дня|ночи)?)$",
                r"^(?P<what>.+?)\s+(?P<when>в\s+(?:понедельник|вторник|среду|четверг|пятницу|субботу|воскресенье)(?:\s+\d{1,2}\.\d{1,2}(?:\.\d{2,4})?)?(?:\s+(?:в\s+)?\d{1,2}[:.]\d{2})?.*)$",
                r"^(?P<what>.+?)\s+(?P<when>\d{1,2}\s*(?:утра|вечера|дня|ночи))$",
                r"^(?P<what>.+?)\s+(?P<when>(?:завтра|послезавтра|сегодня).*)$",
                r"^(?P<what>.+?)\s+(?P<when>\d{1,2}\.\d{1,2}(?:\.\d{2,4})?(?:\s+\d{1,2}:\d{2})?)$",
            ]
            for pat in pats:
                mm = re.match(pat, tail)
                if mm:
                    what = mm.group("what").strip(" ,.!-")
                    when = mm.group("when").strip()
                    break
            if what and when:
                r = TT.t_reminder({"action": "add", "text": what, "when": when})
                if r.get("ok"):
                    return {"text": f"🔔 {r.get('message')}",
                            "speak": f"Напомню: {what}. {r.get('in', '')}"}
                return {"text": f"не получилось создать напоминание: {r.get('error')} {r.get('hint', '')}",
                        "speak": "Не смог разобрать время напоминания"}
        if low in ("напоминания", "мои напоминания", "расписание"):
            r = TT.t_schedule_list({})
            return {"text": "\n".join(r.get("items") or []) or "расписание пустое", "speak": ""}
        if low in ("проверка системы", "здоровье пк", "диагностика", "health"):
            r = TB.t_system_health({"full": True})
            pr = r.get("problems") or []
            txt = ("✅ Система в норме\n" if not pr else "⚠ Проблемы:\n" + "\n".join("• " + p for p in pr))
            txt += "\n\nРекомендации:\n" + "\n".join("• " + x for x in (r.get("recommendations") or [])[:5])
            return {"text": txt, "speak": ("Всё в норме" if not pr else "Внимание. " + pr[0][:200])}
        return None

    # ---------------------------------------------------------------- проактивный поток
    def start_proactive_worker(self):
        """Обрабатывает проактивные сообщения в фоне — Flux сам начинает разговор."""
        def loop():
            while True:
                try:
                    if self.proactive_q.empty() or self.busy.is_set():
                        time.sleep(0.4)
                        continue
                    txt = self.proactive_q.get(timeout=1)
                    if not txt:
                        continue
                    self.out(f"\n{C.YELLOW}⚡ {self.name} обращается сам (важное событие){C.RESET}")
                    self.chat_once(txt, source="proactive")
                    self.out("")
                except queue.Empty:
                    continue
                except Exception as e:
                    log.warning("proactive worker: %s", e)
                    time.sleep(1.0)
        t = threading.Thread(target=loop, daemon=True, name="flux-proactive")
        t.start()
        return t

    # ---------------------------------------------------------------- фон
    def spawn_background(self):
        vbs = ROOT / "flux_background.vbs"
        if vbs.exists():
            try:
                if IS_WIN:
                    subprocess.Popen(["wscript.exe", str(vbs)], creationflags=0x08000000)
                else:
                    subprocess.Popen([sys.executable, str(ROOT / "flux.py"), "--background"])
                return True
            except Exception as e:
                log.warning("spawn_background: %s", e)
        return False

    def inject_proactive(self, text: str):
        self.proactive_q.put(text)
        self.out(f"{C.YELLOW}⚡ проактивное событие поставлено в очередь{C.RESET}")

    # ---------------------------------------------------------------- жизненный цикл
    def start_services(self):
        self._ensure_external_bridge()
        self._qwen_autotoken_boot()
        self.start_proactive_worker()
        TT.start_scheduler(self)
        TB.start_watchdog(self)
        self.panel.start()
        try:
            import gui_window
            self.tray = gui_window.start_tray(self)
        except Exception:
            self.tray = None
        # FIX: настройка gui_on_start в config.json существовала, но никогда не использовалась
        if CFG.get("gui_on_start") and self.gui is None and not (
                self.args.background or self.args.daemon):
            try:
                import gui_window
                gui_window.launch(self, blocking=False)
            except Exception as e:
                log.warning("gui_on_start: %s", e)
        if self.voice.ready and CFG.get("voice_input", True):
            self.voice.start()
        self.hotkey.start()

    def _qwen_autotoken_boot(self):
        """v2.0.9: при старте тихо пробуем освежить токен qwen из браузера,
        если qwen_web используется или стоит в авто-фолбэке."""
        if not CFG.get("qwen_auto_token", True):
            return
        use = (self.llm.provider == "qwen_web"
               or "qwen_web" in (CFG.get("auto_fallback_providers") or []))
        if not use:
            return

        def _go():
            try:
                st = QW.token_status()
                if st["state"] == "ok" and float(st.get("days") or 99) > 0.25:
                    return
                r = QW.auto_refresh_token(force=True)
                if r.get("updated"):
                    self.out(f"{C.GREEN}🔑 qwen-токен обновлён автоматически: "
                             f"{r.get('source')} -> {r.get('detail')}{C.RESET}")
            except Exception as e:
                log.debug("qwen autotoken boot: %s", e)
        threading.Thread(target=_go, daemon=True, name="flux-qwen-autotok").start()

    def _ensure_external_bridge(self):
        """v2.0.6: если выбран провайдер bridge, а мост :8000 не поднят — поднимаем сами
        (автоматически при запуске run.bat / FLUX.exe). Встроенному qwen_web это не нужно."""
        try:
            if str(CFG.get("provider")) != "bridge":
                return
            u = urllib.parse.urlparse(str(CFG.get("bridge_url") or "http://127.0.0.1:8000/v1"))
            if port_open(u.hostname or "127.0.0.1", int(u.port or 8000), 0.8):
                return
            script = ROOT / "tools" / "qwen_bridge.py"
            tok = QW.get_qwen_token()
            if not script.exists():
                log.warning("bridge: tools/qwen_bridge.py не найден")
                return
            if not tok:
                log.warning("bridge: нет токена chat.qwen.ai (qwen_web.key) — мост не поднимаю")
                return
            py = TS.find_python()
            if not py:
                log.warning("bridge: не найден python для внешнего моста")
                return
            env = dict(os.environ)
            env["QWEN_TOKEN"] = tok
            argv = py.split() + [str(script)]
            subprocess.Popen(argv, env=env, cwd=str(ROOT),
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             creationflags=0x08000000 if IS_WIN else 0)
            log.info("bridge: внешний qwen-bridge поднят автоматически (:8000)")
            self.out(f"{C.DIM}[bridge] поднят tools/qwen_bridge.py на :8000{C.RESET}")
        except Exception as e:
            log.warning("ensure bridge: %s", e)

    def shutdown(self):
        try:
            self.session.save()
            if self.voice.ready:
                self.voice.stop()
            self.hotkey.stop()
            if TB.WATCHDOG:
                TB.WATCHDOG.stop()
            if TT.SCHEDULER:
                TT.SCHEDULER.stop()
            get_speaker().stop()
            log.info("shutdown")
        except Exception:
            pass


def _parse_args(raw) -> dict:
    if isinstance(raw, dict):
        return raw
    if not raw:
        return {}
    s = str(raw).strip()
    if s in ("", "null", "None"):
        return {}
    try:
        j = json.loads(s)
        return j if isinstance(j, dict) else {"value": j}
    except Exception:
        pass
    # чиним одинарные кавычки / python-литералы
    try:
        import ast
        j = ast.literal_eval(s)
        if isinstance(j, dict):
            return j
    except Exception:
        pass
    s2 = s.replace("'", '"')
    try:
        j = json.loads(s2)
        return j if isinstance(j, dict) else {"value": j}
    except Exception:
        m = re.search(r"\{.*\}", s, re.S)
        if m:
            try:
                j = json.loads(m.group(0))
                if isinstance(j, dict):
                    return j
            except Exception:
                pass
    log.warning("не разобрал аргументы инструмента: %s", s[:200])
    return {"_raw": s}


def _join(x) -> str:
    """Аккуратно склеивает список строк; если пришла строка — возвращает её как есть."""
    if isinstance(x, str):
        return x
    try:
        return "; ".join(str(i) for i in x)
    except Exception:
        return str(x)


HELP_TEXT = f"""{C.CYAN}FLUX {VERSION} — команды и возможности{C.RESET}

{C.YELLOW}Голос{C.RESET}
  Скажи вслух: «ФЛЮКС, какая погода» — без слова «Флюкс» в начале не сработает.
  Горячая клавиша push-to-talk: {CFG.get('hotkey_modifiers')}+{CFG.get('hotkey_key')} (говорить без wake word).
  После ответа Флюкс слушает ещё {CFG.get('followup_timeout')} сек — можно продолжать диалог.

{C.YELLOW}Быстрые команды (без обращения к модели — мгновенно){C.RESET}
  время · таймер 5 мин · громкость 40 · тише/громче · скриншот
  напоминания · проверка системы · стоп · показать рабочий стол

{C.YELLOW}Провайдеры и модели (v2.0.6){C.RESET}
  /provider            показать/сменить: xkiro | qwen_web | ollama | bridge
  /model [id]          модель провайдера; qwen3.8-max:search — qwen С ПОИСКОМ в интернете
                       (chat.qwen.ai, без лимитов xkiro; токен: tools/token_snippet.js)
  Веб-панель {CFG.get('panel_host')}:{CFG.get('panel_port')} — выбор провайдера/модели/ключей,
  free-режим, темы и анимированный фон прямо в браузере.

{C.YELLOW}Выключение ПК{C.RESET}
  «выключи комп через 30 мин» · «выключи комп в 23:30» · «отмени выключение»

{C.YELLOW}Служебные команды{C.RESET}
  /help            эта справка            /status        статус системы и агента
  /tools           список всех инструментов  /model [id]   посмотреть/сменить модель
  /sessions        список сохранённых диалогов  /load <имя>  продолжить старый диалог
  /compact         сжать историю (экономия токенов)  /clear   новая сессия
  /rem             напоминания и таймеры   /panel       ссылка на веб-панель
  /say <текст>     озвучить текст          /voice on|off  озвучка вкл/выкл
  /listen          сказать один раз в микрофон  /bg      запустить фоновый экземпляр
  /exit            выход

{C.YELLOW}Примеры задач для агента{C.RESET}
  «Флюкс, найди все pdf на диске D за неделю и скопируй в D:\\Docs»
  «Флюкс, создай программу-таймер Помодоро на python и запусти в фоне»
  «Флюкс, что сейчас на экране? сделай скриншот и разбери»
  «Флюкс, проверь ПК на вирусы и покажи что ест память»
  «Флюкс, напомни завтра в 9:00 отправить отчёт, повтор каждый будний день»
  «Флюкс, найди в интернете лучшие практики по Docker и сделай выжимку»
  «Флюкс, скачай это видео: <ссылка>»
  «Флюкс, открой панель управления и браузер»

{C.YELLOW}Веб-панель{C.RESET}: {CFG.get('panel_host')}:{CFG.get('panel_port')}  (управление из браузера, даже с телефона в той же сети)
{C.YELLOW}Веб-поиск{C.RESET}: SearXNG в Docker {CFG.get('searxng_url')} (если не запущен — автоматически DDG/Bing)
"""


# ============================================================================
#  ПЕРВЫЙ ЗАПУСК / API KEY
# ============================================================================
def first_run_setup(app: FluxApp) -> bool:
    key = get_api_key()
    if key:
        return True
    app.out(f"""
{C.YELLOW}┌─────────────────────────────────────────────────────────────────┐
│  НУЖЕН API-КЛЮЧ (бесплатно, 1 минута)                          │
└─────────────────────────────────────────────────────────────────┘{C.RESET}
  1) Открой в браузере:  {C.CYAN}https://xkiro.com{C.RESET}
  2) Зарегистрируйся / войди  ->  раздел {C.CYAN}API Keys{C.RESET}  ->  Create key
  3) Скопируй ключ (обычно начинается с sk-...)
  Ключ можно вставить прямо сейчас, либо потом вписать в {ROOT}\\config.json
  (поле "api_key"), или в файл {ROOT}\\secret.key
""")
    try:
        open_path("https://xkiro.com")
    except Exception:
        pass
    for _ in range(3):
        k = PROMPTS.ask("Вставь API-ключ (или Enter чтобы пропустить) >", timeout=300, default="").strip()
        if not k:
            break
        if len(k) < 8:
            app.out(f"{C.RED}Похоже, это не ключ. Попробуй ещё раз.{C.RESET}")
            continue
        try:
            SECRETS = ROOT / "secret.key"
            SECRETS.write_text(k, encoding="utf-8")
            try:
                os.chmod(SECRETS, 0o600)
            except Exception:
                pass
            # FIX: ключ сохраняем ТОЛЬКО в secret.key (права 600), а не дублируем
            # открытым текстом ещё и в config.json
            CFG.data["api_key"] = k
            app.llm.api_key = k
            app.out(f"{C.GREEN}Ключ сохранён в secret.key ✓{C.RESET}")
            return True
        except Exception as e:
            app.out(f"{C.RED}Не удалось сохранить: {e}{C.RESET}")
    app.out(f"{C.YELLOW}Работаю без ключа — часть запросов может не пройти. Впиши ключ позже.{C.RESET}")
    return False


def connectivity_report(app: FluxApp) -> str:
    lines = []
    # API
    key_ok = bool(get_api_key())
    lines.append(("API-ключ xkiro",
                  f"{masked_key()} из {key_source()}" if key_ok
                  else "НЕТ (нужен бесплатный ключ на https://xkiro.com -> API Keys)"))
    st, body = http_json(app.llm.base + "/models", timeout=15, headers=app.llm._headers())
    if st == 200 and isinstance(body, dict):
        n = len(body.get("data") or [])
        lines.append((f"api.xkiro.com", f"доступен, моделей: {n}"))
    else:
        lines.append(("api.xkiro.com", f"ОШИБКА http {st}"))
    # SearXNG
    alive = TW.searxng_alive(1.5)
    lines.append((f"SearXNG {TW.searxng_base()}", "работает (Docker)" if alive else "НЕ запущен -> install_searxng.bat"))
    # docker
    r = cmd_run("docker --version", timeout=20)
    lines.append(("Docker", (r.get("stdout") or "").strip()[:40] if r.get("code") == 0 else "не установлен (не критично: поиск пойдёт через DDG/Bing)"))
    # голос
    v = app.voice
    lines.append(("Голосовой ввод", "готов" if v.ready else f"недоступен: {v.reason}"))
    lines.append(("Озвучка (TTS)", get_speaker().engine_name))
    # пакеты
    pkgs = {"psutil": "ресурсы системы", "mss": "скриншоты", "PIL": "обработка изображений",
            "pyttsx3": "быстрая озвучка", "keyboard": "горячая клавиша", "yt_dlp": "скачивание видео",
            "edge_tts": "нейро-голос", "pytesseract": "OCR текста с экрана",
            "sounddevice": "запись звука", "trafilatura": "чистое чтение веб-страниц"}
    missing = []
    for mod, why in pkgs.items():
        try:
            __import__(mod)
        except Exception:
            missing.append(f"{mod} ({why})")
    lines.append(("Опциональные пакеты", "все на месте" if not missing else "не хватает: " + ", ".join(missing)))
    # интернет
    lines.append(("Интернет", "есть" if port_open("1.1.1.1", 53, 2) else "НЕТ"))
    return "\n".join(f"  {a:<28} {b}" for a, b in lines)


# ============================================================================
#  MAIN LOOP
# ============================================================================
def repl(app: FluxApp):
    PROMPTS.interactive = True
    app.out(f"{C.GREEN}Готов. Пиши задачу или говори «{app.name}, ...»{C.RESET}")
    app.out(f"{C.DIM}/help — команды · /exit — выход · панель: {app.panel.url()}{C.RESET}\n")
    # стартовое приветствие + проактивная проверка
    def boot():
        try:
            rep = TB.t_system_health({"full": True, "notify": False})
            problems = rep.get("problems") or []
            app.health_hint = json.dumps({k: v for k, v in (rep.get("snapshot") or {}).items()
                                          if k in ("cpu_percent", "memory_percent", "disks", "battery", "internet", "temperature_c")},
                                         ensure_ascii=False)[:1200]
            greet = random.choice([
                f"{app.name} на связи. Систему проверил: " + ("есть замечания — смотри ниже." if problems else "всё в норме."),
                f"Системы в норме, {app.name} готов к работе." if not problems else f"{app.name} готов. Обнаружены замечания по системе.",
            ])
            app.out(f"{C.CYAN}{app.name}:{C.RESET} {greet}")
            if problems:
                app.out(f"{C.YELLOW}⚠ Проактивное предупреждение:{C.RESET}")
                plist = problems if isinstance(problems, list) else [problems]
                for p in plist[:5]:
                    app.out(f"   • {p}")
                for r in (rep.get("recommendations") or [])[:3]:
                    app.out(f"{C.DIM}   → {r}{C.RESET}")
                app.inject_proactive("При запуске обнаружены проблемы системы:\n" + "\n".join(problems[:6]) +
                                     "\n\nСам коротко предупреди пользователя и предложи конкретное исправление (можешь выполнить диагностику сам).")
            else:
                app.say_flux(greet)
        except Exception as e:
            log.warning("boot health: %s", e)
    if not app.args.no_boot_check:
        threading.Thread(target=boot, daemon=True).start()

    while True:
        try:
            # 1) голосовые фразы
            try:
                while True:
                    txt = app.voice.q.get_nowait()
                    app.out(f"{C.MAG}🎙 {txt}{C.RESET}")
                    app.handle_text(txt, source="voice")
            except queue.Empty:
                pass
            # 2) проактивные сообщения обрабатывает отдельный поток (start_proactive_worker)
            # 3) вопросы от инструментов (подтверждения / ask_user) — всегда в главном потоке
            if PROMPTS.poll():
                continue
            # 4) консольный ввод
            if _stdin_ready():
                line = sys.stdin.readline()
                if not line:
                    time.sleep(0.3)
                    continue
                line = line.rstrip("\n")
                if line.strip():
                    res = app.handle_text(line, source="console")
                    # FIX: ответ агента уже напечатан стримингом / локальной командой —
                    # раньше он выводился второй раз целиком.
                    if res and not app._displayed:
                        app.out(f"{C.CYAN}{app.name}:{C.RESET} {res}")
                    continue
            time.sleep(0.12)
        except KeyboardInterrupt:
            app.out(f"\n{C.YELLOW}Выход (Ctrl+C). Сохраняю сессию...{C.RESET}")
            app.shutdown()
            break
        except EOFError:
            app.shutdown()
            break
        except Exception as e:
            log.error("repl: %s", exc_text()[-1200:])
            app.out(f"{C.RED}[ошибка цикла] {type(e).__name__}: {e}{C.RESET}")
            time.sleep(0.5)


def _stdin_ready() -> bool:
    if not sys.stdin or sys.stdin.closed:
        return False
    try:
        if IS_WIN:
            import msvcrt
            return msvcrt.kbhit()
        import select
        return bool(select.select([sys.stdin], [], [], 0)[0])
    except Exception:
        return True


# ============================================================================
#  РЕЖИМЫ ЗАПУСКА
# ============================================================================
def mode_background(app: FluxApp):
    """Фоновый режим: голос + сторож + панель + напоминания, без консоли.
    Опасные действия здесь ОТКЛОНЯЮТСЯ автоматически (подтверждать некому),
    если в config.json не задано auto_approve_dangerous=true."""
    PROMPTS.interactive = False
    PROMPTS.default = "н"
    app.out(f"{C.CYAN}[FLUX background] запущен в фоне. Панель: {app.panel.url()}{C.RESET}")
    log.info("background mode started")
    while True:
        try:
            # голос
            try:
                while True:
                    txt = app.voice.q.get_nowait()
                    log.info("[voice] %s", txt)
                    app.handle_text(txt, source="voice")
            except queue.Empty:
                pass
            # проактив обрабатывает отдельный поток start_proactive_worker()
            # (FIX: раньше фон-цикл и worker выхватывали сообщения из одной очереди
            #  вสอง потока и могли крутить chat_once параллельно)
            time.sleep(0.2)
        except KeyboardInterrupt:
            app.shutdown()
            break
        except Exception as e:
            log.error("background loop: %s", exc_text()[-800:])
            time.sleep(1.0)


def mode_daemon(app: FluxApp):
    """Служебный режим: только сторож + напоминания + панель (LLM по запросу из панели)."""
    PROMPTS.interactive = False
    app.out("[FLUX daemon] сторож и напоминания активны. Панель: " + app.panel.url())
    while True:
        try:
            time.sleep(1)
        except KeyboardInterrupt:
            app.shutdown()
            break


def mode_check(app: FluxApp):
    print(connectivity_report(app))
    return 0


def mode_selftest(app: FluxApp):
    print(f"{C.CYAN}=== САМОТЕСТИРОВАНИЕ FLUX {VERSION} ==={C.RESET}")
    ok = fail = 0

    def t(name, fn):
        nonlocal ok, fail
        try:
            r = fn()
            good = bool(r.get("ok", True)) if isinstance(r, dict) else True
            print(f"  [{'OK ' if good else 'WARN'}] {name}: {clip(json.dumps(r, ensure_ascii=False, default=str), 200)}")
            ok += 1 if good else 0
            fail += 0 if good else 1
        except Exception as e:
            print(f"  [FAIL] {name}: {type(e).__name__}: {e}")
            fail += 1

    t("get_time", lambda: TT.t_get_time({}))
    t("system_info", lambda: TS.t_system_info({"section": "cpu"}))
    t("list_dir", lambda: TS.t_list_dir({"path": str(ROOT), "limit": 5}))
    t("write/read file", lambda: (TS.t_write_file({"path": str(SANDBOX_DIR / "selftest.txt"), "content": "привет flux"}),
                                 TS.t_read_file({"path": str(SANDBOX_DIR / "selftest.txt")}))[1])
    t("edit_file", lambda: TS.t_edit_file({"path": str(SANDBOX_DIR / "selftest.txt"), "old_text": "привет", "new_text": "ЗДРАВСТВУЙ"}))
    t("search_files", lambda: TS.t_search_files({"path": str(ROOT), "name_pattern": "*.json", "max_depth": 2, "limit": 5}))
    t("file_ops info", lambda: TS.t_file_ops({"action": "info", "path": str(ROOT / "config.json")}))
    t("timer", lambda: TT.t_timer({"action": "start", "seconds": 60, "label": "selftest"}))
    t("timer list", lambda: TT.t_timer({"action": "list"}))
    t("reminder", lambda: TT.t_reminder({"action": "add", "text": "selftest", "when": "+2 часа"}))
    t("schedule_list", lambda: TT.t_schedule_list({}))
    t("notes", lambda: TS.REGISTRY["notes"]["handler"]({"action": "todo_add", "text": "selftest task"}))
    t("memory", lambda: TB.t_memory({"action": "remember", "text": "selftest fact", "importance": "high"}))
    t("memory recall", lambda: TB.t_memory({"action": "recall", "text": "selftest"}))
    t("clipboard", lambda: TS.t_clipboard({"action": "get"}))
    t("process_list", lambda: TS.t_process_list({"limit": 5}))
    t("find_app", lambda: TS.t_find_app({"query": "notepad"}))
    t("network ping", lambda: TS.t_network_diagnostics({"action": "ping", "host": "1.1.1.1"}))
    t("searxng_status", lambda: TW.t_searxng_status({"action": "status"}))
    t("web_search", lambda: TW.t_web_search({"query": "Docker SearXNG", "limit": 3}))
    t("fetch_url", lambda: TW.t_fetch_url({"url": "https://example.com", "max_chars": 500}))
    t("weather", lambda: TW.t_weather({"city": "Москва", "days": 1}))
    t("translate", lambda: TW.t_translate({"text": "Hello world", "target": "ru"}))
    t("screen_capture", lambda: TS.t_screen_capture({"analyze": False}))
    t("security_scan", lambda: TS.t_security_scan({"check": "defender"}))
    t("system_events", lambda: TS.t_system_events({"hours": 6, "limit": 5}))
    t("system_health", lambda: TB.t_system_health({"full": True, "notify": False}))
    t("watchdog status", lambda: TB.t_watchdog({"action": "status"}))
    t("create_app", lambda: TS.t_create_app({"name": "selftest_app", "kind": "batch",
                                             "content": "@echo off\r\necho Flux selftest ok\r\n"}))
    t("flux_self status", lambda: t_flux_self({"action": "status"}))
    t("LLM ping", lambda: {"ok": bool(app.llm.api_key) and app.llm.chat(
        [{"role": "user", "content": "ответь одним словом: ok"}], stream=False, max_tokens=10).get("content") is not None})
    # FIX: убираем за собой мусор — раньше selftest оставлял таймер на 60 сек и
    # напоминание «selftest» через 2 часа, которые потом звенели/говорили сами собой.
    try:
        with TT._lock:
            items = TT._load()
            TT._save([i for i in items if "selftest" not in str(i.get("text", "")).lower()])
        nd = jload(TB.NOTES_FILE, default={"notes": {}, "todos": []})
        nd["todos"] = [x for x in nd.get("todos", []) if "selftest" not in str(x.get("text", "")).lower()]
        jsave(TB.NOTES_FILE, nd)
        mm = jload(TB.MEMORY_FILE, default={})
        if isinstance(mm, dict) and mm.get("facts"):
            mm["facts"] = [f for f in mm["facts"] if "selftest" not in str(f.get("text", "")).lower()]
            jsave(TB.MEMORY_FILE, mm)
    except Exception:
        pass
    print(f"\n{C.GREEN}Пройдено: {ok}{C.RESET}  {C.RED}Проблем: {fail}{C.RESET}")
    print(connectivity_report(app))
    return 0 if fail == 0 else 1


# ============================================================================
def build_argparser():
    p = argparse.ArgumentParser(description="FLUX AI assistant")
    p.add_argument("--background", action="store_true", help="фоновый режим (голос + сторож + панель)")
    p.add_argument("--daemon", action="store_true", help="служебный режим (только сторож/напоминания/панель)")
    p.add_argument("--check", action="store_true", help="проверить окружение и соединения")
    p.add_argument("--selftest", action="store_true", help="прогнать самотестирование всех инструментов")
    p.add_argument("--setup", action="store_true", help="мастер первоначальной настройки (API-ключ)")
    p.add_argument("--say", type=str, default="", help="озвучить текст и выйти")
    p.add_argument("--ask", type=str, default="", help="одноразовый вопрос агенту (без REPL)")
    p.add_argument("--resume", action="store_true", help="продолжить последнюю сессию")
    p.add_argument("--session", type=str, default="", help="загрузить конкретную сессию")
    p.add_argument("--no-voice", action="store_true", help="отключить голосовой ввод")
    p.add_argument("--no-tts", action="store_true", help="отключить озвучку")
    p.add_argument("--no-panel", action="store_true", help="не поднимать веб-панель")
    p.add_argument("--no-watchdog", action="store_true", help="отключить проактивный сторож")
    p.add_argument("--no-boot-check", action="store_true", help="без стартовой проверки системы")
    p.add_argument("--model", type=str, default="", help="переопределить модель")
    p.add_argument("--verbose", action="store_true", help="показывать отладку")
    p.add_argument("--gui", action="store_true", help="открыть плавающее окно GUI")
    p.add_argument("--menu", action="store_true",
                   help="стартовое меню с анимацией (в собранном EXE включено по умолчанию)")
    p.add_argument("--no-menu", action="store_true", help="не показывать меню в EXE-режиме")
    p.add_argument("--tool", type=str, default="", help="вызвать инструмент напрямую: --tool web_search --args '{\"query\":\"...\"}'")
    p.add_argument("--args", type=str, default="{}", help="JSON-аргументы для --tool")
    p.add_argument("--version", action="store_true")
    return p


def main() -> int:
    args = build_argparser().parse_args()
    if args.verbose:
        os.environ["FLUX_VERBOSE"] = "1"
        os.environ["FLUX_DEBUG"] = "1"
    if args.version:
        print(f"FLUX {VERSION} (python {sys.version.split()[0]}) root={ROOT}")
        return 0
    if args.no_voice:
        CFG.data["voice_input"] = False
    if args.no_tts:
        CFG.data["voice_output"] = False
        get_speaker().set_enabled(False)
    if args.no_panel:
        CFG.data["control_panel"] = False
    if args.no_watchdog:
        CFG.data["proactive"] = False
    if args.model:
        CFG.data["model"] = args.model

    if args.say:
        say(args.say, priority=True)
        time.sleep(max(2.0, len(args.say) / 11.0))
        return 0

    # ---------------- стартовое меню (анимация/темы) ----------------
    # Показываем, если: --menu явно, ИЛИ запущен собранный EXE без явного режима.
    explicit_mode = (args.background or args.daemon or args.check or args.selftest
                     or args.setup or args.ask or args.tool or args.say or args.gui
                     or args.resume or bool(args.session))
    want_menu = args.menu or (getattr(sys, "frozen", False) and not args.no_menu
                              and not explicit_mode and sys.stdin.isatty())
    if want_menu:
        try:
            import flux_menu
            while True:
                action = flux_menu.run_menu()
                if action == "run":
                    break
                if action == "background":
                    args.background = True
                    break
                if action == "gui":
                    args.gui = True
                    break
                if action == "exit":
                    return 0
                break
        except ImportError:
            pass
        except Exception as e:
            print(f"{C.YELLOW}[menu] недоступно ({e}) — обычный запуск{C.RESET}")

    banner()
    app = FluxApp(args)
    global APP, PANEL
    APP = app
    PANEL = app.panel
    PROMPTS.interactive = True   # до старта REPL: мастер настройки может спросить ключ

    if args.tool:
        a = _parse_args(args.args)
        res = app.exec_tool(args.tool, a)
        print(json.dumps(res, ensure_ascii=False, indent=2, default=str))
        return 0 if res.get("ok", True) else 1

    if args.check:
        return mode_check(app)

    first_run_setup(app)

    if args.selftest:
        app.start_services()
        return mode_selftest(app)

    # восстановление сессии
    if args.session:
        p = SESSIONS_DIR / args.session
        if p.exists():
            app.session = Session.load(p)
            app.out(f"{C.GREEN}Загружена сессия: {p.name} ({len(app.session.messages)} сообщений){C.RESET}")
    elif args.resume:
        ss = Session.list_sessions(1)
        if ss:
            app.session = Session.load(Path(ss[0]["file"]))
            app.out(f"{C.GREEN}Продолжаю сессию: {app.session.title}{C.RESET}")

    app.start_services()
    rep = connectivity_report(app)
    app.out(f"{C.DIM}{rep}{C.RESET}\n")

    if args.ask:
        r = app.handle_text(args.ask, source="console")
        app.shutdown()
        return 0

    if args.background:
        mode_background(app)
        return 0
    if args.daemon:
        mode_daemon(app)
        return 0
    if args.gui:
        try:
            import gui_window
            gui_window.launch(app)
        except Exception as e:
            app.out(f"{C.RED}GUI недоступен: {e}{C.RESET}")
    repl(app)
    return 0


APP: FluxApp | None = None
PANEL: Panel | None = None

if __name__ == "__main__":
    # FIX: когда flux.py запущен как скрипт, он живёт в модуле __main__.
    # gui_window/mic_test делают `import flux` и получали ВТОРОЙ экземпляр модуля
    # со своими синглтонами (PROMPTS/APP...) — правили не то состояние.
    if "flux" not in sys.modules:
        sys.modules["flux"] = sys.modules["__main__"]
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n[FLUX] остановлено пользователем")
        sys.exit(0)
    except Exception:
        print(f"{C.RED}[FLUX] критическая ошибка:{C.RESET}\n{traceback.format_exc()}")
        try:
            log.error("FATAL:\n%s", traceback.format_exc())
        except Exception:
            pass
        sys.exit(1)
