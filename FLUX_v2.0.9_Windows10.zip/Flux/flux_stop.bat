@echo off
chcp 65001 >nul
rem  Останавливает все фоновые процессы FLUX
echo  Останавливаю FLUX...
if exist "%~dp0data\flux_bg.stop" del "%~dp0data\flux_bg.stop" >nul 2>&1
echo stop> "%~dp0data\flux_bg.stop"
taskkill /FI "WINDOWTITLE eq FLUX*" /F >nul 2>&1
wmic process where "CommandLine like '%%flux.py%%' and name like 'python%%'" call terminate >nul 2>&1
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*flux.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1
del "%~dp0data\flux_bg.lock" >nul 2>&1
echo  Готово. FLUX остановлен.
timeout /t 2 >nul
