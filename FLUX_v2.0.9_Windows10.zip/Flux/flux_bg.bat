@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONUTF8=1"
if exist "%~dp0venv\Scripts\pythonw.exe" (set "PYW=%~dp0venv\Scripts\pythonw.exe") else (set "PYW=pythonw")
echo  Запускаю FLUX в фоне (без окна)...
start "" /min "%PYW%" "%~dp0flux.py" --background --no-boot-check
echo  Готово. Панель: http://127.0.0.1:8787 (токен — в config.json: panel_token)
echo  Остановка: flux_stop.bat
timeout /t 3 >nul
