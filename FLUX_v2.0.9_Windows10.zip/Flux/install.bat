@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
title FLUX AI assistant :: install
rem ============================================================
rem  FLUX AI assistant :: УСТАНОВЩИК (Windows 10/11)
rem  Ставит всё на диск D:\Flux (как просил пользователь)
rem ============================================================
set "SRC=%~dp0"
set "SRC=%SRC:~0,-1%"
set "DEST=D:\Flux"
set "PYVER="

echo.
echo  ============================================================
echo    F L U X   ::   установка ИИ-ассистента
echo    целевая папка: %DEST%   (диск D)
echo  ============================================================
echo.

rem ---------- 0. права администратора (необязательно, но желательно)
net session >nul 2>&1
if errorlevel 1 (
  echo  [i] Запуск не от администратора. Установка возможна, но для
  echo      установки Python и некоторых системных функций лучше
  echo      запустить этот файл правой кнопкой - "Запуск от имени администратора".
  echo.
  choice /c YN /m "  Продолжить без прав администратора"
  if errorlevel 2 exit /b 1
)

rem ---------- 1. папка назначения
if not exist "D:\" (
  echo  [!] Диск D: не найден.
  choice /c YN /m "  Установить в C:\Flux вместо D:\Flux"
  if errorlevel 2 exit /b 1
  set "DEST=C:\Flux"
)
echo  [1/9] Создаю %DEST%
if not exist "%DEST%" mkdir "%DEST%" 2>nul
if not exist "%DEST%" (
  echo  [X] Не удалось создать %DEST%. Проверь права на диск D.
  pause & exit /b 1
)

rem ---------- 2. python
echo  [2/9] Ищу Python 3.10+ ...
set "PYCMD="
py -3 -c "import sys" >nul 2>&1
if not errorlevel 1 set "PYCMD=py -3"
if not defined PYCMD (
  python -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYCMD=python"
)
if not defined PYCMD (
  python3 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYCMD=python3"
)

if not defined PYCMD (
  echo  [i] Python не найден. Пробую поставить через winget ...
  where winget >nul 2>&1
  if errorlevel 1 (
    echo  [X] winget тоже нет. Установи Python вручную:
    echo      https://www.python.org/downloads/windows/   ^(галочка "Add python.exe to PATH"^)
    start "" "https://www.python.org/downloads/windows/"
    pause & exit /b 1
  )
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
  set "PATH=%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python312\Scripts;%PATH%"
  py -3 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYCMD=py -3"
  if not defined PYCMD (
    python -c "import sys" >nul 2>&1
    if not errorlevel 1 set "PYCMD=python"
  )
)
if not defined PYCMD (
  echo  [X] Python так и не найден. Поставь его и запусти установку заново.
  pause & exit /b 1
)
%PYCMD% -c "import sys;print('.'.join(map(str,sys.version_info[:3])))" > "%TEMP%\fluxpyver.txt" 2>nul
set /p PYVER=<"%TEMP%\fluxpyver.txt"
del "%TEMP%\fluxpyver.txt" >nul 2>&1
echo      найден Python %PYVER%  ^(команда: %PYCMD%^)

rem ---------- 3. копируем файлы
echo  [3/9] Копирую файлы проекта в %DEST% ...
robocopy "%SRC%" "%DEST%" /E /XD venv __pycache__ .git /XF "*.zip" /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 (
  echo  [X] Ошибка копирования файлов.
  pause & exit /b 1
)
echo      готово.

rem ---------- 4. виртуальное окружение
echo  [4/9] Создаю виртуальное окружение %DEST%\venv ...
if not exist "%DEST%\venv\Scripts\python.exe" (
  %PYCMD% -m venv "%DEST%\venv"
)
set "VPY=%DEST%\venv\Scripts\python.exe"
if not exist "%VPY%" (
  echo  [!] venv не создался — буду использовать системный Python.
  set "VPY=%PYCMD%"
  set "NOVENV=1"
) else (
  echo      ок: %VPY%
)

rem ---------- 5. зависимости
echo  [5/9] Ставлю пакеты ^(это самая долгая часть, 2-6 минут^) ...
"%VPY%" -m pip install --upgrade pip setuptools wheel --quiet --disable-pip-version-check
if exist "%DEST%\requirements-core.txt" (
  "%VPY%" -m pip install -r "%DEST%\requirements-core.txt" --disable-pip-version-check --no-input
)
if exist "%DEST%\requirements-extra.txt" (
  echo      доп. пакеты ^(голос/экран/видео^) — если какой-то не поставится, Flux продолжит работать без него
  "%VPY%" -m pip install -r "%DEST%\requirements-extra.txt" --disable-pip-version-check --no-input
  if errorlevel 1 (
    echo      [i] Часть доп. пакетов не установилась. Ставлю по одному критичные...
    "%VPY%" -m pip install SpeechRecognition --disable-pip-version-check --no-input
    "%VPY%" -m pip install PyAudio --disable-pip-version-check --no-input
    "%VPY%" -m pip install sounddevice soundfile --disable-pip-version-check --no-input
    "%VPY%" -m pip install pyttsx3 psutil mss pillow --disable-pip-version-check --no-input
    "%VPY%" -m pip install keyboard --disable-pip-version-check --no-input
  )
)
echo      пакеты установлены.

rem ---------- 6. API ключ
echo  [6/9] API-ключ xkiro.com
if exist "%DEST%\secret.key" (
  echo      ключ уже сохранён в %DEST%\secret.key
) else (
  echo      Ключ бесплатно: https://xkiro.com  -^>  API Keys  -^>  Create key
  set "NEWKEY="
  set /p "NEWKEY=      Вставь ключ сейчас (или нажми Enter, чтобы ввести позже): "
  if defined NEWKEY (
    >"%DEST%\secret.key" echo|set /p="!NEWKEY!"
    echo      ключ сохранён в %DEST%\secret.key
  ) else (
    echo      [i] Ок, Flux спросит ключ при первом запуске.
  )
)

rem ---------- 7. docker + SearXNG
echo  [7/9] Проверяю Docker ^(для веб-поиска SearXNG^) ...
where docker >nul 2>&1
if errorlevel 1 (
  echo      Docker не установлен.
  echo      [i] Без Docker Flux тоже ищет в интернете (DuckDuckGo/Bing), но
  echo          SearXNG даёт намного более качественный и приватный поиск.
  choice /c YN /m "      Показать страницу загрузки Docker Desktop"
  if not errorlevel 2 start "" "https://docs.docker.com/desktop/install/windows-install/"
) else (
  for /f "delims=" %%i in ('docker info --format "{{.ServerVersion}}" 2^>nul') do set "DVER=%%i"
  if defined DVER (
    echo      Docker запущен: !DVER!
    call "%DEST%\install_searxng.bat" "%DEST%"
  ) else (
    echo      [!] Docker установлен, но ДЕМОН НЕ ЗАПУЩЕН.
    echo          Запусти Docker Desktop, потом выполни: install_searxng.bat
  )
)

rem ---------- 8. ярлыки, автозагрузка, bat-файлы
echo  [8/9] Создаю ярлыки и служебные файлы ...
> "%DEST%\flux.bat" echo @echo off
>>"%DEST%\flux.bat" echo chcp 65001 ^>nul
>>"%DEST%\flux.bat" echo cd /d "%DEST%"
>>"%DEST%\flux.bat" echo %VPY% "%DEST%\flux.py" %%*
>>"%DEST%\flux.bat" echo if errorlevel 1 pause

> "%DEST%\flux_bg.bat" echo @echo off
>>"%DEST%\flux_bg.bat" echo chcp 65001 ^>nul
>>"%DEST%\flux_bg.bat" echo cd /d "%DEST%"
>>"%DEST%\flux_bg.bat" echo %VPY% "%DEST%\flux.py" --background

> "%DEST%\flux_check.bat" echo @echo off
>>"%DEST%\flux_check.bat" echo chcp 65001 ^>nul
>>"%DEST%\flux_check.bat" echo cd /d "%DEST%"
>>"%DEST%\flux_check.bat" echo %VPY% "%DEST%\flux.py" --check
>>"%DEST%\flux_check.bat" echo pause

> "%DEST%\flux_selftest.bat" echo @echo off
>>"%DEST%\flux_selftest.bat" echo chcp 65001 ^>nul
>>"%DEST%\flux_selftest.bat" echo cd /d "%DEST%"
>>"%DEST%\flux_selftest.bat" echo %VPY% "%DEST%\flux.py" --selftest
>>"%DEST%\flux_selftest.bat" echo pause

> "%DEST%\flux_update.bat" echo @echo off
>>"%DEST%\flux_update.bat" echo chcp 65001 ^>nul
>>"%DEST%\flux_update.bat" echo cd /d "%DEST%"
>>"%DEST%\flux_update.bat" echo %VPY% -m pip install -U -r requirements-core.txt -r requirements-extra.txt
>>"%DEST%\flux_update.bat" echo pause

> "%DEST%\uninstall_flux.bat" echo @echo off
>>"%DEST%\uninstall_flux.bat" echo chcp 65001 ^>nul
>>"%DEST%\uninstall_flux.bat" echo echo Удаление FLUX...
>>"%DEST%\uninstall_flux.bat" echo taskkill /F /IM python.exe /FI "WINDOWTITLE eq FLUX*" ^>nul 2^>^&1
>>"%DEST%\uninstall_flux.bat" echo docker rm -f flux-searxng ^>nul 2^>^&1
>>"%DEST%\uninstall_flux.bat" echo reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v FluxAI /f ^>nul 2^>^&1
>>"%DEST%\uninstall_flux.bat" echo del /q "%USERPROFILE%\Desktop\FLUX Ассистент.lnk" ^>nul 2^>^&1
>>"%DEST%\uninstall_flux.bat" echo del /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\FLUX AI.lnk" ^>nul 2^>^&1
>>"%DEST%\uninstall_flux.bat" echo choice /c YN /m "Удалить и ВСЕ ДАННЫЕ (сессии, память, скриншоты)?"
>>"%DEST%\uninstall_flux.bat" echo if not errorlevel 2 rd /s /q "%DEST%"
>>"%DEST%\uninstall_flux.bat" echo echo Готово.
>>"%DEST%\uninstall_flux.bat" echo pause

"%DEST%\venv\Scripts\python.exe" "%DEST%\tools\make_shortcut.py" "%DEST%" >nul 2>&1
if errorlevel 1 "%VPY%" "%DEST%\tools\make_shortcut.py" "%DEST%" >nul 2>&1

rem ---------- 9. проверка
echo  [9/9] Проверяю установку ...
"%VPY%" "%DEST%\flux.py" --version
"%VPY%" "%DEST%\flux.py" --check

echo.
echo  ============================================================
echo    УСТАНОВКА ЗАВЕРШЕНА
echo  ------------------------------------------------------------
echo    Папка          : %DEST%
echo    Запуск         : двойной клик по  %DEST%\run.bat   (или ярлык на рабочем столе)
echo    Аним. меню     : %DEST%\run_menu.bat   (темы/анимация, как в EXE)
echo    Сборка EXE     : %DEST%\build_exe.bat  (анимированное меню сборки)
echo    Фоновый режим  : %DEST%\flux_background.vbs
echo    Веб-панель     : http://127.0.0.1:8787  (токен генерируется при первом запуске,
echo                     смотреть: config.json -^> panel_token или команда /panel)
echo    Поиск SearXNG  : http://localhost:8888
echo    Проверка       : %DEST%\flux_check.bat
echo    Самотест       : %DEST%\flux_selftest.bat
echo    Удаление       : %DEST%\uninstall_flux.bat
echo.
echo    Голосом: скажи  "ФЛЮКС, какая погода"
echo  ============================================================
echo.
choice /c YN /m "  Запустить FLUX прямо сейчас"
if errorlevel 2 goto :end
call "%DEST%\run.bat"
:end
echo.
pause
endlocal
