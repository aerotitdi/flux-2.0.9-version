@echo off
chcp 65001 >nul
setlocal
set "ROOT=%~dp0"
set "ROOT=%ROOT:~0,-1%"
set "KEY=HKCU\Software\Microsoft\Windows\CurrentVersion\Run"

echo.
echo   FLUX :: автозагрузка с Windows
echo   папка: %ROOT%
echo.
echo   1) Включить автозагрузку (Flux стартует в фоне при входе в Windows)
echo   2) Выключить автозагрузку
echo   3) Показать текущее состояние
echo   4) Выход
echo.
set /p "CH=  Твой выбор: "

if "%CH%"=="1" (
  reg add "%KEY%" /v FluxAI /t REG_SZ /d "wscript.exe \"%ROOT%\flux_background.vbs\"" /f
  echo   [OK] Автозагрузка включена.
  schtasks /Create /TN "FluxWatchdog" /TR "wscript.exe \"%ROOT%\flux_background.vbs\"" /SC ONLOGON /RL LIMITED /F >nul 2>&1
  echo   [i] Дополнительно создана задача планировщика FluxWatchdog.
)
if "%CH%"=="2" (
  reg delete "%KEY%" /v FluxAI /f >nul 2>&1
  schtasks /Delete /TN "FluxWatchdog" /F >nul 2>&1
  echo   [OK] Автозагрузка выключена.
)
if "%CH%"=="3" (
  reg query "%KEY%" /v FluxAI 2>nul
  if errorlevel 1 (echo   автозагрузка ВЫКЛЮЧЕНА) else (echo   автозагрузка ВКЛЮЧЕНА)
  schtasks /Query /TN "FluxWatchdog" 2>nul | findstr /i "FluxWatchdog" >nul && echo   задача FluxWatchdog: есть || echo   задача FluxWatchdog: нет
)
echo.
pause
endlocal
