# 🧯 FLUX — решение проблем (Windows 10)

Первым делом всегда: **`flux_check.bat`** (диагностика) и **`flux_selftest.bat`** (прогон всех инструментов).
Логи: `D:\Flux\data\logs\flux.log`, `D:\Flux\data\logs\tools.log`.

---

## 1. Установка

**`install.bat` закрывается мгновенно**
→ Запусти из командной строки, чтобы увидеть текст ошибки:
```bat
cd /d D:\_flux_dist
install.bat
```

**«Не удалось создать D:\Flux»**
→ Нет прав на диск D или его не существует. Запусти от администратора, либо поменяй в `install.bat`
строку `set "DEST=D:\Flux"` на другую папку.

**Python не найден, winget тоже**
→ Поставь Python вручную: https://www.python.org/downloads/windows/ , при установке **обязательно**
поставь галочку **«Add python.exe to PATH»**. Версии 3.10–3.12 (3.13 иногда ломает PyAudio/pyttsx3).
После установки перезапусти `install.bat`.

**`pip install PyAudio` падает с ошибкой компиляции**
```bat
D:\Flux\venv\Scripts\pip install --upgrade pip wheel
D:\Flux\venv\Scripts\pip install PyAudio
:: если не вышло:
D:\Flux\venv\Scripts\pip install pipwin && D:\Flux\venv\Scripts\pipwin install pyaudio
:: альтернатива без PyAudio — sounddevice (Flux умеет писать звук через него):
D:\Flux\venv\Scripts\pip install sounddevice soundfile
```

**Антивирус ругается на `.vbs`/`.bat`**
→ Это ложное срабатывание на `flux_background.vbs` (скрытый запуск python). Добавь папку `D:\Flux`
в исключения Защитника: «Безопасность Windows» → Защита от вирусов → Управление настройками → Исключения.

---

## 2. API / модель

**`HTTP 401` / `403` / «API-ключ неверный»**
1. Открой `D:\Flux\secret.key` — там должен быть ключ одной строкой, **без кавычек и пробелов**.
2. Пересоздай ключ на https://xkiro.com (возможно, истёк лимит бесплатного плана).
3. Проверь: `flux.py --tool flux_config --args "{\"action\":\"model\"}"`.

**`model not found` / модель недоступна**
→ Flux автоматически уходит на `model_fallbacks`. Вручную: `/model qwen/qwen3.7-plus:free`.

**Ответы очень долгие**
→ Бесплатный тариф может стоять в очереди. Поставь в `config.json`:
`"request_timeout": 120`, `"max_tokens": 2048`, модель `qwen/qwen3.7-flash:free` (быстрее).
Простые вещи (время, таймер, громкость, скриншот) и так работают **мгновенно без модели**.

**`429 Too Many Requests`**
→ Лимит бесплатного ключа. Flux ждёт и повторяет автоматически (`max_retries`).
Если постоянно — смени модель на другую бесплатную или разнеси запросы по времени.

---

## 3. Голос

**«нет PyAudio» / микрофон молчит / нет озвучки**
→ **запусти `D:\Flux\fix_voice.bat`** (ставит SpeechRecognition, PyAudio + запасной sounddevice,
pyttsx3, edge-tts, keyboard), затем **`D:\Flux\flux_mic_test.bat`** — он по шагам покажет:
список микрофонов, запись 4 секунд, распознавание фразы, работу wake word и озвучку.
Вручную: см. пункт 1 (PyAudio) и пункт 3 ниже.
**«микрофон не найден»**
→ Параметры → Система → Звук → «Ввод»: выбери устройство и скажи что-нибудь (полоска должна двигаться).
→ Параметры → Конфиденциальность → Микрофон → **«Разрешить классическим приложениям доступ к микрофону» = Вкл**.

**Распознавание не срабатывает на «Флюкс»**
* Говори чётко, без паузы перед командой: «Флюкс, какая погода».
* Посмотри, что реально услышано: запусти с `--verbose` — в консоли будет строка
  `[voice] услышано: ... -> wake=...`.
* Добавь свой вариант произношения в `config.json → wake_words`, например `["флюкс","flux","флукс","флюкс","флук","флюксы"]`.
* Если Google Speech недоступен (нет интернета/блокировка) — используй `Ctrl+Alt+F` или `/listen`.

**Flux не озвучивает ответы**
```bat
D:\Flux\venv\Scripts\pip install pyttsx3 edge-tts
```
Затем `/voice on`. В `config.json`: `"tts_engine": "pyttsx3"` (офлайн, голоса Windows)
или `"edge"` (нейро-голос, нужен интернет), `"tts_voice": "ru-RU-DmitryNeural"`.
Если русского голоса нет: Параметры → Время и язык → Язык → Русский → Параметры → добавить голосовой пакет.

**Озвучка тормозит / прерывается**
→ `"tts_engine": "pyttsx3"` быстрее и стабильнее; `"sound_fx": false` убирает писки.

---

## 4. SearXNG / Docker

**«SearXNG не запущен»**
```bat
docker version          :: есть ли Docker
docker ps -a            :: есть ли контейнер flux-searxng
install_searxng.bat     :: пересоздать контейнер
docker logs flux-searxng
```
*Docker Desktop не запущен* → стартуй его, дождись кита в трее.
*Порт 8888 занят* → поменяй в `docker-compose.yml` и `config.json` на другой (например 8889).
*Контейнер перезапускается по кругу* → удали и пересоздай: `docker rm -f flux-searxng`,
затем проверь, что `D:\Flux\searxng\settings.yml` содержит:
```yaml
search:
  formats: [html, json]
```
*JSON не отдаётся* → SearXNG перезаписал конфиг; верни `formats: json` и `docker restart flux-searxng`.

**Поиск без Docker работает?**
Да. Flux автоматически использует DuckDuckGo → Bing → Wikipedia. Проверка:
```bat
D:\Flux\venv\Scripts\python D:\Flux\flux.py --tool web_search --args "{\"query\":\"docker\",\"engine\":\"ddg\"}"
```

---

## 5. Экран, звук, система

**Скриншот не создаётся**
```bat
D:\Flux\venv\Scripts\pip install mss pillow
```
На Windows без `mss` используется PowerShell+System.Drawing (работает, но медленнее).

**OCR (чтение текста с экрана) не работает**
1. Установи Tesseract: https://github.com/UB-Mannheim/tesseract/wiki (при установке отметь русский язык).
2. `D:\Flux\venv\Scripts\pip install pytesseract pillow`
3. Добавь `C:\Program Files\Tesseract-OCR` в PATH и перезапусти Flux.

**«Отказано в доступе» при shutdown / реестре / чужих процессах**
→ Запусти `run.bat` **от имени администратора**.

**Громкость/яркость не меняются**
→ Яркость через WMI работает на ноутбуках; на ПК с внешним монитором — только кнопками монитора.
→ Громкость: убедись, что установлено устройство воспроизведения по умолчанию.

**Запись звука с микрофона не идёт**
```bat
D:\Flux\venv\Scripts\pip install sounddevice soundfile
```

---

## 6. Панель и GUI

**Панель не открывается**
→ В консоли команда `/panel` покажет точный адрес с токеном. Если порт занят, Flux сам берёт следующий (8788…).
→ `"control_panel": true` в `config.json`.

**GUI не появляется**
→ `/gui`; нужен tkinter (входит в официальный Python). Если ставил Python без tcl/tk — переустанови с галочкой tcl/tk.

**Трея нет**
```bat
D:\Flux\venv\Scripts\pip install pystray pillow
```

---

## 7. Производительность и память

* Flux держит контекст в пределах `context.max_chars` (90 000 символов) и сам сжимает историю —
  расход токенов виден в `/status`.
* Длинные диалоги: `/compact` (умное сжатие моделью) или `/clear` (новая сессия).
* Тяжёлые проверки (журналы Windows, Defender) кэшируются на 10 минут — повторный `system_health` быстрее.
* Фоновый режим `--daemon` почти не потребляет CPU (сторож раз в 3 минуты).
* Скриншоты и записи копятся в `data\media\` — периодически чисти:
  «Флюкс, удали скриншоты старше 7 дней».

---

## 8. Сброс до заводских

```bat
cd /d D:\Flux
ren config.json config.json.old
del secret.key
rd /s /q data\sessions data\memory data\logs
:: затем снова впиши ключ и запусти run.bat
```

---

## 9. Как попросить помощь у самого Flux

```
Флюкс, запусти самодиагностику и расскажи, что не работает
Флюкс, покажи последние 50 строк своего лога
Флюкс, проверь интернет, DNS и скорость
Флюкс, почему не работает поиск? проверь SearXNG и почини
```
